<?php
/**
 * NxtGen Database Connection Layer (Multi-Fallback Engine)
 */

$host = getenv('DB_HOST') ?: '127.0.0.1';
$db   = getenv('DB_NAME') ?: 'nxtgen';
$user = getenv('DB_USER') ?: 'app_user';
$pass = getenv('DB_PASS') ?: 'nxtgen_secure_app_pass_2026';

$pdo = null;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// Attempt 1: Connect via TCP 127.0.0.1 using app_user
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, $options);
} catch (PDOException $e1) {
    // Attempt 2: Connect via Unix Socket / localhost using app_user
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=$db;charset=utf8mb4", $user, $pass, $options);
    } catch (PDOException $e2) {
        // Attempt 3: Connect via root account on local machine
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=$db;charset=utf8mb4", "root", "", $options);
        } catch (PDOException $e3) {
            // Attempt 4: Connect via 127.0.0.1 root account
            try {
                $pdo = new PDO("mysql:host=127.0.0.1;dbname=$db;charset=utf8mb4", "root", "", $options);
            } catch (PDOException $e4) {
                error_log("NxtGen DB Connection Failed: " . $e4->getMessage());
                $pdo = null;
            }
        }
    }
}
