# NxtGen Enterprise Security Architecture & Technical Documentation
**Target OS:** Kali Linux / Native Linux Deployment  
**System Architecture:** Production-Grade Hardened Web Infrastructure  
**Author:** NxtGen Enterprise Security Engineering Team  

---

## 1. Executive Summary & Architecture Overview

The **NxtGen Enterprise Security Platform** is a multi-tiered, zero-trust web application architecture designed to run natively on Kali Linux. Moving away from standard unhardened web setups, NxtGen implements a **Defense-in-Depth** model combining network-level firewalls, web application firewalls (WAF), rate-limiting zones, intrusion prevention systems (IPS), hardened PHP-FPM backend, and database least-privilege isolation.

```
                   [ INCOMING TRAFFIC / CLIENT ]
                                 │
                                 ▼
                     [ 1. UFW Host Firewall ]
                  (Filter Ports: 80, 443, 8080, 22)
                                 │
                                 ▼
                    [ 2. Nginx Reverse Proxy ]
               (TLS 1.3, Rate-Limiting, JSON Logging)
                                 │
                                 ▼
                  [ 3. ModSecurity v3 WAF Engine ]
          (OWASP Core Rule Set 3.3 + NxtGen Custom Rules)
                                 │
                 ┌───────────────┴───────────────┐
                 │                               │
       [ Attack / Malicious ]         [ Clean Request ]
                 │                               │
                 ▼                               ▼
       (HTTP 403 / 429 Block)        [ 4. PHP-FPM Backend Engine ]
      & Logged to Audit Log            (PHP 8.x Socket Worker)
                                                 │
                                                 ▼
                                     [ 5. MariaDB Hardened DB ]
                                     (Least-Privilege Isolation)
```

---

## 2. Complete Technical Flow & Request Lifecycle

| Phase | Component | Technical Operation | Security Enforcement |
| :--- | :--- | :--- | :--- |
| **Phase 1** | **Network Perimeter** | Packet inspection on port 80/443/8080 via **UFW** | Drops unauthorized port scanning, raw SYN floods, and unrouted TCP requests. |
| **Phase 2** | **Nginx Proxy Gatekeeper** | Receives TCP traffic, terminates TLS 1.3, applies Security Headers | Strips server tokens (`server_tokens off`), sets HSTS, CSP, X-Frame-Options, X-Content-Type-Options. |
| **Phase 3** | **ModSecurity v3 Engine** | Deep Inspection of HTTP Method, Headers, URI, Query Params, Payload | Evaluates requests against OWASP CRS 3.3 and custom enterprise rules (IDs 100001–100007). |
| **Phase 4** | **Rate Limiting & IPS** | Checks IP frequency against Nginx Shared Memory Zones & **Fail2Ban** | Limits logins to 5 req/min, signups to 3 req/min. Bans repeating offenders via iptables. |
| **Phase 5** | **PHP-FPM Worker** | Executes non-root PHP workers via Unix Socket `/run/php/php-fpm.sock` | Enforces `session.cookie_httponly`, `session.cookie_samesite=Strict`, and input sanitization. |
| **Phase 6** | **MariaDB Database** | Receives SQL queries executed through **PDO Prepared Statements** | Prevents SQL Injection (SQLi) at the database layer; uses isolated user `app_user`. |

---

## 3. Firewall & Web Security Features Deep Dive

### A. Web Application Firewall (ModSecurity v3 + OWASP CRS)
* **Rule Engine:** ModSecurity v3 native connector compiled into Nginx.
* **OWASP Core Rule Set (CRS 3.3):** Full protection against OWASP Top 10 vulnerabilities, including:
  * **SQL Injection (SQLi):** Detection of boolean-based, time-based, union-based, and error-based payloads.
  * **Cross-Site Scripting (XSS):** Blocking script injection, reflected XSS, and DOM-based vectors.
  * **Remote File Inclusion (RFI) & LFI:** Blocking path traversal (`../`, `%2e%2e`) and external resource fetching.
* **NxtGen Custom Enterprise Rules (`custom-rules.conf`):**
  * **Rule 100001:** Denies access to sensitive backup extensions (`.bak`, `.old`, `.zip`, `.sql`, `.env`, `.config`).
  * **Rule 100002:** Restricts access to internal database scripts (`/includes/`, `/init-db.sql`, `db.php`).
  * **Rule 100003:** Blocks unauthenticated enumeration on `/admin/`.
  * **Rule 100004:** Blocks automated reconnaissance tools (`sqlmap`, `nikto`, `gobuster`, `dirbuster`, `nmap`, `wpscan`).
  * **Rule 100005:** Path Traversal blocking on URI parameters (`severity: CRITICAL`).
  * **Rule 100006:** Blocks HTTP TRACE, TRACK, CONNECT debugging methods.

### B. Intrusion Prevention & Rate Limiting (Fail2Ban & Nginx)
* **Login Protection:** 5 requests/minute (`zone=login_limit`).
* **Signup Protection:** 3 requests/minute (`zone=signup_limit`).
* **Reset Protection:** 2 requests/minute (`zone=reset_limit`).
* **Fail2Ban Jails:** Automatically bans malicious IPs triggering repeated 401/403/429 HTTP status codes for 10 minutes.

### C. Database Security & Account Hardening (MariaDB)
* **Least-Privilege Isolation:**
  * `app_user`: DML privileges (`SELECT`, `INSERT`, `UPDATE`, `DELETE`) on `nxtgen` database only.
  * `readonly`: Read-only reporting user for SIEM/telemetry.
  * `db_admin`: Restricted administrative user for scheduled migrations.
* **Native PDO Prepared Statements:** All PHP database queries use parameterized SQL execution, neutralizing SQL Injection.
* **BCRYPT Hashing:** User passwords stored with BCRYPT work factor 10. Plaintext hashes are upgraded automatically upon authentication.

### D. HTTP Security Headers Policy
```nginx
Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
X-Frame-Options "DENY"
X-Content-Type-Options "nosniff"
X-XSS-Protection "1; mode=block"
Referrer-Policy "strict-origin-when-cross-origin"
Permissions-Policy "camera=(), microphone=(), geolocation=()"
Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net;"
```

---

## 4. Operational Commands & Testing Matrix

### Starting & Checking Services
```bash
# Execute automated installation & deployment
sudo bash setup-kali.sh

# Check status of Nginx, PHP-FPM, and MariaDB
sudo systemctl status nginx mariadb php8.4-fpm
```

### Security Audit Log Paths
* **ModSecurity WAF Block Logs:** `/var/log/modsecurity/modsec_audit.log`
* **Nginx Access Traffic Logs:** `/var/log/nginx/access.log`
* **Nginx Error & Rate Limit Logs:** `/var/log/nginx/error.log`

### WAF Verification Commands
```bash
# 1. Test Automated Scanner Blocking (sqlmap UA) -> Expect HTTP 403
curl -i -A "sqlmap/1.5#stable" http://127.0.0.1:8080/

# 2. Test Path Traversal Prevention -> Expect HTTP 403
curl -i "http://127.0.0.1:8080/index.php?file=../../../../etc/passwd"

# 3. Test Restricted Backup Access -> Expect HTTP 403 / 404
curl -i http://127.0.0.1:8080/admin/config.bak
```

---

## 5. How to Convert This Document to PDF

You can convert this technical documentation into a PDF file on your Kali Linux system using any of the following methods:

### Method 1: Using Pandoc (Command Line in Kali)
```bash
# Install pandoc & pdflatex
sudo apt-get install -y pandoc texlive-latex-base

# Convert Markdown to PDF
pandoc DOCUMENTATION.md -o NxtGen_Security_Architecture.pdf
```

### Method 2: Using Firefox / Chrome (Print to PDF)
1. Open `DOCUMENTATION.md` in Firefox or VS Code.
2. Press **`Ctrl + P`** (Print).
3. Select **"Save to PDF"** and click **Save**.

### Method 3: Using LibreOffice Writer
```bash
libreoffice DOCUMENTATION.md &
```
Then select **File $\rightarrow$ Export As $\rightarrow$ Export as PDF**.
