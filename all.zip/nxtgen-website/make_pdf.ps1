$edgePath = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if (-not (Test-Path $edgePath)) {
    $edgePath = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
}

$pdfPath = "e:\nxtgen-websitee\nxtgen-website\nxtgen-website\NxtGen_Enterprise_Security_Architecture.pdf"
$htmlPath = "file:///e:/nxtgen-websitee/nxtgen-website/nxtgen-website/NxtGen_Security_Architecture.html"

Start-Process -FilePath $edgePath -ArgumentList "--headless", "--disable-gpu", "--print-to-pdf=`"$pdfPath`"", "`"$htmlPath`"" -Wait
Write-Host "PDF generated successfully at $pdfPath"
