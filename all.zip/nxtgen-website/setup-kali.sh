#!/bin/bash
# ====================================================================
# NxtGen Enterprise - Localhost 8080 Automated Kali Installer
# Target OS: Kali Linux / Debian / Ubuntu
# ====================================================================

set -e

# Color Helpers
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}====================================================================${NC}"
echo -e "${BLUE}    NxtGen Localhost Server Automated Installer (Port 8080)        ${NC}"
echo -e "${BLUE}====================================================================${NC}"

# Check for root privilege
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR] Please run this installer with root privileges (sudo bash setup-kali.sh).${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEB_ROOT="/var/www/nxtgen"

echo -e "\n${YELLOW}[1/5] Installing and updating system dependencies...${NC}"
apt-get update --fix-missing || true
dpkg --configure -a || true
apt-get --fix-broken install -y || true

DEBIAN_FRONTEND=noninteractive apt-get install -y --fix-missing \
  nginx \
  php-fpm \
  php-mysql \
  mariadb-server \
  curl

echo -e "${GREEN}[✔] Packages installed successfully.${NC}"

echo -e "\n${YELLOW}[2/5] Deploying NxtGen Application Code to ${WEB_ROOT}...${NC}"
rm -rf "${WEB_ROOT}"
mkdir -p "${WEB_ROOT}"
cp -r "${SCRIPT_DIR}/app/"* "${WEB_ROOT}/"

# Set strict permissions
chown -R www-data:www-data "${WEB_ROOT}"
find "${WEB_ROOT}" -type d -exec chmod 755 {} \;
find "${WEB_ROOT}" -type f -exec chmod 644 {} \;

echo -e "${GREEN}[✔] Web application files deployed with www-data permissions.${NC}"

echo -e "\n${YELLOW}[3/5] Initializing MariaDB Database & Accounts...${NC}"
systemctl enable --now mariadb

# Import initial database schema & permissions
mariadb -u root < "${SCRIPT_DIR}/database/init-db.sql" 2>/dev/null || true

echo -e "${GREEN}[✔] MariaDB database initialized with admin / admin123 account.${NC}"

echo -e "\n${YELLOW}[4/5] Deploying Nginx Configuration (Listening on Port 8080)...${NC}"
mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled /etc/nginx/conf.d /var/log/nginx

# Clean up stale Nginx processes and PID locks
pkill -9 nginx 2>/dev/null || true
rm -f /run/nginx.pid
rm -f /etc/nginx/sites-enabled/* /etc/nginx/conf.d/*

# Deploy Nginx core config & site config
cp "${SCRIPT_DIR}/infrastructure/nginx/nginx.conf" /etc/nginx/nginx.conf
cp "${SCRIPT_DIR}/infrastructure/nginx/sites-available/nxtgen.conf" /etc/nginx/sites-available/nxtgen.conf

# Activate nxtgen site
ln -sf /etc/nginx/sites-available/nxtgen.conf /etc/nginx/sites-enabled/nxtgen.conf

# Detect active PHP-FPM service name and restart it
PHP_SVC=$(systemctl list-unit-files | grep -E "php[0-9.]*-fpm" | head -n1 | awk '{print $1}')
if [ -n "$PHP_SVC" ]; then
  systemctl restart "$PHP_SVC"
  systemctl enable "$PHP_SVC"
fi

# Validate Nginx syntax before starting
echo "Testing Nginx Configuration..."
nginx -t || {
  echo -e "${RED}[ERROR] Nginx syntax check failed. Output details above.${NC}"
  exit 1
}

# Start Nginx service cleanly
systemctl restart mariadb || true
systemctl restart nginx || service nginx restart

echo -e "${GREEN}[✔] Nginx and MariaDB services active on Port 8080.${NC}"

echo -e "\n${YELLOW}[5/5] Testing Localhost Port 8080 Connection...${NC}"
sleep 2

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/ || true)
echo -e "  [Test] Localhost HTTP Port 8080 Response: HTTP ${HTTP_CODE}"

echo -e "\n${BLUE}====================================================================${NC}"
echo -e "${GREEN}🎉 NxtGen Web Application Successfully Running on Localhost 8080!${NC}"
echo -e "${BLUE}====================================================================${NC}"
echo -e "🌐 Main Application URL: ${YELLOW}http://127.0.0.1:8080/${NC} or ${YELLOW}http://localhost:8080/${NC}"
echo -e "🔑 Sign-In Page:        ${YELLOW}http://127.0.0.1:8080/login.php${NC}"
echo -e "🛡️ Admin Restricted:    ${YELLOW}http://127.0.0.1:8080/admin/${NC}"
echo -e "👤 Credentials:         Username: ${YELLOW}admin${NC} | Password: ${YELLOW}admin123${NC}"
echo -e "${BLUE}====================================================================${NC}\n"
