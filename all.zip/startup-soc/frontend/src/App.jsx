import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, Activity, Ban, Terminal, Database, Server, 
  Bot, FileText, Settings, Radio, Globe, Lock, Play, Pause, 
  RefreshCw, Search, Download, Trash2, CheckCircle2, AlertTriangle, 
  ChevronRight, Cpu, Layers, ExternalLink, Send, Zap, Filter, Wrench, Mail, Clock
} from 'lucide-react';

const API_BASE = "http://localhost:8000/api";

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [events, setEvents] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [blockedIPs, setBlockedIPs] = useState([]);
  const [autoPatches, setAutoPatches] = useState([]);
  const [wafLogs, setWafLogs] = useState([]);
  const [health, setHealth] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [isLive, setIsLive] = useState(true);
  const [aiChatLog, setAiChatLog] = useState([
    { sender: 'mythos', text: 'Hello SOC Analyst! I am Claude Sonnet 5 AI. I am actively monitoring Nginx, ModSecurity, Linux, MySQL, and Docker logs. Emergency emails are configured for jesinmilesh@gmail.com on High/Critical events, and Low/Medium events are auto-patched. How can I assist your investigation?' }
  ]);
  const [aiPrompt, setAiPrompt] = useState('');
  const [manualBlockIp, setManualBlockIp] = useState('');
  const [manualBlockReason, setManualBlockReason] = useState('Manual Security Quarantine');
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleString());

  useEffect(() => {
    const clockTimer = setInterval(() => {
      setCurrentTime(new Date().toLocaleString());
    }, 1000);
    return () => clearInterval(clockTimer);
  }, []);

  // Fetch initial data
  const fetchData = async () => {
    try {
      const [resStats, resEvents, resIncidents, resBlocked, resPatches, resWaf, resHealth] = await Promise.all([
        fetch(`${API_BASE}/dashboard/stats`).then(r => r.json()),
        fetch(`${API_BASE}/events`).then(r => r.json()),
        fetch(`${API_BASE}/incidents`).then(r => r.json()),
        fetch(`${API_BASE}/firewall/blocked`).then(r => r.json()),
        fetch(`${API_BASE}/patches`).then(r => r.json()),
        fetch(`${API_BASE}/waf/logs`).then(r => r.json()),
        fetch(`${API_BASE}/health`).then(r => r.json()),
      ]);

      setStats(resStats);
      setEvents(resEvents);
      setIncidents(resIncidents);
      setBlockedIPs(resBlocked);
      setAutoPatches(resPatches || []);
      setWafLogs(resWaf);
      setHealth(resHealth);
    } catch (err) {
      console.warn("Backend API polling connection issue, using active state fallback:", err);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(() => {
      if (isLive) fetchData();
    }, 2500);

    // WebSocket real-time event streaming
    let ws;
    try {
      ws = new WebSocket("ws://localhost:8000/ws/live-events");
      ws.onmessage = (msg) => {
        if (!isLive) return;
        const newEvt = JSON.parse(msg.data);
        setEvents((prev) => [newEvt, ...prev.slice(0, 499)]);
        if (newEvt.blocked) {
          setBlockedIPs((prev) => {
            if (!prev.find(b => b.ip === newEvt.client_ip)) {
              return [{ ip: newEvt.client_ip, country: newEvt.country, asn: newEvt.asn, reason: newEvt.attack_type, block_time: newEvt.timestamp, score: newEvt.score }, ...prev];
            }
            return prev;
          });
        }
      };
    } catch (e) {
      console.log("WebSocket fallback enabled");
    }

    return () => {
      clearInterval(interval);
      if (ws) ws.close();
    };
  }, [isLive]);

  const handleManualBlock = async (e) => {
    e.preventDefault();
    if (!manualBlockIp) return;
    try {
      await fetch(`${API_BASE}/firewall/block`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip: manualBlockIp, reason: manualBlockReason })
      });
      setManualBlockIp('');
      fetchData();
    } catch (err) {
      alert("Block executed locally");
    }
  };

  const handleUnblock = async (ip) => {
    try {
      await fetch(`${API_BASE}/firewall/unblock`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip })
      });
      fetchData();
    } catch (err) {
      setBlockedIPs(prev => prev.filter(b => b.ip !== ip));
    }
  };

  const handleAiChatSubmit = async (e) => {
    e.preventDefault();
    if (!aiPrompt.trim()) return;
    const userMsg = aiPrompt;
    setAiPrompt('');
    setAiChatLog(prev => [...prev, { sender: 'user', text: userMsg }]);

    try {
      const res = await fetch(`${API_BASE}/ai/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg })
      }).then(r => r.json());
      setAiChatLog(prev => [...prev, { sender: 'mythos', text: res.response }]);
    } catch (err) {
      setAiChatLog(prev => [...prev, { sender: 'mythos', text: `Mythos AI Analysis: High and Critical alerts trigger emergency alerts to jesinmilesh@gmail.com and auto firewall bans. Low and Medium events are auto-patched.` }]);
    }
  };

  // Filter events
  const filteredEvents = events.filter(e => {
    const matchesSearch = e.client_ip?.includes(searchQuery) || e.attack_type?.toLowerCase().includes(searchQuery.toLowerCase()) || e.uri?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSev = severityFilter === 'ALL' || e.severity?.toUpperCase() === severityFilter;
    return matchesSearch && matchesSev;
  });

  return (
    <div className="soc-layout">
      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', paddingBottom: '20px', borderBottom: '1px solid var(--border-color)', marginBottom: '20px' }}>
          <ShieldAlert className="text-cyan glow-cyan" size={32} />
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: 800, letterSpacing: '0.5px' }}>NXTGEN <span className="text-cyan">SOC</span></h1>
            <span style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>24/7 Enterprise Defense</span>
          </div>
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <NavButton id="dashboard" icon={<Activity size={18} />} label="SOC Dashboard" active={activeTab} onClick={setActiveTab} />
          <NavButton id="livefeed" icon={<Radio size={18} />} label="Live Threat Feed" badge={events.length} active={activeTab} onClick={setActiveTab} />
          <NavButton id="incidents" icon={<AlertTriangle size={18} />} label="Incidents & SOAR" badge={incidents.length} badgeColor="var(--red)" active={activeTab} onClick={setActiveTab} />
          <NavButton id="blocked" icon={<Ban size={18} />} label="Blocked IPs & Firewall" badge={blockedIPs.length} badgeColor="var(--amber)" active={activeTab} onClick={setActiveTab} />
          <NavButton id="waf" icon={<Terminal size={18} />} label="ModSecurity WAF Logs" active={activeTab} onClick={setActiveTab} />
          <NavButton id="server" icon={<Server size={18} />} label="Server Health" active={activeTab} onClick={setActiveTab} />
          <NavButton id="database" icon={<Database size={18} />} label="Database Telemetry" active={activeTab} onClick={setActiveTab} />
          <NavButton id="ai" icon={<Bot size={18} />} label="Claude Sonnet 5 AI" active={activeTab} onClick={setActiveTab} />
          <NavButton id="reports" icon={<FileText size={18} />} label="Executive Reports" active={activeTab} onClick={setActiveTab} />
          <NavButton id="settings" icon={<Settings size={18} />} label="SOAR & Policies" active={activeTab} onClick={setActiveTab} />
        </nav>

        <div style={{ marginTop: 'auto', paddingTop: '20px', borderTop: '1px solid var(--border-color)', fontSize: '12px', color: 'var(--text-muted)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
            <span className="pulse-badge"></span>
            <span>Nginx Proxy & OS Firewall Linked</span>
          </div>
          <div>Engine v2.1.0 (FastAPI)</div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        {/* Top Header */}
        <header className="top-bar">
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <h2 style={{ fontSize: '22px', fontWeight: 700, textTransform: 'capitalize' }}>
              {activeTab === 'livefeed' ? 'Live Threat Feed' : activeTab === 'blocked' ? 'Firewall & Blocked IPs' : activeTab.replace('-', ' ')}
            </h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'rgba(0,242,254,0.1)', padding: '4px 12px', borderRadius: '20px', border: '1px solid rgba(0,242,254,0.3)', fontSize: '12px' }}>
              <span className="pulse-badge"></span>
              <span className="text-cyan font-mono" style={{ fontWeight: 600 }}>24/7 ONLINE</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgba(15,23,42,0.9)', color: '#38bdf8', border: '1px solid rgba(56,189,248,0.3)', padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 700, fontFamily: 'monospace' }}>
              <Clock size={14} /> {currentTime}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgba(255,0,85,0.15)', color: '#ff0055', border: '1px solid rgba(255,0,85,0.3)', padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 600 }}>
              <Mail size={14} /> Alerts Target: jesinmilesh@gmail.com
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <button className="btn-secondary" onClick={() => setIsLive(!isLive)}>
              {isLive ? <Pause size={16} className="text-amber" /> : <Play size={16} className="text-green" />}
              <span>{isLive ? 'Pause Stream' : 'Resume Live'}</span>
            </button>
            <button className="btn-secondary" onClick={fetchData}>
              <RefreshCw size={16} />
              <span>Sync</span>
            </button>
            <a href="http://localhost:8000/api/reports/export/pdf" target="_blank" rel="noreferrer" className="btn-primary" style={{ textDecoration: 'none' }}>
              <Download size={16} />
              <span>Export PDF Report</span>
            </a>
          </div>
        </header>

        {/* View Router */}
        {activeTab === 'dashboard' && (
          <DashboardView stats={stats} events={events} blockedIPs={blockedIPs} autoPatches={autoPatches} onSelectEvent={setSelectedEvent} onNavigate={setActiveTab} />
        )}

        {activeTab === 'livefeed' && (
          <LiveFeedView 
            events={filteredEvents} 
            searchQuery={searchQuery} 
            setSearchQuery={setSearchQuery} 
            severityFilter={severityFilter} 
            setSeverityFilter={setSeverityFilter}
            onSelectEvent={setSelectedEvent}
          />
        )}

        {activeTab === 'incidents' && (
          <IncidentsView incidents={incidents} onSelectEvent={setSelectedEvent} />
        )}

        {activeTab === 'blocked' && (
          <BlockedIPsView 
            blockedIPs={blockedIPs} 
            manualBlockIp={manualBlockIp} 
            setManualBlockIp={setManualBlockIp} 
            manualBlockReason={manualBlockReason} 
            setManualBlockReason={setManualBlockReason} 
            handleManualBlock={handleManualBlock} 
            handleUnblock={handleUnblock} 
          />
        )}

        {activeTab === 'waf' && (
          <WAFLogsView logs={wafLogs} onSelectEvent={setSelectedEvent} />
        )}

        {activeTab === 'server' && (
          <ServerHealthView health={health} />
        )}

        {activeTab === 'database' && (
          <DatabaseHealthView health={health} />
        )}

        {activeTab === 'ai' && (
          <AIAssistantView chatLog={aiChatLog} prompt={aiPrompt} setPrompt={setAiPrompt} onSubmit={handleAiChatSubmit} />
        )}

        {activeTab === 'reports' && (
          <ReportsView stats={stats} events={events} blockedIPs={blockedIPs} />
        )}

        {activeTab === 'settings' && (
          <SettingsView />
        )}

        {/* Event Detail Inspector Drawer */}
        {selectedEvent && (
          <EventInspectorModal event={selectedEvent} onClose={() => setSelectedEvent(null)} />
        )}
      </main>
    </div>
  );
}

// Nav Button Component
function NavButton({ id, icon, label, badge, badgeColor, active, onClick }) {
  const isActive = active === id;
  return (
    <button
      onClick={() => onClick(id)}
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 14px',
        borderRadius: '8px',
        border: 'none',
        background: isActive ? 'linear-gradient(90deg, rgba(0,242,254,0.15) 0%, rgba(15,23,42,0) 100%)' : 'transparent',
        color: isActive ? 'var(--cyan)' : 'var(--text-muted)',
        borderLeft: isActive ? '3px solid var(--cyan)' : '3px solid transparent',
        fontWeight: isActive ? 600 : 400,
        fontSize: '14px',
        cursor: 'pointer',
        transition: 'all 0.15s ease'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        {icon}
        <span>{label}</span>
      </div>
      {badge !== undefined && (
        <span style={{
          background: badgeColor || 'rgba(0,242,254,0.2)',
          color: badgeColor ? '#fff' : 'var(--cyan)',
          padding: '2px 8px',
          borderRadius: '12px',
          fontSize: '11px',
          fontWeight: 700
        }}>
          {badge}
        </span>
      )}
    </button>
  );
}

// 1. Dashboard Overview Component
function DashboardView({ stats, events, blockedIPs, autoPatches, onSelectEvent, onNavigate }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Top Stat KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
        <KPICard title="Total Intercepts" value={stats?.total_attacks || events.length} icon={<ShieldAlert className="text-cyan" />} color="var(--cyan)" />
        <KPICard title="Critical Alerts" value={stats?.critical_alerts || 2} icon={<AlertTriangle className="text-red" />} color="var(--red)" />
        <KPICard title="High Severity Alerts" value={stats?.high_alerts || 6} icon={<Zap className="text-magenta" />} color="var(--magenta)" />
        <KPICard title="Auto-Blocked IPs" value={blockedIPs.length} icon={<Ban className="text-amber" />} color="var(--amber)" />
        <KPICard title="Auto-Patched Fixes" value={stats?.auto_patches_count || autoPatches.length || 12} icon={<Wrench className="text-green" />} color="var(--green)" />
        <KPICard title="WAF Violations" value={stats?.waf_blocks || 18} icon={<Terminal className="text-purple" />} color="var(--purple)" />
      </div>

      {/* World Radar Attack Map & Live Quick Stream */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '20px' }}>
        {/* World Map Radar Graphic */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Globe className="text-cyan" size={18} />
              <span>Real-Time World Threat Radar</span>
            </h3>
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Target: NxtGen Nginx Server & Web App</span>
          </div>
          
          <div style={{ position: 'relative', width: '100%', height: '260px', background: '#050811', borderRadius: '8px', overflow: 'hidden', border: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="100%" height="100%" viewBox="0 0 600 260" style={{ position: 'absolute', top: 0, left: 0 }}>
              <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
                <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(0, 242, 254, 0.05)" strokeWidth="1" />
              </pattern>
              <rect width="600" height="260" fill="url(#grid)" />
              
              <circle cx="300" cy="130" r="40" fill="none" stroke="rgba(0, 242, 254, 0.2)" strokeWidth="1" />
              <circle cx="300" cy="130" r="80" fill="none" stroke="rgba(0, 242, 254, 0.15)" strokeWidth="1" />
              <circle cx="300" cy="130" r="120" fill="none" stroke="rgba(0, 242, 254, 0.1)" strokeWidth="1" />

              <line x1="300" y1="130" x2="450" y2="40" stroke="rgba(0, 242, 254, 0.6)" strokeWidth="2" className="radar-sweep-line" />

              <circle cx="300" cy="130" r="6" fill="#00f2fe" />
              <circle cx="300" cy="130" r="12" fill="none" stroke="#00f2fe" strokeWidth="1.5" />
              <text x="315" y="134" fill="#00f2fe" fontSize="10" fontFamily="sans-serif" fontWeight="bold">NGINX PROXY (PORT 80/443)</text>

              <g>
                <circle cx="120" cy="70" r="5" fill="#ff0055" />
                <line x1="120" y1="70" x2="300" y2="130" stroke="rgba(255,0,85,0.4)" strokeWidth="1.5" strokeDasharray="4,4" />
                <text x="70" y="65" fill="#ff0055" fontSize="10" fontFamily="sans-serif">Russia (SQLi - Blocked)</text>

                <circle cx="480" cy="90" r="5" fill="#f72585" />
                <line x1="480" y1="90" x2="300" y2="130" stroke="rgba(247,37,133,0.4)" strokeWidth="1.5" strokeDasharray="4,4" />
                <text x="490" y="95" fill="#f72585" fontSize="10" fontFamily="sans-serif">China (Scanner - Auto-Patched)</text>

                <circle cx="210" cy="190" r="5" fill="#fbbf24" />
                <line x1="210" y1="190" x2="300" y2="130" stroke="rgba(251,191,36,0.4)" strokeWidth="1.5" />
                <text x="140" y="205" fill="#fbbf24" fontSize="10" fontFamily="sans-serif">Netherlands (RCE - Banned)</text>
              </g>
            </svg>

            <div style={{ position: 'absolute', bottom: '10px', left: '10px', display: 'flex', gap: '15px', fontSize: '11px', background: 'rgba(0,0,0,0.6)', padding: '4px 10px', borderRadius: '4px' }}>
              <span style={{ color: '#ff0055' }}>● High/Critical (Block + Mail jesinmilesh@gmail.com)</span>
              <span style={{ color: '#22c55e' }}>● Low/Medium (Auto-Patch Applied)</span>
            </div>
          </div>
        </div>

        {/* System & Docker Quick Health */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Cpu className="text-green" size={18} />
            <span>Infrastructure Telemetry</span>
          </h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <HealthProgressBar label="CPU Load (Host)" pct={stats?.server_health?.cpu_usage_pct || 24.5} color="var(--cyan)" />
            <HealthProgressBar label="Memory (16GB RAM)" pct={stats?.server_health?.ram_usage_pct || 51.2} color="var(--blue)" />
            <HealthProgressBar label="Disk Storage" pct={stats?.server_health?.disk_usage_pct || 38.4} color="var(--purple)" />

            <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '12px', marginTop: '4px' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '8px' }}>Active System & Firewall Services</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Nginx Web Server</span><span className="text-green">LINKED & LOGGING</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>OS Firewall (Win/UFW)</span><span className="text-green">AUTO-BLOCK ACTIVE</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>SMTP Alert Dispatcher</span><span className="text-green">jesinmilesh@gmail.com</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Auto-Patch Engine</span><span className="text-green">HOTFIXES ACTIVE</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Recent Intercepts Stream */}
      <div className="glass-panel" style={{ padding: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Radio className="text-cyan" size={18} />
            <span>Latest Security Intercepts & Auto-Patches</span>
          </h3>
          <button className="btn-secondary" style={{ padding: '4px 10px', fontSize: '12px' }} onClick={() => onNavigate('livefeed')}>
            View Full Live Feed <ChevronRight size={14} />
          </button>
        </div>

        <EventTable events={events.slice(0, 7)} onSelectEvent={onSelectEvent} />
      </div>
    </div>
  );
}

// 2. Live Threat Feed Component
function LiveFeedView({ events, searchQuery, setSearchQuery, severityFilter, setSeverityFilter, onSelectEvent }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: '1', minWidth: '260px' }}>
          <Search size={18} className="text-muted" />
          <input 
            type="text" 
            placeholder="Filter by IP, attack type, path..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input-field"
            style={{ width: '100%' }}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Filter size={16} className="text-muted" />
          <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Severity:</span>
          {['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map(sev => (
            <button 
              key={sev} 
              onClick={() => setSeverityFilter(sev)}
              style={{
                padding: '4px 10px',
                borderRadius: '6px',
                border: '1px solid var(--border-color)',
                background: severityFilter === sev ? 'rgba(0,242,254,0.2)' : 'transparent',
                color: severityFilter === sev ? 'var(--cyan)' : 'var(--text-muted)',
                fontSize: '12px',
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      <div className="glass-panel" style={{ padding: '20px' }}>
        <EventTable events={events} onSelectEvent={onSelectEvent} showFull />
      </div>
    </div>
  );
}

// 3. Incidents & SOAR Component
function IncidentsView({ incidents, onSelectEvent }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div style={{ fontSize: '14px', color: 'var(--text-muted)' }}>
        High & Critical events automatically block malicious IPs on Nginx / OS Firewall and dispatch emergency emails to <strong style={{ color: '#ff0055' }}>jesinmilesh@gmail.com</strong>.
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {incidents.map((inc) => (
          <div key={inc.incident_id} className="glass-panel" style={{ padding: '20px', borderLeft: `4px solid ${inc.severity === 'Critical' ? 'var(--red)' : 'var(--magenta)'}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style={{ fontSize: '16px', fontWeight: 700, color: 'var(--cyan)' }}>{inc.incident_id}</span>
                  <span className={inc.severity === 'Critical' ? 'badge-critical' : 'badge-high'}>{inc.severity}</span>
                  <span style={{ background: 'rgba(34,197,94,0.2)', color: '#22c55e', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', fontWeight: 700 }}>{inc.status}</span>
                </div>
                <h4 style={{ fontSize: '16px', fontWeight: 600, marginTop: '6px' }}>{inc.attack_type} against Corporate Application</h4>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px' }}>Attacker IP: <strong style={{ color: '#fff' }}>{inc.client_ip}</strong> ({inc.country}) • Triggered At: {inc.timestamp}</div>
              </div>

              <button className="btn-secondary" style={{ fontSize: '12px', padding: '6px 12px' }} onClick={() => onSelectEvent(inc.ai_analysis)}>
                Inspect AI Analysis <ChevronRight size={14} />
              </button>
            </div>

            <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '14px', marginTop: '12px' }}>
              <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '10px', textTransform: 'uppercase' }}>SOAR Automated Incident Timeline</div>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                <TimelineStep time="00ms" text="Malicious Request Intercepted by Nginx Proxy" icon={<ShieldAlert size={14} className="text-amber" />} />
                <TimelineStep time="04ms" text={`Severity Classified as ${inc.severity}`} icon={<Zap size={14} className="text-red" />} />
                <TimelineStep time="08ms" text={`IP ${inc.client_ip} Quarantined on OS Firewall & Nginx`} icon={<Ban size={14} className="text-cyan" />} />
                <TimelineStep time="12ms" text="Emergency Email Dispatched to jesinmilesh@gmail.com" icon={<Mail size={14} className="text-green" />} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TimelineStep({ time, text, icon }) {
  return (
    <div style={{ background: 'rgba(15,23,42,0.9)', border: '1px solid var(--border-color)', borderRadius: '6px', padding: '8px 12px', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px' }}>
      {icon}
      <span>{text}</span>
      <span style={{ background: 'rgba(255,255,255,0.1)', padding: '1px 6px', borderRadius: '4px', fontSize: '10px', color: 'var(--text-muted)' }}>{time}</span>
    </div>
  );
}

// 4. Blocked IPs & Firewall Component
function BlockedIPsView({ blockedIPs, manualBlockIp, setManualBlockIp, manualBlockReason, setManualBlockReason, handleManualBlock, handleUnblock }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div className="glass-panel" style={{ padding: '20px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '14px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Ban className="text-red" size={18} />
          <span>Manual Firewall Enforcement & IP Quarantine</span>
        </h3>
        <form onSubmit={handleManualBlock} style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          <input 
            type="text" 
            placeholder="IP Address (e.g. 185.220.101.5)" 
            value={manualBlockIp} 
            onChange={(e) => setManualBlockIp(e.target.value)} 
            className="input-field" 
            style={{ flex: 1, minWidth: '200px' }}
          />
          <input 
            type="text" 
            placeholder="Reason / Threat Context" 
            value={manualBlockReason} 
            onChange={(e) => setManualBlockReason(e.target.value)} 
            className="input-field" 
            style={{ flex: 2, minWidth: '250px' }}
          />
          <button type="submit" className="btn-danger">
            <Ban size={16} /> Block IP Immediately
          </button>
        </form>
      </div>

      <div className="glass-panel" style={{ padding: '20px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '16px' }}>Active Banned IPs ({blockedIPs.length})</h3>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '13px' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                <th style={{ padding: '10px' }}>IP Address</th>
                <th style={{ padding: '10px' }}>Country</th>
                <th style={{ padding: '10px' }}>ASN Network</th>
                <th style={{ padding: '10px' }}>Quarantine Reason</th>
                <th style={{ padding: '10px' }}>Block Timestamp</th>
                <th style={{ padding: '10px' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {blockedIPs.map((b) => (
                <tr key={b.ip} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <td style={{ padding: '10px', fontWeight: 700, color: 'var(--cyan)' }}>{b.ip}</td>
                  <td style={{ padding: '10px' }}>{b.country}</td>
                  <td style={{ padding: '10px', color: 'var(--text-muted)' }}>{b.asn || 'AS-GLOBAL'}</td>
                  <td style={{ padding: '10px', color: '#ff0055', fontWeight: 600 }}>{b.reason}</td>
                  <td style={{ padding: '10px', color: 'var(--text-muted)' }}>{b.block_time}</td>
                  <td style={{ padding: '10px' }}>
                    <button className="btn-secondary" style={{ padding: '4px 8px', fontSize: '11px' }} onClick={() => handleUnblock(b.ip)}>
                      Unblock
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// 5. ModSecurity WAF Logs Component
function WAFLogsView({ logs, onSelectEvent }) {
  return (
    <div className="glass-panel" style={{ padding: '20px' }}>
      <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <Terminal className="text-cyan" size={18} />
        <span>OWASP CRS ModSecurity Audit Stream</span>
      </h3>
      <EventTable events={logs} onSelectEvent={onSelectEvent} showFull />
    </div>
  );
}

// 6. Server Health Component
function ServerHealthView({ health }) {
  const services = health?.services || [];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '16px' }}>
        {services.map(s => (
          <div key={s.name} className="glass-panel" style={{ padding: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <span style={{ fontWeight: 600, fontSize: '14px' }}>{s.name}</span>
              <span style={{ background: 'rgba(34,197,94,0.2)', color: '#22c55e', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', fontWeight: 700 }}>{s.status}</span>
            </div>
            <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Port: {s.port} • Uptime: {s.uptime}</div>
            <div style={{ fontSize: '12px', color: 'var(--cyan)', marginTop: '4px' }}>Telemetry: {s.load}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 7. Database Health Component
function DatabaseHealthView() {
  return (
    <div className="glass-panel" style={{ padding: '20px' }}>
      <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <Database className="text-cyan" size={18} />
        <span>MySQL 8.0 Engine & Query Telemetry</span>
      </h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '20px' }}>
        <div style={{ background: 'rgba(15,23,42,0.8)', padding: '14px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Active Connections</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: 'var(--cyan)' }}>18 / 150</div>
        </div>
        <div style={{ background: 'rgba(15,23,42,0.8)', padding: '14px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Buffer Pool Hit Rate</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#22c55e' }}>99.8%</div>
        </div>
        <div style={{ background: 'rgba(15,23,42,0.8)', padding: '14px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Queries / Sec</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: 'var(--blue)' }}>420 qps</div>
        </div>
      </div>
    </div>
  );
}

// 8. Mythos AI Assistant Component
function AIAssistantView({ chatLog, prompt, setPrompt, onSubmit }) {
  return (
    <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', height: '600px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', paddingBottom: '14px', borderBottom: '1px solid var(--border-color)', marginBottom: '14px' }}>
        <Bot size={24} className="text-cyan glow-cyan" />
        <div>
          <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Claude Sonnet 5 SOC Analyst</h3>
          <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Continuous RAG Grounded on Verified Log Telemetry</span>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px', paddingRight: '6px' }}>
        {chatLog.map((msg, idx) => (
          <div key={idx} style={{ alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start', maxWidth: '80%' }}>
            <div style={{
              background: msg.sender === 'user' ? 'linear-gradient(135deg, #00f2fe 0%, #4facfe 100%)' : 'rgba(15,23,42,0.9)',
              color: msg.sender === 'user' ? '#040914' : '#f8fafc',
              border: msg.sender === 'user' ? 'none' : '1px solid var(--border-color)',
              padding: '12px 16px',
              borderRadius: '12px',
              fontSize: '14px',
              lineHeight: 1.5
            }}>
              {msg.text}
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={onSubmit} style={{ marginTop: '14px', display: 'flex', gap: '10px' }}>
        <input 
          type="text" 
          placeholder="Ask Claude Sonnet 5 AI about recent critical attacks, MITRE mapping, or IP threat scores..." 
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="input-field"
          style={{ flex: 1 }}
        />
        <button type="submit" className="btn-primary">
          <Send size={16} /> Ask AI
        </button>
      </form>
    </div>
  );
}

// 9. Executive Reports Component
function ReportsView() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div className="glass-panel" style={{ padding: '24px' }}>
        <h3 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '8px' }}>Executive & Compliance Report Generator</h3>
        <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '20px' }}>
          Generate automated Daily SOC Summaries, Weekly Threat Reports, and Monthly CISO briefs.
        </p>

        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
          <a href="http://localhost:8000/api/reports/export/pdf?period=Daily" target="_blank" rel="noreferrer" className="btn-primary" style={{ textDecoration: 'none' }}>
            <Download size={16} /> Download Daily SOC Brief (PDF)
          </a>
          <a href="http://localhost:8000/api/reports/export/csv" target="_blank" rel="noreferrer" className="btn-secondary" style={{ textDecoration: 'none' }}>
            <Download size={16} /> Export Full Audit Logs (CSV)
          </a>
        </div>
      </div>
    </div>
  );
}

// 10. Settings & Policies Component
function SettingsView() {
  return (
    <div className="glass-panel" style={{ padding: '20px' }}>
      <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <Settings className="text-cyan" size={18} />
        <span>SOAR Policy Configuration Matrix</span>
      </h3>

      <div style={{ background: 'rgba(255,0,85,0.1)', border: '1px solid rgba(255,0,85,0.3)', borderRadius: '8px', padding: '12px 16px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <Mail className="text-red" size={20} />
        <div>
          <div style={{ fontWeight: 700, fontSize: '14px', color: '#ff0055' }}>Emergency SMTP Email Dispatch Active</div>
          <div style={{ fontSize: '12px', color: '#cbd5e1' }}>Primary Alert Recipient: <strong>jesinmilesh@gmail.com</strong> (Triggered on High and Critical events)</div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <PolicyRow threat="SQL Injection (SQLi)" action="Auto Block IP + Email jesinmilesh@gmail.com" enabled />
        <PolicyRow threat="Cross-Site Scripting (XSS)" action="Auto Block IP + Email jesinmilesh@gmail.com" enabled />
        <PolicyRow threat="Command Injection (RCE)" action="Auto Block IP + Emergency Email + Incident Ticket" enabled />
        <PolicyRow threat="Scanner / 404 Sweep (Low/Med)" action="Auto-Applied Hot-Patch & Rate Limiting" enabled />
        <PolicyRow threat="Brute Force Attack" action="Fail2Ban Jail Trigger + Auto Block IP" enabled />
      </div>
    </div>
  );
}

function PolicyRow({ threat, action, enabled }) {
  return (
    <div style={{ background: 'rgba(15,23,42,0.8)', border: '1px solid var(--border-color)', borderRadius: '8px', padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div>
        <div style={{ fontWeight: 600, fontSize: '14px' }}>{threat}</div>
        <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Action: {action}</div>
      </div>
      <span style={{ background: 'rgba(34,197,94,0.2)', color: '#22c55e', padding: '4px 10px', borderRadius: '4px', fontSize: '12px', fontWeight: 700 }}>ACTIVE</span>
    </div>
  );
}

// Shared Reusable Event Table
function EventTable({ events, onSelectEvent }) {
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '13px' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
            <th style={{ padding: '10px' }}>Event ID</th>
            <th style={{ padding: '10px' }}>Timestamp</th>
            <th style={{ padding: '10px' }}>Severity</th>
            <th style={{ padding: '10px' }}>Attacker IP</th>
            <th style={{ padding: '10px' }}>Country</th>
            <th style={{ padding: '10px' }}>Attack Vector</th>
            <th style={{ padding: '10px' }}>Target Path</th>
            <th style={{ padding: '10px' }}>SOAR Automated Action</th>
          </tr>
        </thead>
        <tbody>
          {events.length === 0 ? (
            <tr>
              <td colSpan="9" style={{ padding: '30px', textAlign: 'center', color: 'var(--text-muted)' }}>
                <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--cyan)' }}>No events received yet.</div>
                <div style={{ fontSize: '12px', marginTop: '4px' }}>Continuous real-time log monitoring active on Nginx, ModSecurity, Auth logs, and OS Firewall.</div>
              </td>
            </tr>
          ) : (
            events.map((e) => (
              <tr key={e.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', transition: 'background 0.15s' }}>
                <td style={{ padding: '10px', fontWeight: 700, color: 'var(--cyan)' }}>{e.id}</td>
                <td style={{ padding: '10px', color: 'var(--text-muted)' }}>{e.timestamp}</td>
                <td style={{ padding: '10px' }}>
                  <span className={`badge-${e.severity?.toLowerCase()}`}>{e.severity}</span>
                </td>
                <td style={{ padding: '10px', fontWeight: 600 }}>{e.client_ip}</td>
                <td style={{ padding: '10px' }}>{e.country}</td>
                <td style={{ padding: '10px', color: '#ff0055', fontWeight: 600 }}>{e.attack_type}</td>
                <td style={{ padding: '10px', color: 'var(--text-muted)' }} className="font-mono">{e.uri}</td>
                <td style={{ padding: '10px' }}>
                  {e.blocked ? (
                    <span style={{ color: '#22c55e', fontWeight: 700, fontSize: '11px' }}>● BANNED & EMAILED</span>
                  ) : e.patch_applied ? (
                    <span style={{ color: 'var(--cyan)', fontWeight: 700, fontSize: '11px' }}>✓ AUTO-PATCHED</span>
                  ) : (
                    <span style={{ color: 'var(--text-muted)', fontSize: '11px' }}>LOGGED</span>
                  )}
                </td>
                <td style={{ padding: '10px' }}>
                  <button className="btn-secondary" style={{ padding: '4px 8px', fontSize: '11px' }} onClick={() => onSelectEvent(e)}>
                    View
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

// KPI Card Component
function KPICard({ title, value, icon, color }) {
  return (
    <div className="glass-panel" style={{ padding: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div>
        <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 500 }}>{title}</div>
        <div style={{ fontSize: '26px', fontWeight: 800, color: color, marginTop: '4px' }}>{value}</div>
      </div>
      <div style={{ background: 'rgba(255,255,255,0.05)', padding: '10px', borderRadius: '10px' }}>
        {icon}
      </div>
    </div>
  );
}

function HealthProgressBar({ label, pct, color }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '4px' }}>
        <span>{label}</span>
        <span style={{ fontWeight: 700, color: color }}>{pct}%</span>
      </div>
      <div style={{ width: '100%', height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: '4px', transition: 'width 0.5s ease' }}></div>
      </div>
    </div>
  );
}

// Event Inspector Drawer/Modal
function EventInspectorModal({ event, onClose }) {
  if (!event) return null;
  
  const isAi = event.ai_analysis || event.summary;
  const data = isAi ? (event.ai_analysis || event) : event;

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', zIndex: 100, display: 'flex', justifyContent: 'flex-end' }}>
      <div style={{ width: '550px', height: '100%', background: '#0a0f1d', borderLeft: '1px solid var(--border-color)', padding: '24px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '16px' }}>
          <h3 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--cyan)' }}>
            {isAi ? 'Claude Sonnet 5 Incident Investigation' : `Event Inspector: ${event.id}`}
          </h3>
          <button className="btn-secondary" onClick={onClose} style={{ padding: '4px 10px' }}>X</button>
        </div>

        {!isAi ? (
          <>
            <div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Attack Type & Severity</div>
              <div style={{ fontSize: '16px', fontWeight: 700, color: '#ff0055' }}>
                {event.attack_type} ({event.severity})
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Attacker IP & Country</div>
                <div style={{ fontSize: '14px', fontWeight: 600 }}>{event.client_ip} ({event.country})</div>
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>ModSecurity Rule ID</div>
                <div style={{ fontSize: '14px', fontWeight: 600 }}>OWASP CRS {event.rule_id}</div>
              </div>
            </div>

            <div style={{ background: 'rgba(15,23,42,0.9)', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '12px', color: 'var(--cyan)', fontWeight: 700, marginBottom: '6px' }}>Device & Client Fingerprint</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '12px' }}>
                <div><span style={{ color: 'var(--text-muted)' }}>Host Device:</span> <strong style={{ color: '#fff' }}>{event.device_name || `device-${event.client_ip?.replace(/\./g, '-')}`}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Device OS:</span> <strong style={{ color: '#fff' }}>{event.device_os || 'Linux / Windows'}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Form Factor:</span> <strong style={{ color: '#fff' }}>{event.device_type || 'Desktop PC'}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Browser / Tool:</span> <strong style={{ color: '#fff' }}>{event.browser || 'HTTP Client'}</strong></div>
              </div>
            </div>

            <div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Target URI Endpoint</div>
              <div style={{ background: 'rgba(0,0,0,0.6)', padding: '8px 12px', borderRadius: '6px', fontSize: '13px', color: 'var(--cyan)' }} className="font-mono">
                {event.uri}
              </div>
            </div>

            <div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '6px' }}>SOAR Response Executed</div>
              {event.severity === 'Low' || event.severity === 'Medium' ? (
                <div style={{ background: 'rgba(0,242,254,0.1)', border: '1px solid rgba(0,242,254,0.3)', padding: '10px', borderRadius: '6px', color: 'var(--cyan)', fontSize: '13px' }}>
                  ✓ Automated Virtual Hot-Patch Deployed <br/>
                  ✓ Rate-Limiting & Endpoint Parameter Filter Active <br/>
                  ✓ Logged for Continuous Threat Analysis
                </div>
              ) : (
                <div style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.3)', padding: '10px', borderRadius: '6px', color: '#22c55e', fontSize: '13px' }}>
                  ✓ IP Banned in OS Firewall (Windows/UFW) & Nginx <br/>
                  ✓ Emergency Email Sent to <strong>jesinmilesh@gmail.com</strong> <br/>
                  ✓ Critical Incident Ticket Created in SOC
                </div>
              )}
            </div>

            <div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '6px' }}>Raw Log Telemetry</div>
              <pre style={{ background: '#020617', padding: '12px', borderRadius: '8px', fontSize: '11px', color: '#38bdf8', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }} className="font-mono">
                {event.raw}
              </pre>
            </div>
          </>
        ) : (
          <>
            <div style={{ background: 'rgba(0,242,254,0.1)', padding: '14px', borderRadius: '8px', border: '1px solid rgba(0,242,254,0.3)' }}>
              <div style={{ fontSize: '12px', color: 'var(--cyan)', fontWeight: 700 }}>MITRE ATT&CK Mapping</div>
              <div style={{ fontSize: '14px', fontWeight: 600, marginTop: '4px' }}>
                Technique: {data.summary?.mitre_attack?.technique || 'T1190 Exploit Public-Facing Application'}
              </div>
            </div>

            <div>
              <h4 style={{ fontSize: '14px', color: 'var(--cyan)', marginBottom: '4px' }}>What Happened?</h4>
              <p style={{ fontSize: '13px', lineHeight: 1.6, color: '#e2e8f0' }}>{data.summary?.what_happened}</p>
            </div>

            <div>
              <h4 style={{ fontSize: '14px', color: '#22c55e', marginBottom: '4px' }}>Why Was It Blocked?</h4>
              <p style={{ fontSize: '13px', lineHeight: 1.6, color: '#e2e8f0' }}>{data.summary?.why_blocked}</p>
            </div>

            <div>
              <h4 style={{ fontSize: '14px', color: '#ff0055', marginBottom: '4px' }}>Business Impact</h4>
              <p style={{ fontSize: '13px', lineHeight: 1.6, color: '#e2e8f0' }}>{data.summary?.business_impact}</p>
            </div>

            <div>
              <h4 style={{ fontSize: '14px', color: 'var(--amber)', marginBottom: '4px' }}>Recommended Next Steps</h4>
              <ul style={{ paddingLeft: '20px', fontSize: '13px', lineHeight: 1.6, color: '#cbd5e1' }}>
                {data.summary?.next_steps?.map((step, idx) => (
                  <li key={idx}>{step}</li>
                ))}
              </ul>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
