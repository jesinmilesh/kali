"""
Detection Rules for OWASP CRS, SQLi, XSS, RCE, Path Traversal, Brute Force, Scanner Detection
"""
import re

DETECTION_RULES = [
    {
        "id": "RULE-SQLI-001",
        "name": "SQL Injection Pattern (OWASP 942100)",
        "pattern": r"(?i)(union\s+select|select\s+.*\s+from|insert\s+into|delete\s+from|drop\s+table|or\s+1=1|\bOR\b\s+['\"].*['\"]=)",
        "attack_type": "SQL Injection (SQLi)",
        "default_score": 8
    },
    {
        "id": "RULE-XSS-002",
        "name": "Cross-Site Scripting (OWASP 941100)",
        "pattern": r"(?i)(<script.*?>|javascript:|onload=|onerror=|document\.cookie|alert\(|eval\()",
        "attack_type": "Cross-Site Scripting (XSS)",
        "default_score": 8
    },
    {
        "id": "RULE-RCE-003",
        "name": "Command Injection (OWASP 932100)",
        "pattern": r"(?i)(;\s*cat\s+/etc/passwd|;\s*id\b|;\s*whoami|;\s*wget\b|;\s*curl\b|`.*`|\$\(.*\))",
        "attack_type": "Command Injection (RCE)",
        "default_score": 10
    },
    {
        "id": "RULE-TRAV-004",
        "name": "Path Traversal (OWASP 930100)",
        "pattern": r"(?i)(\.\./\.\./|%2e%2e%2f|/etc/passwd|/etc/shadow|/win.ini)",
        "attack_type": "Path Traversal",
        "default_score": 7
    },
    {
        "id": "RULE-SCAN-005",
        "name": "Vulnerability Scanner Detection",
        "pattern": r"(?i)(nikto|nmap|sqlmap|acunetix|nessus|dirbuster|gobuster|wpscan)",
        "attack_type": "Scanner Detection",
        "default_score": 4
    }
]

def inspect_payload(payload: str) -> dict:
    for rule in DETECTION_RULES:
        if re.search(rule["pattern"], payload):
            return {
                "matched": True,
                "rule_id": rule["id"],
                "rule_name": rule["name"],
                "attack_type": rule["attack_type"],
                "score": rule["default_score"]
            }
    return {"matched": False}
