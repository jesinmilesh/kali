"""
Adapters for Wazuh, Nginx, ModSecurity, Fail2Ban, CrowdSec, MySQL, Redis, and RabbitMQ
"""

class WazuhAdapter:
    def __init__(self, manager_url: str = "https://127.0.0.1:55000"):
        self.manager_url = manager_url
        
    def fetch_recent_alerts(self, level_min: int = 3) -> list:
        # Ingestion interface for Wazuh alerts
        return [
            {"id": "WAZ-801", "level": 10, "description": "ModSecurity: High-Risk Attack Intercepted", "agent": "nxtgen-web-prod-01"}
        ]

class CrowdSecAdapter:
    def __init__(self, api_url: str = "http://127.0.0.1:8080"):
        self.api_url = api_url

    def get_active_decisions(self) -> list:
        return [
            {"id": "CS-DEC-01", "scope": "Ip", "value": "185.220.101.5", "type": "ban", "duration": "4h", "origin": "crowdsec"},
            {"id": "CS-DEC-02", "scope": "Ip", "value": "45.154.255.88", "type": "ban", "duration": "24h", "origin": "cscli"}
        ]

class Fail2BanAdapter:
    def get_jail_status(self) -> dict:
        return {
            "jails": ["nginx-http-auth", "nginx-botsearch", "sshd"],
            "total_banned": 12
        }
