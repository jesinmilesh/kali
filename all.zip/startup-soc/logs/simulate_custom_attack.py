"""
Custom Attack Dispatcher for Manual SOC Testing.
Allows testing custom URLs, payloads, and IPs to verify real-time detection in the SOC Dashboard.
"""
import sys
import json
import urllib.request

API_URL = "http://127.0.0.1:8000/api/ingest/nginx"

def send_attack(attack_type: str, uri: str, payload: str, client_ip: str = "185.220.101.99", user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"):
    body = {
        "client_ip": client_ip,
        "method": "POST" if payload else "GET",
        "uri": uri,
        "user_agent": user_agent,
        "payload": payload
    }
    
    req = urllib.request.Request(API_URL, data=json.dumps(body).encode('utf-8'), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req) as res:
            data = json.loads(res.read().decode('utf-8'))
            print(f"\n[+] Ingested Attack: {attack_type}")
            print(f"    - Endpoint: {uri}")
            print(f"    - Client IP: {client_ip}")
            print(f"    - Severity: {data['event']['severity']} (Score: {data['event']['score']})")
            print(f"    - Blocked: {data['event']['blocked']}")
            print(f"    - Email Sent to jesinmilesh@gmail.com: {data['event']['email_sent']}")
    except Exception as e:
        print(f"[!] Error: {e}")

if __name__ == "__main__":
    print("Sending test attacks...")
    send_attack("SQL Injection", "/login.php", "username=admin' OR 1=1 --", client_ip="198.51.100.77")
    send_attack("Command Injection (RCE)", "/admin/system.php?cmd=id;", "id;", client_ip="193.142.146.88")
