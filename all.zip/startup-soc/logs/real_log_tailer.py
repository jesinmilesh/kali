"""
Real Production Server Log Tailer.
Connects directly to real log files on the host system:
  - Nginx: /var/log/nginx/access.log, /var/log/nginx/error.log
  - ModSecurity: /var/log/modsecurity/audit.log
  - Linux Auth: /var/log/auth.log, /var/log/syslog
  - MySQL: /var/log/mysql/error.log

No synthetic or fake data is generated. If no log entries are present, zero events are reported.
"""
import os
import time
import asyncio
from datetime import datetime, timezone
from typing import Callable, List, Optional
from soc_engine.log_parser import LogParser

class RealLogTailer:
    """
    Monitors and tails real production server log files on Linux or Windows environments.
    """
    def __init__(self, log_paths: Optional[List[str]] = None):
        default_paths = [
            "/var/log/nginx/access.log",
            "/var/log/nginx/error.log",
            "/var/log/modsecurity/audit.log",
            "/var/log/auth.log",
            "/var/log/mysql/error.log",
            os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "logs", "nginx_access.log")),
            os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "logs", "modsec_audit.log")),
            os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "logs", "auth.log"))
        ]
        self.log_paths = log_paths or default_paths
        self.parser = LogParser()
        self.file_handles = {}
        self._init_file_handles()

    def _init_file_handles(self):
        for path in self.log_paths:
            if os.path.exists(path):
                try:
                    f = open(path, "r", encoding="utf-8", errors="ignore")
                    f.seek(0, os.SEEK_END)
                    self.file_handles[path] = f
                except Exception:
                    pass

    def check_new_logs(self) -> List[dict]:
        """Checks for new unread lines in monitored log files."""
        events = []
        for path, f in list(self.file_handles.items()):
            try:
                while True:
                    line = f.readline()
                    if not line:
                        break
                    line_str = line.strip()
                    if line_str and not line_str.startswith("#"):
                        parsed = self.parser.parse_nginx_access(line_str)
                        if parsed:
                            events.append(parsed)
            except Exception:
                pass
        return events
