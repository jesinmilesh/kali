"""
Test Live Traffic & Attack Dispatcher.
Simulates real web requests to Nginx / FastAPI backend to verify:
 1. Low/Medium Severity -> Auto-Patch Applied
 2. High/Critical Severity -> IP Auto-Blocked on OS Firewall/Nginx + Email Alert Sent to jesinmilesh@gmail.com
"""
import urllib.request
import json
import time

API_URL = "http://127.0.0.1:8000/api/ingest/nginx"

test_cases = [
    {
        "client_ip": "198.51.100.44",
        "method": "GET",
        "uri": "/contact.php?search=nikto_scanner",
        "user_agent": "Nikto/2.1.6",
        "payload": "scan",
        "expected": "Low/Medium -> Auto-Patched"
    },
    {
        "client_ip": "185.220.101.99",
        "method": "POST",
        "uri": "/login.php",
        "user_agent": "Mozilla/5.0",
        "payload": "username=admin' OR 1=1 --&password=foo",
        "expected": "Critical -> Auto-Block IP + Email jesinmilesh@gmail.com"
    },
    {
        "client_ip": "193.142.146.77",
        "method": "GET",
        "uri": "/admin/exec.php?cmd=cat%20/etc/passwd;",
        "user_agent": "Curl/7.68.0",
        "payload": "cat /etc/passwd",
        "expected": "Critical -> Auto-Block IP + Email jesinmilesh@gmail.com"
    },
    {
        "client_ip": "203.0.113.15",
        "method": "GET",
        "uri": "/.env",
        "user_agent": "Python-urllib/3.9",
        "payload": "",
        "expected": "Medium -> Auto-Patched"
    }
]

def run_tests():
    print("==========================================================")
    print(" [*] TESTING LIVE NGINX TRAFFIC & AUTOMATED SOC RESPONSE")
    print("==========================================================")
    
    for case in test_cases:
        req_data = json.dumps(case).encode('utf-8')
        req = urllib.request.Request(API_URL, data=req_data, headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req) as response:
                res_body = json.loads(response.read().decode('utf-8'))
                evt = res_body.get("event", {})
                print(f"\n[+] Ingested Request from {case['client_ip']} -> {case['uri']}")
                print(f"    - Attack Vector: {evt.get('attack_type')}")
                print(f"    - Severity: {evt.get('severity')} (Score: {evt.get('score')})")
                print(f"    - Blocked: {evt.get('blocked')}")
                print(f"    - Email Dispatched: {evt.get('email_sent')} (Recipient: jesinmilesh@gmail.com)")
                print(f"    - Actions Taken: {evt.get('actions_taken')}")
        except Exception as e:
            print(f"[!] Error sending request: {e}")
        time.sleep(1)

if __name__ == "__main__":
    run_tests()
