import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from notifications.email_notifier import EmailNotifier

notifier = EmailNotifier()

test_event = {
    "id": "INC-CRITICAL-LIVE-99",
    "severity": "CRITICAL",
    "attack_type": "Command Injection (RCE) - Real Dispatch Test",
    "client_ip": "193.142.146.77",
    "country": "Netherlands",
    "uri": "/admin/exec.php?cmd=cat%20/etc/passwd",
    "rule_id": "CRS-932100",
    "raw": "193.142.146.77 - - [2026-08-23 02:43:00] \"GET /admin/exec.php?cmd=cat%20/etc/passwd HTTP/1.1\" 403 512 \"-\" \"Curl/7.68.0\""
}

print("Sending real email to jesinmilesh@gmail.com...")
result = notifier.send_emergency_alert(test_event)
print(f"Result: {result}")
