"""
Launcher script for Enterprise 24/7 Automated SOC Platform
Starts FastAPI backend server on port 8000 and Vite frontend on port 3000.
"""
import subprocess
import sys
import os
import time

def main():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    backend_dir = os.path.join(root_dir, "backend")
    frontend_dir = os.path.join(root_dir, "frontend")

    print("==========================================================")
    print(" 🛡️  STARTING ENTERPRISE 24/7 AUTOMATED SOC PLATFORM")
    print("==========================================================")
    print("SIEM | SOAR | WAF | Wazuh | CrowdSec | Mythos AI Assistant")
    print("----------------------------------------------------------")

    # Start FastAPI Backend
    print("[+] Launching FastAPI SOC Engine on http://localhost:8000 ...")
    backend_cmd = [sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
    backend_process = subprocess.Popen(backend_cmd, cwd=root_dir)

    time.sleep(2)

    # Launch Vite Frontend if node/npm is available
    print("[+] Launching React SOC Dashboard on http://localhost:3000 ...")
    try:
        frontend_process = subprocess.Popen(["npm.cmd" if os.name == 'nt' else "npm", "run", "dev"], cwd=frontend_dir)
        frontend_process.wait()
    except Exception as e:
        print(f"[*] Frontend node process error or closed: {e}")

    try:
        backend_process.wait()
    except KeyboardInterrupt:
        print("\n[!] Shutting down Enterprise SOC Platform...")
        backend_process.terminate()

if __name__ == "__main__":
    main()
