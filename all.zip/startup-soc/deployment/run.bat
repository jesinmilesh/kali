@echo off
echo ==========================================================
echo  🛡️ STARTING ENTERPRISE 24/7 AUTOMATED SOC PLATFORM
echo ==========================================================
cd /d "%~dp0\.."
py deployment\start_soc.py
pause
