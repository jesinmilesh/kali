#!/bin/bash
# ==============================================================================
# Enterprise 24/7 Automated SOC Platform — Kali Linux Automated Setup Script
# Target Recipient: jesinmilesh@gmail.com
# AI Engine: Claude Sonnet 5
# OS Target: Kali Linux / Debian / Ubuntu
# ==============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${CYAN}====================================================================${NC}"
echo -e "${CYAN}     🛡️  NXTGEN ENTERPRISE AUTOMATED SOC PLATFORM SETUP (KALI)      ${NC}"
echo -e "${CYAN}====================================================================${NC}"

# 1. Check Root Privileges (Required for UFW / iptables & Nginx log access)
if [ "$EUID" -ne 0 ]; then
  echo -e "${YELLOW}[!] Warning: Running without root privileges. Firewall auto-blocking features require sudo/root.${NC}"
fi

SOC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$SOC_DIR"

echo -e "\n${GREEN}[+] Step 1: Installing System & Language Dependencies...${NC}"
sudo apt-get update -y || true
sudo apt-get install -y python3 python3-pip python3-venv nodejs npm ufw nginx net-tools curl || true

# 2. Setup Python Virtual Environment & Dependencies
echo -e "\n${GREEN}[+] Step 2: Setting up Python Virtual Environment...${NC}"
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi

source venv/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn requests python-dotenv psutil pydantic websockets jinja2

# 3. Configure Credentials & Environment
echo -e "\n${GREEN}[+] Step 3: Configuring Credentials & SMTP Environment (.env)...${NC}"
cat << 'EOF' > .env
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=jesinmilesh@gmail.com
SMTP_PASSWORD=smavbwsgcsuuxybj
ALERT_EMAIL=jesinmilesh@gmail.com
EOF

echo -e "${GREEN}[✓] Credentials written to .env file.${NC}"

# 4. Setup React Frontend
echo -e "\n${GREEN}[+] Step 4: Building React SOC Dashboard Frontend...${NC}"
cd "$SOC_DIR/frontend"
npm install --legacy-peer-deps
npm run build
cd "$SOC_DIR"

# 5. Configure Nginx Log File Permissions
echo -e "\n${GREEN}[+] Step 5: Preparing Real Nginx & System Log Telemetry Paths...${NC}"
mkdir -p logs
touch logs/nginx_access.log logs/nginx_deny.conf
sudo chmod 644 logs/nginx_access.log || true

if [ -f "/var/log/nginx/access.log" ]; then
  sudo chmod 644 /var/log/nginx/access.log || true
fi

# 6. Launch Services
echo -e "\n${CYAN}====================================================================${NC}"
echo -e "${CYAN}            🚀 LAUNCHING 24/7 AUTOMATED SOC PLATFORM                ${NC}"
echo -e "${CYAN}====================================================================${NC}"

# Kill any existing processes on 8000 or 3000
fuser -k 8000/tcp 2>/dev/null || true
fuser -k 3000/tcp 2>/dev/null || true

# Start Backend in Background
echo -e "${GREEN}[+] Starting FastAPI SOC Backend Engine (Port 8000)...${NC}"
source venv/bin/activate
nohup python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 > logs/backend.log 2>&1 &
BACKEND_PID=$!
echo -e "${GREEN}[✓] FastAPI Backend running (PID: $BACKEND_PID)${NC}"

# Start Frontend Static Server in Background
echo -e "${GREEN}[+] Starting React SOC Dashboard Frontend (Port 3000)...${NC}"
cd "$SOC_DIR/frontend"
nohup npx -y serve -s dist -p 3000 > ../logs/frontend.log 2>&1 &
FRONTEND_PID=$!
cd "$SOC_DIR"
echo -e "${GREEN}[✓] React Frontend running (PID: $FRONTEND_PID)${NC}"

sleep 2

# 7. Print Access Information
echo -e "\n${GREEN}====================================================================${NC}"
echo -e "${GREEN}     🎉 KALI AUTOMATED SOC PLATFORM IS NOW ONLINE & MONITORING!     ${NC}"
echo -e "${GREEN}====================================================================${NC}"
echo -e " 🌐 ${CYAN}React SOC Dashboard:${NC}   http://localhost:3000"
echo -e " ⚡ ${CYAN}FastAPI Backend API:${NC}   http://localhost:8000"
echo -e " 🤖 ${CYAN}AI Triage Engine:${NC}      Claude Sonnet 5"
echo -e " 📧 ${CYAN}Emergency Alerts:${NC}      jesinmilesh@gmail.com (Real Gmail Dispatch Active)"
echo -e " 🛡️ ${CYAN}OS Firewall Blocking:${NC}  UFW / iptables & Nginx Deny Rules"
echo -e "${GREEN}====================================================================${NC}"

echo -e "\n${YELLOW}🧪 To test real-time attack detection & automated email dispatch, run:${NC}"
echo -e "   python3 logs/simulate_custom_attack.py"
echo -e "   python3 logs/test_live_attacks.py\n"
