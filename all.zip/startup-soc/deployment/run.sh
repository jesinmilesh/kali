#!/bin/bash
echo "=========================================================="
echo " 🛡️ STARTING ENTERPRISE 24/7 AUTOMATED SOC PLATFORM"
echo "=========================================================="
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR/.."
python3 deployment/start_soc.py
