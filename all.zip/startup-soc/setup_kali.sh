#!/bin/bash
# NxtGen Enterprise SOC Platform - Quick Kali Setup Launcher
chmod +x deployment/setup_kali_soc.sh
./deployment/setup_kali_soc.sh
