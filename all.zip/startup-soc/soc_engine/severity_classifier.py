"""
Severity Classifier for SOC Events
Scores security events on a 0 - 10 scale and assigns Low, Medium, High, or Critical.
"""

class SeverityClassifier:
    
    ATTACK_SCORE_MAP = {
        "Single 404": 2,
        "Scanner Detection": 3,
        "Suspicious User-Agent": 3,
        "Failed Login": 5,
        "Authentication Abuse": 6,
        "Admin Enumeration": 6,
        "Path Traversal": 7,
        "File Inclusion": 7,
        "Cross-Site Scripting (XSS)": 8,
        "SQL Injection (SQLi)": 8,
        "Brute Force Attack": 8,
        "Command Injection (RCE)": 10,
        "SSH Root Attack": 10,
        "Critical WAF Violation": 9,
    }

    ASSET_CRITICALITY_BOOST = {
        "/admin": 2,
        "/login.php": 1,
        "/dashboard.php": 1,
        "/api": 1,
        "/etc/passwd": 3,
        "/cmd.php": 3
    }

    @classmethod
    def classify(cls, attack_type: str, uri: str = "", frequency: int = 1, modsec_severity: str = "") -> dict:
        base_score = cls.ATTACK_SCORE_MAP.get(attack_type, 4)
        
        # Adjust for critical asset paths
        for path, boost in cls.ASSET_CRITICALITY_BOOST.items():
            if path in uri.lower():
                base_score += boost
                break

        # Adjust for high request frequency
        if frequency > 20:
            base_score += 2
        elif frequency > 5:
            base_score += 1

        # Adjust for WAF severity header if present
        if modsec_severity.upper() in ["CRITICAL", "EMERGENCY"]:
            base_score = max(base_score, 9)
        elif modsec_severity.upper() == "HIGH":
            base_score = max(base_score, 7)

        # Cap score between 0 and 10
        final_score = max(0, min(10, base_score))

        if final_score <= 3:
            severity = "Low"
            color = "#00f2fe" # Cyan/Blue
        elif final_score <= 6:
            severity = "Medium"
            color = "#ffb703" # Amber/Yellow
        elif final_score <= 8:
            severity = "High"
            color = "#f72585" # Magenta/Orange-Red
        else:
            severity = "Critical"
            color = "#ff0055" # Neon Red

        return {
            "score": final_score,
            "severity": severity,
            "color": color
        }
