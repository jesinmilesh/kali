from collections import defaultdict
import time
from typing import Dict, List

class CorrelationEngine:
    """
    Tracks state, frequency, and event sequences across client IPs to identify high-velocity attacks.
    """
    def __init__(self):
        self.ip_history = defaultdict(list)
        self.failed_logins = defaultdict(int)
        self.window_seconds = 60

    def add_event(self, client_ip: str, attack_type: str, uri: str) -> dict:
        now = time.time()
        # Clean old events
        self.ip_history[client_ip] = [e for e in self.ip_history[client_ip] if now - e["timestamp"] < self.window_seconds]
        
        event_record = {
            "timestamp": now,
            "attack_type": attack_type,
            "uri": uri
        }
        self.ip_history[client_ip].append(event_record)
        
        freq = len(self.ip_history[client_ip])
        correlated_attack = attack_type
        
        if attack_type == "Failed Login":
            self.failed_logins[client_ip] += 1
            if self.failed_logins[client_ip] >= 5:
                correlated_attack = "Brute Force Attack"
        elif freq > 15 and attack_type in ["Single 404", "Scanner Detection"]:
            correlated_attack = "Scanner Detection"
            
        return {
            "frequency": freq,
            "correlated_attack": correlated_attack,
            "history_count": freq
        }
