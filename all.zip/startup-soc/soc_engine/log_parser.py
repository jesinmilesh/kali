import re
import json
import socket
from datetime import datetime, timezone

class LogParser:
    """
    Parses and normalizes raw log messages from Nginx, ModSecurity, PHP,
    MySQL, Linux Syslog, Fail2Ban, CrowdSec, Docker, and SSH.
    Extracts deep device fingerprint details: Real IP, Device Hostname, OS, Browser, and Form Factor.
    """
    
    @staticmethod
    def parse_device_fingerprint(user_agent: str) -> dict:
        """Parses User-Agent string into Device Name, OS, Browser, and Category."""
        if not user_agent or user_agent == "-":
            return {
                "device_type": "Unknown Device",
                "os": "Unknown OS",
                "browser": "Unknown Client",
                "is_bot": False
            }
        
        ua = user_agent.lower()
        
        # 1. OS Fingerprint
        if "windows nt 10.0" in ua or "windows nt 11.0" in ua:
            os_name = "Windows 11 / 10"
        elif "windows nt 6.3" in ua or "windows nt 6.1" in ua:
            os_name = "Windows 7 / 8"
        elif "macintosh" in ua or "mac os x" in ua:
            os_name = "macOS"
        elif "android" in ua:
            os_name = "Android Mobile"
        elif "iphone" in ua or "ipad" in ua:
            os_name = "Apple iOS"
        elif "kali" in ua:
            os_name = "Kali Linux Security Suite"
        elif "ubuntu" in ua or "debian" in ua:
            os_name = "Linux (Ubuntu/Debian)"
        elif "linux" in ua:
            os_name = "Linux x86_64"
        else:
            os_name = "Embedded System / OS"

        # 2. Browser / Client Fingerprint
        if "nikto" in ua:
            browser_name = "Nikto Web Scanner"
        elif "sqlmap" in ua:
            browser_name = "SQLmap Automated Tool"
        elif "nmap" in ua or "masscan" in ua:
            browser_name = "Nmap Security Scanner"
        elif "curl" in ua:
            browser_name = "cURL Command CLI"
        elif "python" in ua or "requests" in ua:
            browser_name = "Python Automated Script"
        elif "chrome" in ua and "edg" not in ua:
            browser_name = "Google Chrome"
        elif "edg" in ua:
            browser_name = "Microsoft Edge"
        elif "firefox" in ua:
            browser_name = "Mozilla Firefox"
        elif "safari" in ua and "chrome" not in ua:
            browser_name = "Apple Safari"
        else:
            browser_name = "HTTP Client Software"

        # 3. Device Category
        if any(bot_tag in ua for bot_tag in ["nikto", "sqlmap", "nmap", "scanner", "bot", "python", "curl", "gobuster", "dirbuster"]):
            device_type = "Automated Security Bot / Scanner"
            is_bot = True
        elif "mobile" in ua or "android" in ua or "iphone" in ua:
            device_type = "Mobile Smartphone / Tablet"
            is_bot = False
        else:
            device_type = "Workstation / Desktop PC"
            is_bot = False

        return {
            "device_type": device_type,
            "os": os_name,
            "browser": browser_name,
            "is_bot": is_bot
        }

    @staticmethod
    def resolve_device_hostname(ip: str) -> str:
        """Performs Reverse DNS lookup to obtain actual network device hostname."""
        if not ip or ip in ["127.0.0.1", "0.0.0.0", "::1"]:
            return "localhost-node"
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return hostname
        except Exception:
            return f"device-{ip.replace('.', '-')}"

    @classmethod
    def parse_nginx_access(cls, line: str) -> dict:
        # Standard combined log format or custom JSON
        pattern = r'(?P<ip>[\d\.]+)\s+-\s+-\s+\[(?P<time>[^\]]+)\]\s+"(?P<method>\w+)\s+(?P<uri>\S+)\s+HTTP/[^"]+"\s+(?P<status>\d+)\s+(?P<bytes>\d+)\s+"(?P<referrer>[^"]*)"\s+"(?P<user_agent>[^"]*)"'
        match = re.match(pattern, line)
        if match:
            data = match.groupdict()
            client_ip = data["ip"]
            user_agent = data["user_agent"]
            device_fp = cls.parse_device_fingerprint(user_agent)
            device_host = cls.resolve_device_hostname(client_ip)

            return {
                "source": "nginx",
                "timestamp": data["time"],
                "client_ip": client_ip,
                "device_name": device_host,
                "device_os": device_fp["os"],
                "device_type": device_fp["device_type"],
                "browser": device_fp["browser"],
                "method": data["method"],
                "uri": data["uri"],
                "status_code": int(data["status"]),
                "user_agent": user_agent,
                "raw": line
            }
        return {"source": "nginx", "raw": line, "timestamp": datetime.now(timezone.utc).isoformat()}

    @classmethod
    def parse_modsecurity(cls, line: str) -> dict:
        rule_match = re.search(r'\[id "(?P<rule_id>\d+)"\]\s*\[msg "(?P<msg>[^"]+)"\]\s*\[severity "(?P<severity>[^"]+)"\]', line)
        ip_match = re.search(r'\[client (?P<ip>[\d\.]+)\]', line)
        uri_match = re.search(r'\[uri "(?P<uri>[^"]+)"\]', line)
        
        client_ip = ip_match.group("ip") if ip_match else "127.0.0.1"
        device_host = cls.resolve_device_hostname(client_ip)

        return {
            "source": "modsecurity",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "rule_id": rule_match.group("rule_id") if rule_match else "999999",
            "message": rule_match.group("msg") if rule_match else "WAF Rule Triggered",
            "waf_severity": rule_match.group("severity") if rule_match else "WARNING",
            "client_ip": client_ip,
            "device_name": device_host,
            "uri": uri_match.group("uri") if uri_match else "/",
            "raw": line
        }

    @classmethod
    def parse_fail2ban(cls, line: str) -> dict:
        match = re.search(r'(?P<time>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}).*?\[(?P<jail>\w+)\]\s+(?P<action>Ban|Unban|Found)\s+(?P<ip>[\d\.]+)', line)
        if match:
            d = match.groupdict()
            client_ip = d["ip"]
            device_host = cls.resolve_device_hostname(client_ip)
            return {
                "source": "fail2ban",
                "timestamp": d["time"],
                "jail": d["jail"],
                "action": d["action"],
                "client_ip": client_ip,
                "device_name": device_host,
                "raw": line
            }
        return {"source": "fail2ban", "raw": line, "timestamp": datetime.now(timezone.utc).isoformat()}

    @classmethod
    def parse_crowdsec(cls, line: str) -> dict:
        ip_match = re.search(r'ip:(?P<ip>[\d\.]+)', line)
        reason_match = re.search(r'reason:(?P<reason>[^\s,]+)', line)
        client_ip = ip_match.group("ip") if ip_match else "0.0.0.0"
        device_host = cls.resolve_device_hostname(client_ip)
        return {
            "source": "crowdsec",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "client_ip": client_ip,
            "device_name": device_host,
            "reason": reason_match.group("reason") if reason_match else "Reputation ban",
            "raw": line
        }

    @staticmethod
    def parse_generic(source: str, line: str) -> dict:
        return {
            "source": source,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "raw": line
        }
