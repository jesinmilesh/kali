"""
Nginx & Website Real-Time Log Monitor.
Tails Nginx access logs and ingests active web requests into the SOC Engine.
"""
import os
import time
import asyncio
from typing import Callable, Optional

class NginxLogMonitor:
    """
    Monitors Nginx access.log and error.log in real time and feeds events into the SOC Engine.
    """
    def __init__(self, log_path: Optional[str] = None):
        self.log_path = log_path or os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "logs", "nginx_access.log")
        )
        os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
        if not os.path.exists(self.log_path):
            with open(self.log_path, "w") as f:
                f.write("# NxtGen Enterprise Nginx Access Log Stream\n")

    def append_web_request(self, client_ip: str, method: str, uri: str, user_agent: str, status_code: int = 200) -> str:
        timestamp = time.strftime("%d/%b/%Y:%H:%M:%S +0000", time.gmtime())
        line = f'{client_ip} - - [{timestamp}] "{method} {uri} HTTP/1.1" {status_code} 1024 "-" "{user_agent}"'
        try:
            with open(self.log_path, "a") as f:
                f.write(line + "\n")
        except Exception:
            pass
        return line

    async def start_tailing(self, callback: Callable[[str], None]):
        """Asynchronously tails the log file for new entries."""
        try:
            with open(self.log_path, "r") as f:
                f.seek(0, os.SEEK_END)
                while True:
                    line = f.readline()
                    if line:
                        callback(line.strip())
                    else:
                        await asyncio.sleep(0.5)
        except Exception as e:
            print(f"[!] Log tailing error: {e}")
