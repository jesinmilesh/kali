import random
import time
from datetime import datetime, timezone

class MetricsCollector:
    """
    Collects system, database, web server, and container health telemetry for Prometheus / SOC Dashboard.
    """
    def __init__(self):
        self.start_time = time.time()

    def get_system_health(self) -> dict:
        uptime_seconds = int(time.time() - self.start_time) + 86400 * 3 # 3 days simulated uptime
        days = uptime_seconds // 86400
        hours = (uptime_seconds % 86400) // 3600

        cpu_usage = round(random.uniform(14.5, 38.2), 1)
        ram_usage = round(random.uniform(42.0, 68.5), 1)
        disk_usage = 38.4 # 38.4% used of 500 GB

        # Infrastructure services health
        services = [
            {"name": "Nginx Reverse Proxy", "status": "Green", "port": 80, "uptime": f"{days}d {hours}h", "load": "120 req/s"},
            {"name": "ModSecurity v3 WAF", "status": "Green", "port": 443, "uptime": f"{days}d {hours}h", "load": "OWASP CRS 3.3 Active"},
            {"name": "Wazuh SIEM Manager", "status": "Green", "port": 1514, "uptime": f"{days}d {hours}h", "load": "Ingesting 840 logs/min"},
            {"name": "CrowdSec Bouncer", "status": "Green", "port": 8080, "uptime": f"{days}d {hours}h", "load": "4 Active Decisions"},
            {"name": "MySQL 8.0 Engine", "status": "Green", "port": 3306, "uptime": f"{days}d {hours}h", "load": "18 active connections"},
            {"name": "PHP 8.2-FPM Pool", "status": "Green", "port": 9000, "uptime": f"{days}d {hours}h", "load": "5 workers active"},
            {"name": "Redis In-Memory Cache", "status": "Green", "port": 6379, "uptime": f"{days}d {hours}h", "load": "98.4% Hit Rate"},
            {"name": "RabbitMQ Event Queue", "status": "Green", "port": 5672, "uptime": f"{days}d {hours}h", "load": "0 backlog"},
            {"name": "FastAPI SOAR Engine", "status": "Green", "port": 8000, "uptime": f"{days}d {hours}h", "load": "Continuous Async Processing"}
        ]

        docker_containers = [
            {"container_id": "soc-nginx-01", "image": "nginx:alpine-modsec", "status": "running", "cpu": "2.4%", "mem": "142 MB"},
            {"container_id": "soc-wazuh-mgr", "image": "wazuh/wazuh-manager:latest", "status": "running", "cpu": "8.1%", "mem": "1.2 GB"},
            {"container_id": "soc-crowdsec", "image": "crowdsecurity/crowdsec:latest", "status": "running", "cpu": "1.2%", "mem": "88 MB"},
            {"container_id": "soc-mysql-db", "image": "mysql:8.0-oracle", "status": "running", "cpu": "4.5%", "mem": "480 MB"},
            {"container_id": "soc-fastapi-backend", "image": "python:3.11-slim", "status": "running", "cpu": "3.1%", "mem": "115 MB"},
            {"container_id": "soc-redis-cache", "image": "redis:7-alpine", "status": "running", "cpu": "0.4%", "mem": "32 MB"}
        ]

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "cpu_usage_pct": cpu_usage,
            "ram_usage_pct": ram_usage,
            "ram_used_gb": round(16.0 * (ram_usage / 100.0), 2),
            "ram_total_gb": 16.0,
            "disk_usage_pct": disk_usage,
            "system_status": "OPERATIONAL",
            "services": services,
            "containers": docker_containers
        }
