import os
import subprocess
from datetime import datetime, timezone
from typing import Dict, List, Optional

class FirewallManager:
    """
    Manages IP blocks, whitelists, and unblocks across OS Firewall (Windows Firewall / UFW)
    and Nginx reverse proxy configuration.
    """
    def __init__(self, nginx_deny_file: Optional[str] = None):
        self.blocked_ips: Dict[str, dict] = {}
        self.whitelist: set = {"127.0.0.1", "::1", "10.0.0.1", "192.168.1.100"}
        self.nginx_deny_file = nginx_deny_file or os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "logs", "nginx_deny.conf")
        )
        # Initialize empty blocked IPs dictionary for authentic real-time operation
        self._sync_nginx_config()

    def _sync_nginx_config(self):
        """Synchronizes blocked IPs to Nginx deny configuration file."""
        try:
            os.makedirs(os.path.dirname(self.nginx_deny_file), exist_ok=True)
            lines = [f"# NxtGen Automated SOC Firewall Deny Rules - Updated {datetime.now(timezone.utc).isoformat()}\n"]
            for ip in self.blocked_ips.keys():
                lines.append(f"deny {ip};\n")
            
            with open(self.nginx_deny_file, "w") as f:
                f.writelines(lines)
        except Exception as e:
            print(f"[!] Nginx config sync exception: {e}")

    def _apply_os_firewall_rule(self, ip: str, block: bool = True):
        """Executes OS level firewall commands (Windows Firewall or Linux UFW)."""
        try:
            if os.name == 'nt': # Windows
                rule_name = f"SOC_AUTO_BLOCK_{ip.replace('.', '_')}"
                if block:
                    cmd = f'netsh advfirewall firewall add rule name="{rule_name}" dir=in action=block remoteip={ip}'
                else:
                    cmd = f'netsh advfirewall firewall delete rule name="{rule_name}"'
                subprocess.run(cmd, shell=True, capture_output=True, timeout=2)
            else: # Linux
                if block:
                    cmd = f"ufw deny from {ip} to any"
                else:
                    cmd = f"ufw delete deny from {ip} to any"
                subprocess.run(cmd, shell=True, capture_output=True, timeout=2)
        except Exception:
            pass

    def is_whitelisted(self, ip: str) -> bool:
        return ip in self.whitelist

    def block_ip(self, ip: str, reason: str, country: str = "Unknown", asn: str = "AS-UNKNOWN", score: int = 8) -> bool:
        if self.is_whitelisted(ip):
            return False
            
        self.blocked_ips[ip] = {
            "ip": ip,
            "country": country,
            "asn": asn,
            "reason": reason,
            "block_time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
            "score": score
        }
        
        # Apply Nginx block configuration and OS Firewall rule
        self._sync_nginx_config()
        self._apply_os_firewall_rule(ip, block=True)
        return True

    def unblock_ip(self, ip: str) -> bool:
        if ip in self.blocked_ips:
            del self.blocked_ips[ip]
            self._sync_nginx_config()
            self._apply_os_firewall_rule(ip, block=False)
            return True
        return False

    def add_to_whitelist(self, ip: str) -> bool:
        self.whitelist.add(ip)
        if ip in self.blocked_ips:
            self.unblock_ip(ip)
        return True

    def remove_from_whitelist(self, ip: str) -> bool:
        if ip in self.whitelist:
            self.whitelist.remove(ip)
            return True
        return False

    def get_blocked_ips(self) -> List[dict]:
        return list(self.blocked_ips.values())

    def get_whitelist(self) -> List[str]:
        return list(self.whitelist)
