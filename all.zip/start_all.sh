#!/bin/bash
# Master Launcher for NxtGen Website + 24/7 SOC Platform
chmod +x setup_enterprise_soc_and_website.sh
./setup_enterprise_soc_and_website.sh
