#!/bin/bash
# ==============================================================================
# Master Unified Enterprise Setup Script: Website (8080) + SOC Dashboard (3000/8000)
# Target OS: Kali Linux / Debian / Ubuntu
# Target Recipient: jesinmilesh@gmail.com
# AI Engine: Claude Sonnet 5
# ==============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${CYAN}====================================================================${NC}"
echo -e "${CYAN}  🛡️  UNIFIED ENTERPRISE SETUP: NXTGEN WEBSITE + 24/7 SOC PLATFORM  ${NC}"
echo -e "${CYAN}====================================================================${NC}"

# Check for root privilege
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR] Please run this master setup script with root privileges:${NC}"
  echo -e "${YELLOW}        sudo ./setup_enterprise_soc_and_website.sh${NC}"
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEBSITE_DIR="${ROOT_DIR}/nxtgen-website"
SOC_DIR="${ROOT_DIR}/startup-soc"

# ------------------------------------------------------------------------------
# STEP 1: Install All Required System Dependencies
# ------------------------------------------------------------------------------
echo -e "\n${YELLOW}[1/6] Installing System Dependencies (Nginx, PHP-FPM, MariaDB, Python3, Node.js, UFW)...${NC}"
apt-get update --fix-missing || true
dpkg --configure -a || true
apt-get --fix-broken install -y || true

DEBIAN_FRONTEND=noninteractive apt-get install -y --fix-missing \
  nginx \
  php-fpm \
  php-mysql \
  mariadb-server \
  python3 \
  python3-pip \
  python3-venv \
  nodejs \
  npm \
  ufw \
  curl \
  net-tools \
  procps

echo -e "${GREEN}[✔] All core system packages successfully installed.${NC}"

# ------------------------------------------------------------------------------
# STEP 2: Deploy & Configure NxtGen Web Application on Port 8080
# ------------------------------------------------------------------------------
echo -e "\n${YELLOW}[2/6] Setting up NxtGen Production Website on Port 8080...${NC}"
WEB_ROOT="/var/www/nxtgen"
rm -rf "${WEB_ROOT}"
mkdir -p "${WEB_ROOT}"
cp -r "${WEBSITE_DIR}/app/"* "${WEB_ROOT}/"

chown -R www-data:www-data "${WEB_ROOT}"
find "${WEB_ROOT}" -type d -exec chmod 755 {} \;
find "${WEB_ROOT}" -type f -exec chmod 644 {} \;

systemctl enable --now mariadb || service mariadb start
mariadb -u root < "${WEBSITE_DIR}/database/init-db.sql" 2>/dev/null || true

mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled /etc/nginx/conf.d /var/log/nginx
pkill -9 nginx 2>/dev/null || true
rm -f /run/nginx.pid
rm -f /etc/nginx/sites-enabled/* /etc/nginx/conf.d/*

cp "${WEBSITE_DIR}/infrastructure/nginx/nginx.conf" /etc/nginx/nginx.conf
cp "${WEBSITE_DIR}/infrastructure/nginx/sites-available/nxtgen.conf" /etc/nginx/sites-available/nxtgen.conf
ln -sf /etc/nginx/sites-available/nxtgen.conf /etc/nginx/sites-enabled/nxtgen.conf

PHP_SVC=$(systemctl list-unit-files | grep -E "php[0-9.]*-fpm" | head -n1 | awk '{print $1}')
if [ -n "$PHP_SVC" ]; then
  systemctl restart "$PHP_SVC"
  systemctl enable "$PHP_SVC"
fi

nginx -t || {
  echo -e "${RED}[ERROR] Nginx syntax check failed.${NC}"
  exit 1
}

systemctl restart mariadb || service mariadb restart
systemctl restart nginx || service nginx restart

echo -e "${GREEN}[✔] NxtGen Web Application active on http://localhost:8080/${NC}"

# ------------------------------------------------------------------------------
# STEP 3: Setup Python Environment & Credentials for SOC Platform
# ------------------------------------------------------------------------------
echo -e "\n${YELLOW}[3/6] Configuring SOC Python Engine & Real Gmail Credentials...${NC}"
cd "${SOC_DIR}"

if [ ! -d "venv" ]; then
  python3 -m venv venv
fi

source venv/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn requests python-dotenv psutil pydantic websockets jinja2

cat << 'EOF' > .env
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=jesinmilesh@gmail.com
SMTP_PASSWORD=smavbwsgcsuuxybj
ALERT_EMAIL=jesinmilesh@gmail.com
EOF

echo -e "${GREEN}[✔] SMTP credentials written to .env for jesinmilesh@gmail.com.${NC}"

# ------------------------------------------------------------------------------
# STEP 4: Build React SOC Dashboard Frontend
# ------------------------------------------------------------------------------
echo -e "\n${YELLOW}[4/6] Building React SOC Dashboard Frontend...${NC}"
cd "${SOC_DIR}/frontend"
npm install --legacy-peer-deps
npm run build
cd "${SOC_DIR}"

# ------------------------------------------------------------------------------
# STEP 5: Prepare Nginx Telemetry & Log Monitoring
# ------------------------------------------------------------------------------
echo -e "\n${YELLOW}[5/6] Preparing Log Tailing Telemetry (/var/log/nginx/access.log)...${NC}"
mkdir -p logs
touch logs/nginx_access.log logs/nginx_deny.conf
chmod 666 /var/log/nginx/access.log 2>/dev/null || true
chmod 666 logs/nginx_access.log 2>/dev/null || true

# ------------------------------------------------------------------------------
# STEP 6: Launch All Services (Backend 8000 + Frontend 3000)
# ------------------------------------------------------------------------------
echo -e "\n${YELLOW}[6/6] Launching 24/7 SOC Backend & Dashboard Services...${NC}"

fuser -k 8000/tcp 2>/dev/null || true
fuser -k 3000/tcp 2>/dev/null || true

# Start Backend Engine
echo -e "${GREEN}[+] Starting FastAPI SOC Engine (Port 8000)...${NC}"
source venv/bin/activate
nohup python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 > logs/backend.log 2>&1 &
BACKEND_PID=$!

# Start Frontend Dashboard
echo -e "${GREEN}[+] Starting React SOC Dashboard (Port 3000)...${NC}"
cd "${SOC_DIR}/frontend"
nohup npx -y serve -s dist -p 3000 > ../logs/frontend.log 2>&1 &
FRONTEND_PID=$!
cd "${ROOT_DIR}"

sleep 2

# ------------------------------------------------------------------------------
# SUMMARY & ACCESS INFORMATION
# ------------------------------------------------------------------------------
echo -e "\n${BLUE}====================================================================${NC}"
echo -e "${GREEN}  🎉 MASTER ENTERPRISE STACK SUCCESSFULLY OPERATIONAL IN KALI!      ${NC}"
echo -e "${BLUE}====================================================================${NC}"
echo -e " 🌐 ${CYAN}NxtGen Production Website:${NC}   ${YELLOW}http://localhost:8080/${NC}"
echo -e " 🔑 ${CYAN}Website Admin Sign-In:${NC}       ${YELLOW}http://localhost:8080/login.php${NC} (admin / admin123)"
echo -e " 🖥️ ${CYAN}React SOC Dashboard:${NC}         ${YELLOW}http://localhost:3000/${NC}"
echo -e " ⚡ ${CYAN}FastAPI SOC Backend API:${NC}     ${YELLOW}http://localhost:8000/${NC}"
echo -e " 🤖 ${CYAN}AI Triage Assistant:${NC}         ${YELLOW}Claude Sonnet 5${NC}"
echo -e " 📧 ${CYAN}Emergency Alert Target:${NC}      ${YELLOW}jesinmilesh@gmail.com${NC}"
echo -e " 🛡️ ${CYAN}SOAR Automated Defense:${NC}       ${YELLOW}Active (UFW OS Firewall & Nginx Blocking)${NC}"
echo -e "${BLUE}====================================================================${NC}"

echo -e "\n${YELLOW}🧪 To send test attacks and watch them on the SOC Dashboard live, run:${NC}"
echo -e "   python3 startup-soc/logs/simulate_custom_attack.py"
echo -e "   python3 startup-soc/logs/test_live_attacks.py\n"
