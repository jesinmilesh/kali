# AetherForge Startup — WAF Defense Lab

Professional **fictional** company website + Nginx/ModSecurity/OWASP CRS firewall + attack & defense exercise.

No real personal or company data is used. Built only for local cybersecurity training on Kali.

---

## Architecture

```
[ Kali attacker tools ]
         |
    +----+----+
    |         |
 :8080      :8082
 Direct     WAF (ModSecurity + CRS)
    |         |
    +----> PHP site (AetherForge)
              |
           MariaDB
```

| Port | Role |
|------|------|
| **8080** | Website without WAF (Round 1 – attacks succeed) |
| **8082** | Same site behind WAF (Rounds 2 & 3) |

---

## Prerequisites (Kali)

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-v2 curl
sudo systemctl enable --now docker
sudo usermod -aG docker $USER   # then re-login or newgrp docker
```

Optional tools (usually already on Kali):

```bash
sudo apt install -y sqlmap gobuster
```

---

## Start the lab

```bash
cd startup-waf-lab
chmod +x scripts/*.sh
./scripts/start-lab.sh
```

Open:

- **http://127.0.0.1:8080** — full marketing site + login  
- **http://127.0.0.1:8082** — same site through the firewall  

Demo accounts (normal login):

| User     | Password     |
|----------|--------------|
| admin    | admin123     |
| analyst  | observe2024  |

---

## The three attacks (from your original plan)

### Attack 1 — SQL Injection (login)

Vulnerable form: **`/login.php`**

Classic payload in username (password anything):

```
admin' OR '1'='1' -- 
```

Or with sqlmap:

```bash
sqlmap -u "http://127.0.0.1:8080/login.php" \
  --data="username=test&password=test" \
  --batch --dbs --level=2 --risk=2
```

### Attack 2 — Cross-Site Scripting (XSS)

Vulnerable page: **`/search.php?q=`**

Payload:

```html
<script>alert('Hacked!');</script>
```

Open in browser:

```
http://127.0.0.1:8080/search.php?q=<script>alert('Hacked!');</script>
```

### Attack 3 — Directory / content discovery (mini DoS-style load)

```bash
gobuster dir -u http://127.0.0.1:8080 \
  -w /usr/share/wordlists/dirb/common.txt -t 20
```

Interesting paths that exist for discovery practice:

- `/admin/`
- `/admin/backup.php`
- `/login.php`
- `/robots.txt`

---

## Defense rounds

### Round 1 — No defense
Attack **port 8080**. SQLi, XSS, and gobuster should succeed.

### Round 2 — Detection only
```bash
./scripts/set-waf-mode.sh DetectionOnly
```
Attack **port 8082**. Attacks may still reach the app; defenders watch:

```bash
./scripts/watch-logs.sh
```

### Round 3 — Blocking
```bash
./scripts/set-waf-mode.sh On
```
Same attacks against **8082** should return **403**.  
Optional host block:

```bash
./scripts/block-ip.sh <attacker_ip>
```

---

## Helper scripts

| Script | Purpose |
|--------|---------|
| `start-lab.sh` | Build & start stack |
| `set-waf-mode.sh` | `DetectionOnly` / `On` / `Off` |
| `watch-logs.sh` | Live WAF logs |
| `block-ip.sh` / `unblock-ip.sh` | iptables DROP |
| `attack-demo.sh` | Quick probes for all three attacks |

---

## Stop / reset

```bash
docker compose down          # stop
docker compose down -v       # stop + wipe database
```

---

## Safety

- Bindings are localhost-oriented for training.
- Do **not** publish 8080/8082 to the public internet.
- Use only on isolated machines you own or are authorized to test.
- The site is intentionally vulnerable for learning WAF detection and blocking.

---

## Fictional company

**AetherForge** is an invented product (observability + security platform). All copy, users, and data are synthetic and exist only inside this lab.
