<?php
session_start();
if (empty($_SESSION['user'])) {
    header('Location: /login.php');
    exit;
}
$page = 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — AetherForge</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">
  <?php include 'includes/navbar.php'; ?>

  <main class="flex-grow-1 py-5">
    <div class="container">
      <h1 class="h3 fw-bold mb-1">Welcome, <?= htmlspecialchars($_SESSION['user']) ?></h1>
      <p class="text-muted mb-4">Role: <?= htmlspecialchars($_SESSION['role'] ?? 'user') ?></p>
      <div class="alert alert-success">
        You are authenticated. In a real product this would show org metrics and control panels.
      </div>
      <div class="row g-3">
        <div class="col-md-4">
          <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small">Active services</div>
            <div class="fs-3 fw-bold">24</div>
          </div></div>
        </div>
        <div class="col-md-4">
          <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small">Open incidents</div>
            <div class="fs-3 fw-bold text-warning">2</div>
          </div></div>
        </div>
        <div class="col-md-4">
          <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small">SLO compliance</div>
            <div class="fs-3 fw-bold text-success">99.4%</div>
          </div></div>
        </div>
      </div>
    </div>
  </main>

  <?php include 'includes/footer.php'; ?>
</body>
</html>
