<?php
session_start();
$page = 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AetherForge — Intelligent Infrastructure for Modern Teams</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body>
  <?php include 'includes/navbar.php'; ?>

  <!-- Hero -->
  <section class="hero text-white">
    <div class="container py-5">
      <div class="row align-items-center min-vh-75">
        <div class="col-lg-6">
          <span class="badge bg-primary-subtle text-primary mb-3">Series A · Trusted by 120+ teams</span>
          <h1 class="display-4 fw-bold mb-3">Infrastructure that thinks with you</h1>
          <p class="lead text-white-50 mb-4">AetherForge gives engineering teams real-time observability, automated remediation, and secure-by-default platforms — without the operational drag.</p>
          <div class="d-flex gap-3 flex-wrap">
            <a href="/contact.php" class="btn btn-primary btn-lg">Request a demo</a>
            <a href="/services.php" class="btn btn-outline-light btn-lg">Explore platform</a>
          </div>
        </div>
        <div class="col-lg-6 d-none d-lg-block text-center">
          <div class="hero-card p-4 rounded-4 shadow-lg">
            <div class="d-flex justify-content-between mb-3">
              <span class="text-success"><i class="bi bi-check-circle-fill"></i> All systems healthy</span>
              <span class="text-muted small">Live</span>
            </div>
            <div class="progress mb-2" style="height:8px"><div class="progress-bar bg-success" style="width:94%"></div></div>
            <div class="row g-2 mt-3 text-start small">
              <div class="col-6"><div class="p-2 bg-dark rounded">API latency <strong>42ms</strong></div></div>
              <div class="col-6"><div class="p-2 bg-dark rounded">Error rate <strong>0.02%</strong></div></div>
              <div class="col-6"><div class="p-2 bg-dark rounded">Deploy success <strong>99.8%</strong></div></div>
              <div class="col-6"><div class="p-2 bg-dark rounded">MTTR <strong>4.1 min</strong></div></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Logos / social proof -->
  <section class="py-4 bg-light border-bottom">
    <div class="container text-center text-muted small">
      <span class="me-4">Trusted by teams at</span>
      <span class="fw-semibold me-3">Northwind</span>
      <span class="fw-semibold me-3">Lumina Health</span>
      <span class="fw-semibold me-3">Orbit Payments</span>
      <span class="fw-semibold me-3">Vertex Robotics</span>
      <span class="fw-semibold">Cascade AI</span>
    </div>
  </section>

  <!-- Features -->
  <section class="py-5">
    <div class="container">
      <div class="text-center mb-5">
        <h2 class="fw-bold">Built for the way modern teams ship</h2>
        <p class="text-muted col-lg-8 mx-auto">From first commit to production incident, AetherForge keeps your systems observable, resilient, and secure.</p>
      </div>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-body p-4">
              <div class="icon-box bg-primary-subtle text-primary mb-3"><i class="bi bi-radar"></i></div>
              <h5>Unified Observability</h5>
              <p class="text-muted mb-0">Metrics, logs, and traces in one place with smart correlation so you find root cause in minutes, not hours.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-body p-4">
              <div class="icon-box bg-success-subtle text-success mb-3"><i class="bi bi-shield-check"></i></div>
              <h5>Secure by Default</h5>
              <p class="text-muted mb-0">Policy-as-code, continuous posture checks, and least-privilege access baked into every deployment pipeline.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-body p-4">
              <div class="icon-box bg-warning-subtle text-warning mb-3"><i class="bi bi-lightning-charge"></i></div>
              <h5>Automated Remediation</h5>
              <p class="text-muted mb-0">Playbooks that fix common failures automatically while keeping humans in the loop for high-impact changes.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="py-5 bg-dark text-white">
    <div class="container text-center">
      <h2 class="fw-bold mb-3">Ready to simplify your platform?</h2>
      <p class="text-white-50 mb-4">Join engineering teams that ship faster and sleep better.</p>
      <a href="/contact.php" class="btn btn-primary btn-lg">Talk to our team</a>
    </div>
  </section>

  <?php include 'includes/footer.php'; ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
