<?php
// Hidden path for directory discovery exercises
http_response_code(403);
?>
<!DOCTYPE html>
<html><head><title>Forbidden</title></head>
<body><h1>403 Forbidden</h1><p>Admin area — access restricted.</p></body></html>
