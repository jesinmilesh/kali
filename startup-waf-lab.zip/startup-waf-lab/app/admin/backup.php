<?php
// Another path for gobuster / dirb discovery
header('Content-Type: text/plain');
echo "LAB ONLY — fake backup listing\n";
echo "users.sql.bak\nconfig.old\n";
