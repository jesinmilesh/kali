<?php
/**
 * INTENTIONALLY VULNERABLE search — Reflected XSS training endpoint.
 * User input is echoed without encoding.
 */
session_start();
$page = 'search';
$q = $_GET['q'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search — AetherForge</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
  <?php include 'includes/navbar.php'; ?>

  <main class="flex-grow-1 py-5">
    <div class="container" style="max-width:720px">
      <h1 class="h3 fw-bold mb-4">Search knowledge base</h1>
      <form method="get" action="/search.php" class="mb-4">
        <div class="input-group">
          <input type="text" name="q" class="form-control form-control-lg" placeholder="Search docs, runbooks, APIs..." value="">
          <button class="btn btn-primary btn-lg" type="submit">Search</button>
        </div>
      </form>

      <?php if ($q !== ''): ?>
        <div class="alert alert-lab bg-light">
          <!-- VULNERABLE: reflected XSS — no htmlspecialchars -->
          <p class="mb-1">Results for: <strong><?= $q ?></strong></p>
          <p class="text-muted small mb-0">No indexed articles matched your query. Try different keywords.</p>
        </div>
      <?php else: ?>
        <p class="text-muted">Enter a term to search platform documentation and status updates.</p>
      <?php endif; ?>
    </div>
  </main>

  <?php include 'includes/footer.php'; ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
