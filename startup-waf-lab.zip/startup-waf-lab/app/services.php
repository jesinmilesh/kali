<?php
session_start();
$page = 'services';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Platform — AetherForge</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
  <?php include 'includes/navbar.php'; ?>

  <main class="flex-grow-1 py-5">
    <div class="container">
      <div class="text-center mb-5">
        <h1 class="fw-bold">The AetherForge platform</h1>
        <p class="text-muted col-lg-8 mx-auto">One control plane for observability, security posture, and automated operations.</p>
      </div>
      <div class="row g-4">
        <div class="col-md-6">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-body p-4">
              <h5><i class="bi bi-graph-up text-primary me-2"></i> Observability Suite</h5>
              <p class="text-muted">Full-stack metrics, logs, and distributed tracing with AI-assisted correlation and SLO tracking.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-body p-4">
              <h5><i class="bi bi-shield-lock text-success me-2"></i> Security Posture</h5>
              <p class="text-muted">Continuous compliance checks, secret scanning, and policy-as-code enforcement across clouds.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-body p-4">
              <h5><i class="bi bi-robot text-warning me-2"></i> Auto-Remediation</h5>
              <p class="text-muted">Runbooks that execute safely under guardrails when known failure modes appear.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-body p-4">
              <h5><i class="bi bi-people text-info me-2"></i> Team Workflows</h5>
              <p class="text-muted">On-call routing, incident timelines, and postmortem templates integrated with Slack and PagerDuty.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center mt-5">
        <a href="/contact.php" class="btn btn-primary btn-lg">Request a demo</a>
      </div>
    </div>
  </main>

  <?php include 'includes/footer.php'; ?>
</body>
</html>
