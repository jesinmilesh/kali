<?php
/**
 * Lab database connection.
 * Intentionally simple — used by vulnerable endpoints for training.
 */
$host = getenv('DB_HOST') ?: 'db';
$db   = getenv('DB_NAME') ?: 'aetherforge';
$user = getenv('DB_USER') ?: 'aether';
$pass = getenv('DB_PASS') ?: 'aetherpass';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    // Soft fail for pages that don't need DB
    $pdo = null;
}
