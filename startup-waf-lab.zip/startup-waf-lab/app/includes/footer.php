<footer class="footer py-5 mt-auto">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <h6 class="text-white mb-3"><i class="bi bi-hexagon-fill text-primary me-1"></i> AetherForge</h6>
        <p class="mb-0">Intelligent infrastructure for teams that ship. Observability, security, and automation in one platform.</p>
      </div>
      <div class="col-md-2">
        <h6 class="text-white mb-3">Product</h6>
        <ul class="list-unstyled">
          <li><a href="/services.php">Platform</a></li>
          <li><a href="/contact.php">Request demo</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h6 class="text-white mb-3">Company</h6>
        <ul class="list-unstyled">
          <li><a href="/about.php">About</a></li>
          <li><a href="/contact.php">Contact</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h6 class="text-white mb-3">Lab notice</h6>
        <p class="small mb-0">This is a fictional company created solely for a local cybersecurity training lab. No real business or personal data is used.</p>
      </div>
    </div>
    <hr class="border-secondary my-4">
    <div class="d-flex justify-content-between small">
      <span>&copy; <?= date('Y') ?> AetherForge Labs (training only)</span>
      <span>Isolated lab environment</span>
    </div>
  </div>
</footer>
