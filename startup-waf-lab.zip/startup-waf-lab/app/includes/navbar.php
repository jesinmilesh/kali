<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container">
    <a class="navbar-brand" href="/">
      <i class="bi bi-hexagon-fill text-primary me-1"></i> AetherForge
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
        <li class="nav-item"><a class="nav-link <?= ($page ?? '') === 'home' ? 'active' : '' ?>" href="/">Home</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page ?? '') === 'services' ? 'active' : '' ?>" href="/services.php">Platform</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page ?? '') === 'about' ? 'active' : '' ?>" href="/about.php">Company</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page ?? '') === 'search' ? 'active' : '' ?>" href="/search.php">Search</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page ?? '') === 'contact' ? 'active' : '' ?>" href="/contact.php">Contact</a></li>
        <?php if (!empty($_SESSION['user'])): ?>
          <li class="nav-item"><a class="nav-link" href="/dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm ms-lg-2" href="/login.php">Sign in</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
