<?php
/**
 * INTENTIONALLY VULNERABLE login — SQL Injection training endpoint.
 * Do NOT use this pattern in real applications.
 */
session_start();
$page = 'login';
require_once 'includes/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($pdo) {
        // VULNERABLE: string concatenation — classic SQLi
        $sql = "SELECT id, username, role FROM users WHERE username = '$username' AND password = '$password' LIMIT 1";
        try {
            $stmt = $pdo->query($sql);
            $row = $stmt->fetch();
            if ($row) {
                $_SESSION['user'] = $row['username'];
                $_SESSION['role'] = $row['role'];
                header('Location: /dashboard.php');
                exit;
            } else {
                $error = 'Invalid credentials.';
            }
        } catch (Exception $e) {
            // Surface SQL errors for lab visibility (not production-safe)
            $error = 'Query error: ' . htmlspecialchars($e->getMessage());
        }
    } else {
        $error = 'Database unavailable.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign in — AetherForge</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="bg-light d-flex flex-column min-vh-100">
  <?php include 'includes/navbar.php'; ?>

  <main class="flex-grow-1 d-flex align-items-center py-5">
    <div class="container">
      <div class="auth-card card border-0 shadow">
        <div class="card-body p-4 p-md-5">
          <div class="text-center mb-4">
            <i class="bi bi-hexagon-fill text-primary fs-2"></i>
            <h1 class="h4 mt-2 mb-1">Sign in to AetherForge</h1>
            <p class="text-muted small mb-0">Employee & partner portal</p>
          </div>

          <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= $error ?></div>
          <?php endif; ?>

          <form method="post" action="/login.php" autocomplete="off">
            <div class="mb-3">
              <label class="form-label">Username</label>
              <input type="text" name="username" class="form-control" placeholder="you@company.com" required>
            </div>
            <div class="mb-4">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Sign in</button>
          </form>

          <p class="text-muted small text-center mt-4 mb-0">
            Lab hint: try classic SQLi payloads against this form when WAF is off.
          </p>
        </div>
      </div>
    </div>
  </main>

  <?php include 'includes/footer.php'; ?>
</body>
</html>
