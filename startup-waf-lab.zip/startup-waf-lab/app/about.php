<?php
session_start();
$page = 'about';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Company — AetherForge</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
  <?php include 'includes/navbar.php'; ?>

  <main class="flex-grow-1 py-5">
    <div class="container" style="max-width:800px">
      <h1 class="fw-bold mb-3">About AetherForge</h1>
      <p class="lead text-muted">We build the control plane that keeps modern software reliable and secure.</p>
      <p>AetherForge was founded to close the gap between fast shipping and operational excellence. Our platform unifies observability, policy, and automated response so platform and SRE teams can focus on leverage instead of toil.</p>
      <p>This website is a <strong>fictional product</strong> created for a local cybersecurity training laboratory. It contains intentional vulnerabilities so students can practice detection and defense with a Web Application Firewall. No real company, customers, or personal data are involved.</p>
      <hr>
      <h5 class="mt-4">Lab endpoints of interest</h5>
      <ul>
        <li><code>/login.php</code> — SQL injection practice</li>
        <li><code>/search.php</code> — reflected XSS practice</li>
        <li>Hidden paths under <code>/admin/</code> and similar — directory discovery practice</li>
      </ul>
    </div>
  </main>

  <?php include 'includes/footer.php'; ?>
</body>
</html>
