#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAB_DIR="$(dirname "$SCRIPT_DIR")"
cd "$LAB_DIR"

echo "=============================================="
echo "  AetherForge Startup — WAF Defense Lab"
echo "=============================================="

DOCKER="docker"
if ! docker info &>/dev/null; then
  if sudo docker info &>/dev/null; then
    DOCKER="sudo docker"
    echo "[*] Using sudo for Docker"
  else
    echo "[!] Docker not available. Install: sudo apt install -y docker.io docker-compose-v2"
    exit 1
  fi
fi

export MODSEC_RULE_ENGINE="${MODSEC_RULE_ENGINE:-DetectionOnly}"
echo "[*] Building and starting stack (WAF mode: $MODSEC_RULE_ENGINE)..."
$DOCKER compose up -d --build

echo "[*] Waiting for services..."
sleep 12

for i in {1..20}; do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/ 2>/dev/null || echo 000)
  if [[ "$code" == "200" ]]; then
    echo "[+] Website is up"
    break
  fi
  sleep 2
done

echo ""
echo "=============================================="
echo "  Lab ready"
echo "=============================================="
echo ""
echo "  Direct site (no WAF):   http://127.0.0.1:8080"
echo "  WAF-protected site:     http://127.0.0.1:8082"
echo ""
echo "  Demo logins (for legit use):"
echo "    admin / admin123"
echo "    analyst / observe2024"
echo ""
echo "  Vulnerable endpoints:"
echo "    /login.php   → SQL Injection"
echo "    /search.php  → Reflected XSS"
echo "    /admin/      → Directory discovery targets"
echo ""
echo "  Commands:"
echo "    ./scripts/set-waf-mode.sh DetectionOnly|On|Off"
echo "    ./scripts/watch-logs.sh"
echo "    ./scripts/block-ip.sh <IP>"
echo "    ./scripts/attack-demo.sh"
echo ""
echo "  Stop:  docker compose down"
echo "  Reset: docker compose down -v && ./scripts/start-lab.sh"
echo "=============================================="
