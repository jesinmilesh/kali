#!/bin/bash
set -e
IP="${1:-}"
[[ -z "$IP" ]] && { echo "Usage: $0 <IP>"; exit 1; }
sudo iptables -D INPUT -s "$IP" -j DROP 2>/dev/null || echo "Rule not present"
echo "[+] Done"
