#!/bin/bash
set -e
DOCKER="docker"
if ! docker info &>/dev/null; then DOCKER="sudo docker"; fi

echo "=== Live WAF / access logs (Ctrl+C to stop) ==="
$DOCKER logs -f --tail 80 af-waf
