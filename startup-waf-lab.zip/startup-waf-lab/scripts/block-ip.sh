#!/bin/bash
set -e
IP="${1:-}"
if [[ -z "$IP" || ! "$IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "Usage: $0 <IPv4>"
  exit 1
fi
echo "[*] Blocking $IP ..."
sudo iptables -C INPUT -s "$IP" -j DROP 2>/dev/null || sudo iptables -A INPUT -s "$IP" -j DROP
echo "[+] DROP rule active for $IP"
echo "    Unblock: sudo iptables -D INPUT -s $IP -j DROP"
