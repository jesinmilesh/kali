#!/bin/bash
set -e
MODE="${1:-}"
if [[ -z "$MODE" ]]; then
  echo "Usage: $0 <DetectionOnly|On|Off>"
  exit 1
fi
case "$MODE" in DetectionOnly|On|Off) ;; *) echo "Invalid mode"; exit 1 ;; esac

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$(dirname "$SCRIPT_DIR")"

DOCKER="docker"
if ! docker info &>/dev/null; then DOCKER="sudo docker"; fi

export MODSEC_RULE_ENGINE="$MODE"
echo "[*] Setting WAF to $MODE ..."
$DOCKER compose up -d --force-recreate waf
echo "[+] WAF engine: $MODE"
echo "    Test via http://127.0.0.1:8082/"
