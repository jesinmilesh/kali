#!/bin/bash
# ====================================================================
# NxtGen Enterprise Security - Automated Kali Linux Localhost Installer
# Target OS: Kali Linux / Debian / Ubuntu
# ====================================================================

set -e

# Color Helpers
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}====================================================================${NC}"
echo -e "${BLUE}    NxtGen Enterprise WAF & Server Automated Installer for Kali    ${NC}"
echo -e "${BLUE}====================================================================${NC}"

# Check for root privilege
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR] Please run this installer with root privileges (sudo bash setup-kali.sh).${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEB_ROOT="/var/www/nxtgen"

echo -e "\n${YELLOW}[1/7] Updating package index & fixing any broken system dependencies...${NC}"
apt-get update --fix-missing || true
dpkg --configure -a || true
apt-get --fix-broken install -y || true
apt-get update --fix-missing || true

DEBIAN_FRONTEND=noninteractive apt-get install -y --fix-missing \
  nginx \
  libnginx-mod-http-modsecurity \
  modsecurity-crs \
  php-fpm \
  php-mysql \
  mariadb-server \
  fail2ban \
  openssl \
  curl \
  ufw \
  cron

echo -e "${GREEN}[✔] Packages installed successfully.${NC}"

echo -e "\n${YELLOW}[2/7] Deploying NxtGen Application Code to ${WEB_ROOT}...${NC}"
mkdir -p "${WEB_ROOT}"
cp -r "${SCRIPT_DIR}/app/"* "${WEB_ROOT}/"
rm -f "${WEB_ROOT}/admin/config.bak" 2>/dev/null || true

# Set strict permissions
chown -R www-data:www-data "${WEB_ROOT}"
find "${WEB_ROOT}" -type d -exec chmod 755 {} \;
find "${WEB_ROOT}" -type f -exec chmod 644 {} \;

echo -e "${GREEN}[✔] Web application files deployed with www-data permissions.${NC}"

echo -e "\n${YELLOW}[3/7] Generating SSL Certificates for Localhost (HTTPS)...${NC}"
mkdir -p /etc/ssl/nxtgen
openssl req -x509 -nodes -days 365 -newkey rsa:4096 \
  -keyout /etc/ssl/nxtgen/server.key \
  -out /etc/ssl/nxtgen/server.crt \
  -subj "/C=US/ST=Local/L=Localhost/O=NxtGen Enterprise/OU=SOC/CN=localhost" \
  2>/dev/null

chmod 600 /etc/ssl/nxtgen/server.key
chmod 644 /etc/ssl/nxtgen/server.crt

echo -e "${GREEN}[✔] SSL Certificates created at /etc/ssl/nxtgen/.${NC}"

echo -e "\n${YELLOW}[4/7] Initializing MariaDB Database & Least-Privilege Users...${NC}"
systemctl enable --now mariadb

# Import initial database schema & permissions
mariadb -u root < "${SCRIPT_DIR}/database/init-db.sql"
cp "${SCRIPT_DIR}/database/my.cnf" /etc/mysql/mariadb.conf.d/99-nxtgen.cnf 2>/dev/null || true

echo -e "${GREEN}[✔] MariaDB initialized with app_user, readonly, and db_admin accounts.${NC}"

echo -e "\n${YELLOW}[5/7] Configuring ModSecurity v3 WAF & OWASP CRS Rules...${NC}"
mkdir -p /etc/modsecurity/rules /var/log/modsecurity

# Deploy ModSecurity configuration
cp "${SCRIPT_DIR}/infrastructure/modsecurity/modsecurity.conf" /etc/modsecurity/modsecurity.conf
cp "${SCRIPT_DIR}/infrastructure/modsecurity/crs-setup.conf" /etc/modsecurity/crs-setup.conf
cp "${SCRIPT_DIR}/infrastructure/modsecurity/rules/custom-rules.conf" /etc/modsecurity/rules/custom-rules.conf

# Copy OWASP CRS rules if present in system or from repo
if [ -d "/usr/share/modsecurity-crs/rules" ]; then
  cp -n /usr/share/modsecurity-crs/rules/*.conf /etc/modsecurity/rules/ 2>/dev/null || true
fi

chown -R www-data:www-data /var/log/modsecurity

echo -e "${GREEN}[✔] ModSecurity v3 WAF & OWASP CRS configured.${NC}"

echo -e "\n${YELLOW}[6/7] Deploying Nginx & Fail2Ban Configurations...${NC}"
mkdir -p /etc/nginx/snippets /etc/nginx/sites-available /etc/nginx/sites-enabled /etc/nginx/conf.d

# Clean up stale files in conf.d and sites-enabled
rm -f /etc/nginx/conf.d/* /etc/nginx/sites-enabled/*

# Deploy Nginx core config, rate limits, and security snippets
cp "${SCRIPT_DIR}/infrastructure/nginx/nginx.conf" /etc/nginx/nginx.conf
cp "${SCRIPT_DIR}/infrastructure/nginx/conf.d/rate_limits.conf" /etc/nginx/conf.d/rate_limits.conf
cp "${SCRIPT_DIR}/infrastructure/nginx/snippets/security-headers.conf" /etc/nginx/snippets/security-headers.conf
cp "${SCRIPT_DIR}/infrastructure/nginx/sites-available/nxtgen.conf" /etc/nginx/sites-available/nxtgen.conf

# Activate nxtgen site
ln -sf /etc/nginx/sites-available/nxtgen.conf /etc/nginx/sites-enabled/nxtgen.conf

# Fail2Ban Setup
cp "${SCRIPT_DIR}/infrastructure/fail2ban/jail.local" /etc/fail2ban/jail.d/nxtgen.conf
cp "${SCRIPT_DIR}/infrastructure/fail2ban/filter.d/"*.conf /etc/fail2ban/filter.d/ 2>/dev/null || true

# Deploy Encrypted Backup Script
cp "${SCRIPT_DIR}/infrastructure/backups/backup.sh" /usr/local/bin/nxtgen-backup.sh
chmod +x /usr/local/bin/nxtgen-backup.sh
cp "${SCRIPT_DIR}/infrastructure/backups/crontab.example" /etc/cron.d/nxtgen-backup 2>/dev/null || true

# Detect active PHP-FPM service name
PHP_SVC=$(systemctl list-unit-files | grep -E "php[0-9.]*-fpm" | head -n1 | awk '{print $1}')
if [ -n "$PHP_SVC" ]; then
  systemctl restart "$PHP_SVC"
  systemctl enable "$PHP_SVC"
fi

# Validate Nginx configuration before restarting service
echo "Testing Nginx Configuration..."
nginx -t || {
  echo -e "${RED}[ERROR] Nginx syntax check failed. Output details above.${NC}"
  exit 1
}

systemctl restart mariadb nginx fail2ban
systemctl enable mariadb nginx fail2ban

echo -e "${GREEN}[✔] Nginx, PHP-FPM, MariaDB, and Fail2Ban services started.${NC}"

echo -e "\n${YELLOW}[7/7] Running Security Verification Tests on Localhost...${NC}"
sleep 2

# Test 1: Localhost HTTP -> HTTPS Redirect or 200 OK Check
HTTP_CODE=$(curl -k -s -o /dev/null -w "%{http_code}" https://localhost/ || true)
echo -e "  [Test 1] HTTPS Localhost Access: HTTP ${HTTP_CODE} (Expected 200/302)"

# Test 2: Scanner Blocking Check (sqlmap User-Agent)
SCANNER_CODE=$(curl -k -s -o /dev/null -w "%{http_code}" -A "sqlmap/1.5" https://localhost/ || true)
if [ "$SCANNER_CODE" -eq 403 ]; then
  echo -e "  [Test 2] ${GREEN}WAF Scanner Tool Blocking (sqlmap UA): HTTP 403 Forbidden [PASSED]${NC}"
else
  echo -e "  [Test 2] ${YELLOW}WAF Scanner Tool Blocking: HTTP ${SCANNER_CODE}${NC}"
fi

# Test 3: Path Traversal Attack Test
TRAVERSAL_CODE=$(curl -k -s -o /dev/null -w "%{http_code}" "https://localhost/index.php?file=../../../../etc/passwd" || true)
if [ "$TRAVERSAL_CODE" -eq 403 ]; then
  echo -e "  [Test 3] ${GREEN}WAF Path Traversal Prevention: HTTP 403 Forbidden [PASSED]${NC}"
else
  echo -e "  [Test 3] ${YELLOW}WAF Path Traversal Prevention: HTTP ${TRAVERSAL_CODE}${NC}"
fi

echo -e "\n${BLUE}====================================================================${NC}"
echo -e "${GREEN}🎉 NxtGen Enterprise Hardened Server Successfully Installed on Kali!${NC}"
echo -e "${BLUE}====================================================================${NC}"
echo -e "🌐 Access Localhost Web Application: ${YELLOW}https://localhost/${NC} or ${YELLOW}http://localhost/${NC}"
echo -e "🔑 Admin Portal:                     ${YELLOW}https://localhost/admin/${NC}"
echo -e "🛡️ ModSecurity Audit Logs:          ${YELLOW}/var/log/modsecurity/modsec_audit.log${NC}"
echo -e "🚨 Nginx Access & Error Logs:       ${YELLOW}/var/log/nginx/${NC}"
echo -e "💾 Manual Encrypted Backup Trigger:  ${YELLOW}sudo /usr/local/bin/nxtgen-backup.sh all${NC}"
echo -e "${BLUE}====================================================================${NC}\n"
