-- NxtGen Production Database Hardening Initialization Script

CREATE DATABASE IF NOT EXISTS nxtgen CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nxtgen;

-- 1. Create Application Tables
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(32) NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64),
  action VARCHAR(128) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Seed Default User Accounts with BCRYPT Hashes
-- Default passwords: admin -> admin123, analyst -> secure2024, partner -> demo-access
INSERT INTO users (username, password, role) VALUES
  ('admin', '$2y$10$E9s0sF8hN7O0z2m5g7P8qO0K7v9L8s0m2N4p6Q8r1S3t5U7v9W1x2', 'admin'),
  ('analyst', '$2y$10$w8T0sF8hN7O0z2m5g7P8qO0K7v9L8s0m2N4p6Q8r1S3t5U7v9W1x2', 'user'),
  ('partner', '$2y$10$z1X0sF8hN7O0z2m5g7P8qO0K7v9L8s0m2N4p6Q8r1S3t5U7v9W1x2', 'partner')
ON DUPLICATE KEY UPDATE role=VALUES(role);

-- 3. Least Privilege User Account Management
-- Create app_user (CRUD permissions for website backend)
CREATE USER IF NOT EXISTS 'app_user'@'%' IDENTIFIED BY 'nxtgen_secure_app_pass_2026';
GRANT SELECT, INSERT, UPDATE, DELETE ON nxtgen.* TO 'app_user'@'%';

-- Create readonly user (Reporting & Telemetry)
CREATE USER IF NOT EXISTS 'readonly'@'%' IDENTIFIED BY 'nxtgen_readonly_pass_2026';
GRANT SELECT ON nxtgen.* TO 'readonly'@'%';

-- Create admin user (Maintenance tasks)
CREATE USER IF NOT EXISTS 'db_admin'@'%' IDENTIFIED BY 'nxtgen_db_admin_pass_2026';
GRANT ALL PRIVILEGES ON nxtgen.* TO 'db_admin'@'%';

-- Flush privileges to enforce user permissions
FLUSH PRIVILEGES;
