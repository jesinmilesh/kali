#!/bin/bash
# NxtGen Certificate Generator Script (RSA 4096 / ECC TLS 1.3)
set -e

CERT_DIR="$(dirname "$0")/certs"
mkdir -p "$CERT_DIR"

DOMAIN="nxtgen-website.local"

echo "Generating 4096-bit Private Key for $DOMAIN..."
openssl req -x509 -nodes -days 365 -newkey rsa:4096 \
  -keyout "$CERT_DIR/server.key" \
  -out "$CERT_DIR/server.crt" \
  -subj "/C=US/ST=Oregon/L=Portland/O=NxtGen Enterprise Security/OU=SOC/CN=$DOMAIN"

chmod 600 "$CERT_DIR/server.key"
chmod 644 "$CERT_DIR/server.crt"

echo "Certificates generated successfully in $CERT_DIR"
