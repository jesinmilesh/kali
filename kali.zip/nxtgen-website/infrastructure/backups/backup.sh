#!/bin/bash
# NxtGen Enterprise Encrypted Backup Suite - Native Kali Linux Deployment
set -euo pipefail

BACKUP_DIR="/var/backups/nxtgen"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
ENCRYPTION_PASS="${BACKUP_ENCRYPTION_KEY:-nxtgen_backup_encrypt_secret_2026}"

mkdir -p "$BACKUP_DIR/db" "$BACKUP_DIR/config" "$BACKUP_DIR/logs" "$BACKUP_DIR/ssl"

TYPE="${1:-all}"

encrypt_file() {
    local src="$1"
    local dest="$2"
    openssl enc -aes-256-cbc -pbkdf2 -salt -in "$src" -out "$dest" -k "$ENCRYPTION_PASS"
    rm -f "$src"
}

# 1. MySQL Daily Backup
backup_mysql() {
    echo "[$(date)] Starting MariaDB Database Backup..."
    local raw_dump="$BACKUP_DIR/db/nxtgen_db_$TIMESTAMP.sql"
    local enc_dump="$BACKUP_DIR/db/nxtgen_db_$TIMESTAMP.sql.enc"
    
    mysqldump -u app_user -pnxtgen_secure_app_pass_2026 nxtgen > "$raw_dump"
    encrypt_file "$raw_dump" "$enc_dump"
    echo "[$(date)] MariaDB Backup completed & encrypted: $enc_dump"
}

# 2. Infrastructure Config Daily Backup
backup_config() {
    echo "[$(date)] Starting Configuration Files Backup..."
    local raw_tar="$BACKUP_DIR/config/nxtgen_config_$TIMESTAMP.tar.gz"
    local enc_tar="$BACKUP_DIR/config/nxtgen_config_$TIMESTAMP.tar.gz.enc"
    
    tar -czf "$raw_tar" /etc/nginx /etc/modsecurity /var/www/nxtgen/infrastructure 2>/dev/null || true
    encrypt_file "$raw_tar" "$enc_tar"
    echo "[$(date)] Config Backup completed & encrypted: $enc_tar"
}

# 3. Logs Hourly Archival
backup_logs() {
    echo "[$(date)] Starting Log Files Archival..."
    local raw_log="$BACKUP_DIR/logs/nxtgen_logs_$TIMESTAMP.tar.gz"
    local enc_log="$BACKUP_DIR/logs/nxtgen_logs_$TIMESTAMP.tar.gz.enc"
    
    tar -czf "$raw_log" /var/log/nginx /var/log/modsecurity 2>/dev/null || true
    encrypt_file "$raw_log" "$enc_log"
    echo "[$(date)] Logs Archive completed & encrypted: $enc_log"
}

# 4. SSL Certificates Weekly Backup
backup_ssl() {
    echo "[$(date)] Starting SSL Certificates Backup..."
    local raw_ssl="$BACKUP_DIR/ssl/nxtgen_ssl_$TIMESTAMP.tar.gz"
    local enc_ssl="$BACKUP_DIR/ssl/nxtgen_ssl_$TIMESTAMP.tar.gz.enc"
    
    tar -czf "$raw_ssl" /etc/ssl/nxtgen
    encrypt_file "$raw_ssl" "$enc_ssl"
    echo "[$(date)] SSL Backup completed & encrypted: $enc_ssl"
}

case "$TYPE" in
    mysql)  backup_mysql ;;
    config) backup_config ;;
    logs)   backup_logs ;;
    ssl)    backup_ssl ;;
    all)
        backup_mysql
        backup_config
        backup_logs
        backup_ssl
        ;;
    *)
        echo "Usage: $0 {mysql|config|logs|ssl|all}"
        exit 1
        ;;
esac

# Retain backups for 30 days
find "$BACKUP_DIR" -type f -mtime +30 -name "*.enc" -delete
