<?php session_start(); $page='platform'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Platform — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h1 class="fw-bold">The NxtGen platform</h1>
      <p class="text-muted col-lg-8 mx-auto">Unified control plane for infrastructure, security posture, and intelligent operations.</p>
    </div>
    <div class="row g-4">
      <div class="col-md-6"><div class="feature-card h-100"><h5><i class="bi bi-layers text-indigo me-2"></i>Infrastructure Hub</h5><p class="text-muted mb-0">Provision, observe, and govern multi-cloud resources from a single pane of glass.</p></div></div>
      <div class="col-md-6"><div class="feature-card h-100"><h5><i class="bi bi-shield-check text-teal me-2"></i>Security Posture</h5><p class="text-muted mb-0">Continuous compliance, secret scanning, and policy-as-code across environments.</p></div></div>
      <div class="col-md-6"><div class="feature-card h-100"><h5><i class="bi bi-lightning text-amber me-2"></i>AI Ops</h5><p class="text-muted mb-0">Correlate signals, suggest root cause, and trigger safe automated remediation.</p></div></div>
      <div class="col-md-6"><div class="feature-card h-100"><h5><i class="bi bi-people text-indigo me-2"></i>Team Workflows</h5><p class="text-muted mb-0">On-call routing, incident timelines, and integrations with Slack, Jira, and PagerDuty.</p></div></div>
    </div>
    <div class="text-center mt-5"><a href="/contact.php" class="btn btn-accent btn-lg">Request a demo</a></div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
