<nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background:#0b1220">
  <div class="container">
    <a class="navbar-brand" href="/">Nxt<span>Gen</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
        <li class="nav-item"><a class="nav-link <?= ($page??'')==='home'?'active':'' ?>" href="/">Home</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page??'')==='platform'?'active':'' ?>" href="/platform.php">Platform</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page??'')==='solutions'?'active':'' ?>" href="/solutions.php">Solutions</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page??'')==='about'?'active':'' ?>" href="/about.php">Company</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page??'')==='careers'?'active':'' ?>" href="/careers.php">Careers</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page??'')==='search'?'active':'' ?>" href="/search.php">Search</a></li>
        <li class="nav-item"><a class="nav-link <?= ($page??'')==='contact'?'active':'' ?>" href="/contact.php">Contact</a></li>
        <?php if (!empty($_SESSION['user'])): ?>
          <li class="nav-item"><a class="nav-link" href="/dashboard.php">Portal</a></li>
          <li class="nav-item"><a class="nav-link" href="/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item ms-lg-2"><a class="btn btn-accent btn-sm px-3" href="/login.php">Sign in</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
