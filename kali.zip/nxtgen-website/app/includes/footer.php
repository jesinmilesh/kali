<footer class="footer py-5 mt-auto">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <h6 class="text-white mb-3">Nxt<span style="color:#818cf8">Gen</span></h6>
        <p class="mb-0">Next-generation platforms for cloud, security, and AI operations. Built for enterprises that refuse to compromise on speed or safety.</p>
      </div>
      <div class="col-md-2">
        <h6 class="text-white mb-3">Product</h6>
        <ul class="list-unstyled">
          <li><a href="/platform.php">Platform</a></li>
          <li><a href="/solutions.php">Solutions</a></li>
          <li><a href="/contact.php">Request demo</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h6 class="text-white mb-3">Company</h6>
        <ul class="list-unstyled">
          <li><a href="/about.php">About</a></li>
          <li><a href="/careers.php">Careers</a></li>
          <li><a href="/contact.php">Contact</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h6 class="text-white mb-3">Enterprise &amp; Security</h6>
        <p class="small mb-0">NxtGen empowers organizations with modern, reliable, and compliant cloud platforms built for mission-critical operations.</p>
      </div>
    </div>
    <hr class="border-secondary my-4">
    <div class="d-flex flex-wrap justify-content-between small">
      <span>&copy; <?= date('Y') ?> NxtGen Inc. All rights reserved.</span>
      <span>HQ: San Francisco, CA</span>
    </div>
  </div>
</footer>
