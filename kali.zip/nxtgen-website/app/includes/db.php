<?php
/**
 * NxtGen Database Connection Layer (PDO Prepared Statements Engine)
 */

$host = getenv('DB_HOST') ?: '127.0.0.1';
$db   = getenv('DB_NAME') ?: 'nxtgen';
$user = getenv('DB_USER') ?: 'app_user';
$pass = getenv('DB_PASS') ?: 'nxtgen_secure_app_pass_2026';

$pdo = null;

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false, // Enforce native prepared statements
    ];
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    try {
        // Fallback to localhost socket or root if app_user password differs
        $pdo = new PDO("mysql:host=localhost;dbname=$db;charset=utf8mb4", $user, $pass, $options);
    } catch (PDOException $e2) {
        error_log("Database connection error: " . $e2->getMessage());
        $pdo = null;
    }
}
