<?php
/**
 * NxtGen Security Module - Session Hardening, Rate Limiting & Input Sanitization
 */

// Harden session configuration before session start
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Strict');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', 1);
    }
    session_start();
}

/**
 * Regenerate session ID safely to prevent Session Fixation attacks
 */
function secure_session_regenerate() {
    if (!isset($_SESSION['CREATED'])) {
        $_SESSION['CREATED'] = time();
    } else if (time() - $_SESSION['CREATED'] > 1800) { // regenerate every 30 mins
        session_regenerate_id(true);
        $_SESSION['CREATED'] = time();
    }
}

/**
 * In-memory / session-backed Rate Limiter
 * @param string $action Action key (e.g. 'login', 'signup', 'reset')
 * @param int $maxAttempts Maximum allowed requests
 * @param int $decaySeconds Window duration in seconds
 * @return bool True if permitted, false if rate limit exceeded
 */
function check_rate_limit(string $action, int $maxAttempts, int $decaySeconds = 60): bool {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $key = 'rate_limit_' . $action . '_' . md5($ip);
    
    $now = time();
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = [];
    }
    
    // Filter attempts within the decay window
    $_SESSION[$key] = array_filter($_SESSION[$key], function($timestamp) use ($now, $decaySeconds) {
        return ($now - $timestamp) < $decaySeconds;
    });
    
    if (count($_SESSION[$key]) >= $maxAttempts) {
        return false;
    }
    
    $_SESSION[$key][] = $now;
    return true;
}

/**
 * Sanitize string input against XSS
 */
function sanitize_input($data): string {
    if (is_null($data)) return '';
    return htmlspecialchars(trim((string)$data), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Require active authentication session
 */
function require_auth() {
    if (empty($_SESSION['user'])) {
        header('Location: /login.php');
        exit;
    }
    secure_session_regenerate();
}

/**
 * Require administrator privilege
 */
function require_admin() {
    require_auth();
    $role = $_SESSION['role'] ?? 'user';
    if ($role !== 'admin' && strtolower($_SESSION['user']) !== 'admin') {
        http_response_code(403);
        echo "<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><h1>403 Forbidden</h1><p>Access denied. Administrator privileges required.</p></body></html>";
        exit;
    }
}
