<?php session_start(); $page='home'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NxtGen — Next-Generation Digital Transformation</title>
  <meta name="description" content="NxtGen builds intelligent platforms that help enterprises modernize operations, secure data, and accelerate innovation.">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<section class="hero">
  <div class="container">
    <div class="row align-items-center min-vh-75 py-5">
      <div class="col-lg-6">
        <span class="badge-pill mb-3">Trusted by 200+ enterprises worldwide</span>
        <h1 class="display-4 fw-bold text-white mb-3">Build the future.<br>Operate with confidence.</h1>
        <p class="lead text-white-50 mb-4">NxtGen delivers cloud-native platforms, AI-assisted operations, and enterprise-grade security so your teams ship faster and sleep better.</p>
        <div class="d-flex flex-wrap gap-3">
          <a href="/contact.php" class="btn btn-accent btn-lg px-4">Book a demo</a>
          <a href="/platform.php" class="btn btn-outline-light btn-lg px-4">Explore platform</a>
        </div>
        <div class="d-flex gap-4 mt-5 text-white-50 small">
          <div><strong class="text-white d-block fs-5">99.99%</strong> Platform uptime</div>
          <div><strong class="text-white d-block fs-5">40%</strong> Faster releases</div>
          <div><strong class="text-white d-block fs-5">24/7</strong> SOC-ready support</div>
        </div>
      </div>
      <div class="col-lg-6 d-none d-lg-block">
        <div class="hero-panel">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-success small"><i class="bi bi-circle-fill me-1" style="font-size:8px"></i> All systems operational</span>
            <span class="text-muted small">Live telemetry</span>
          </div>
          <div class="row g-2">
            <div class="col-6"><div class="metric-card"><div class="text-muted small">API latency</div><div class="fs-4 fw-bold text-white">38ms</div></div></div>
            <div class="col-6"><div class="metric-card"><div class="text-muted small">Error budget</div><div class="fs-4 fw-bold text-success">99.2%</div></div></div>
            <div class="col-6"><div class="metric-card"><div class="text-muted small">Deploys / week</div><div class="fs-4 fw-bold text-white">142</div></div></div>
            <div class="col-6"><div class="metric-card"><div class="text-muted small">MTTR</div><div class="fs-4 fw-bold text-info">3.4m</div></div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-4 bg-white border-bottom">
  <div class="container text-center text-muted small">
    <span class="me-3">Partners &amp; customers</span>
    <span class="fw-semibold text-dark me-3">Horizon Bank</span>
    <span class="fw-semibold text-dark me-3">Lumina Health</span>
    <span class="fw-semibold text-dark me-3">Orbit Logistics</span>
    <span class="fw-semibold text-dark me-3">Vertex Energy</span>
    <span class="fw-semibold text-dark">Cascade Media</span>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold">One platform. Complete control.</h2>
      <p class="text-muted col-lg-7 mx-auto">From infrastructure to application security, NxtGen unifies the tools modern enterprises need to stay competitive and compliant.</p>
    </div>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="feature-card h-100">
          <div class="icon-circle bg-indigo-soft text-indigo mb-3"><i class="bi bi-cloud-check"></i></div>
          <h5>Cloud Modernization</h5>
          <p class="text-muted mb-0">Migrate, optimize, and govern multi-cloud workloads with automated cost and compliance controls.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card h-100">
          <div class="icon-circle bg-teal-soft text-teal mb-3"><i class="bi bi-shield-lock"></i></div>
          <h5>Security &amp; Compliance</h5>
          <p class="text-muted mb-0">Continuous posture management, policy-as-code, and SOC integrations that reduce mean time to remediate.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card h-100">
          <div class="icon-circle bg-amber-soft text-amber mb-3"><i class="bi bi-cpu"></i></div>
          <h5>AI Operations</h5>
          <p class="text-muted mb-0">Intelligent alerting, root-cause suggestions, and automated runbooks that free engineers for higher-value work.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-5 bg-dark text-white">
  <div class="container text-center">
    <h2 class="fw-bold mb-3">Ready to accelerate your roadmap?</h2>
    <p class="text-white-50 mb-4 col-lg-6 mx-auto">Join product and platform teams that trust NxtGen for reliability, security, and speed.</p>
    <a href="/contact.php" class="btn btn-accent btn-lg px-5">Talk to sales</a>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
