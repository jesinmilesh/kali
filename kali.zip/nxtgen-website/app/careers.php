<?php session_start(); $page='careers'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Careers — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 py-5">
  <div class="container">
    <h1 class="fw-bold mb-2">Careers at NxtGen</h1>
    <p class="text-muted mb-5">Join our global team building the next generation of platform tools.</p>
    <div class="row g-3">
      <div class="col-md-6"><div class="feature-card"><h5 class="mb-1">Senior Platform Engineer</h5><p class="text-muted small mb-0">Remote · Full-time · Infrastructure &amp; reliability</p></div></div>
      <div class="col-md-6"><div class="feature-card"><h5 class="mb-1">Security Engineer (AppSec)</h5><p class="text-muted small mb-0">Remote · Full-time · Product security</p></div></div>
      <div class="col-md-6"><div class="feature-card"><h5 class="mb-1">Product Designer</h5><p class="text-muted small mb-0">Hybrid · Full-time · Design systems</p></div></div>
      <div class="col-md-6"><div class="feature-card"><h5 class="mb-1">Customer Success Manager</h5><p class="text-muted small mb-0">Remote · Full-time · Enterprise accounts</p></div></div>
    </div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
