<?php session_start(); $page='solutions'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Solutions — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 py-5">
  <div class="container">
    <h1 class="fw-bold mb-2">Solutions by industry</h1>
    <p class="text-muted mb-5">Purpose-built patterns for regulated and high-scale environments.</p>
    <div class="row g-4">
      <div class="col-md-4"><div class="feature-card h-100"><h5>Financial services</h5><p class="text-muted mb-0">Audit-ready controls, data residency options, and real-time fraud signal pipelines.</p></div></div>
      <div class="col-md-4"><div class="feature-card h-100"><h5>Healthcare</h5><p class="text-muted mb-0">HIPAA-aligned patterns, PHI handling guidance, and high-availability clinical workloads.</p></div></div>
      <div class="col-md-4"><div class="feature-card h-100"><h5>Retail &amp; logistics</h5><p class="text-muted mb-0">Edge-friendly deployments, inventory event streams, and peak-season autoscaling.</p></div></div>
    </div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
