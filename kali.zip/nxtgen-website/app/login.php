<?php
require_once __DIR__ . '/includes/security.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/db.php';

$page = 'login';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Enforce Rate Limit: 5 attempts per minute
    if (!check_rate_limit('login', 5, 60)) {
        $error = 'Too many login attempts. Please wait 60 seconds before trying again.';
    } 
    // 2. Enforce CSRF verification
    else if (!verify_csrf_token()) {
        $error = 'Security validation failed (Invalid CSRF Token). Please refresh and try again.';
    } 
    else {
        $username = sanitize_input($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($password)) {
            $error = 'Username and password are required.';
        } else if ($pdo) {
            try {
                // Prepared statement to prevent SQL Injection
                $stmt = $pdo->prepare("SELECT id, username, password, role FROM users WHERE username = :username LIMIT 1");
                $stmt->execute([':username' => $username]);
                $userRow = $stmt->fetch();

                if ($userRow) {
                    $dbPassword = $userRow['password'];
                    $passwordValid = false;

                    // Support both password_hash (BCRYPT) and legacy initial migration verification
                    if (password_verify($password, $dbPassword)) {
                        $passwordValid = true;
                    } else if ($password === $dbPassword) {
                        // Legacy match - upgrade password hash on the fly
                        $passwordValid = true;
                        $newHash = password_hash($password, PASSWORD_BCRYPT);
                        $updateStmt = $pdo->prepare("UPDATE users SET password = :hash WHERE id = :id");
                        $updateStmt->execute([':hash' => $newHash, ':id' => $userRow['id']]);
                    }

                    if ($passwordValid) {
                        // Regenerate session ID upon authentication to block session fixation
                        session_regenerate_id(true);
                        $_SESSION['user'] = $userRow['username'];
                        $_SESSION['role'] = $userRow['role'];
                        $_SESSION['authenticated_at'] = time();

                        header('Location: /dashboard.php');
                        exit;
                    }
                }
                $error = 'Invalid username or password.';
            } catch (Exception $e) {
                error_log("Login error: " . $e->getMessage());
                $error = 'An internal authentication error occurred. Please contact system administrator.';
            }
        } else {
            $error = 'Authentication backend service unavailable.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign in — NxtGen Enterprise Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 d-flex align-items-center py-5">
  <div class="container">
    <div class="auth-card card border-0 shadow-lg mx-auto" style="max-width: 480px;">
      <div class="card-body p-4 p-md-5">
        <div class="text-center mb-4">
          <div class="icon-circle bg-indigo-soft text-indigo mx-auto mb-2"><i class="bi bi-shield-lock"></i></div>
          <h1 class="h4 fw-bold">Sign in to NxtGen</h1>
          <p class="text-muted small mb-0">Protected by Enterprise ModSecurity & OWASP WAF</p>
        </div>
        
        <?php if ($error): ?>
          <div class="alert alert-danger py-2 small d-flex align-items-center"><i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i><div><?= htmlspecialchars($error) ?></div></div>
        <?php endif; ?>

        <form method="post" action="/login.php" autocomplete="off">
          <?= csrf_field(); ?>
          <div class="mb-3">
            <label class="form-label fw-semibold">Username</label>
            <input type="text" name="username" class="form-control form-control-lg" required autofocus autocomplete="username">
          </div>
          <div class="mb-4">
            <label class="form-label fw-semibold">Password</label>
            <input type="password" name="password" class="form-control form-control-lg" required autocomplete="current-password">
          </div>
          <button type="submit" class="btn btn-accent w-100 btn-lg fw-bold">Sign in to Dashboard</button>
        </form>
        <div class="mt-4 text-center">
          <span class="badge bg-light text-secondary border px-3 py-2"><i class="bi bi-lock-fill text-success me-1"></i> Rate-Limited Login Policy (5 req/min)</span>
        </div>
      </div>
    </div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
