<?php
require_once __DIR__ . '/../includes/security.php';

// Strict Admin Gatekeeper: Require auth and admin role
require_admin();

$page = 'admin';
$user = sanitize_input($_SESSION['user']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Restricted Zone — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="bg-dark text-white min-vh-100 d-flex flex-column justify-content-center align-items-center">
  <div class="card bg-secondary text-white border-0 shadow-lg p-4" style="max-width: 500px;">
    <div class="card-body text-center">
      <div class="display-4 text-warning mb-3"><i class="bi bi-shield-lock-fill"></i></div>
      <h2 class="h4 fw-bold">Admin Privileged Area</h2>
      <p class="text-white-50 small mb-4">Authenticated Administrator Session verified for <strong><?= $user ?></strong>.</p>
      <div class="alert alert-dark border border-secondary text-start small">
        <div><i class="bi bi-check-circle-fill text-success me-1"></i> ModSecurity Custom WAF Rule Active</div>
        <div><i class="bi bi-check-circle-fill text-success me-1"></i> Enumeration Protection Active</div>
        <div><i class="bi bi-check-circle-fill text-success me-1"></i> Strict Role-Based Access Control</div>
      </div>
      <a href="/dashboard.php" class="btn btn-accent w-100 fw-bold">Return to Main Dashboard</a>
    </div>
  </div>
</body>
</html>
