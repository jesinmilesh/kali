<?php
require_once __DIR__ . '/includes/security.php';
$page = 'search';
$q = sanitize_input($_GET['q'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search — NxtGen Enterprise Knowledge Base</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 py-5">
  <div class="container" style="max-width:720px">
    <h1 class="h3 fw-bold mb-4"><i class="bi bi-search me-2 text-indigo"></i>Search knowledge base</h1>
    <form method="get" action="/search.php" class="mb-4">
      <div class="input-group input-group-lg">
        <input type="text" name="q" class="form-control" placeholder="Search docs, APIs, runbooks..." value="<?= $q ?>" required maxlength="100">
        <button class="btn btn-accent" type="submit">Search</button>
      </div>
    </form>
    <?php if ($q !== ''): ?>
      <div class="alert alert-light border shadow-sm">
        <p class="mb-1">Results for query: <strong><?= $q ?></strong></p>
        <p class="text-muted small mb-0">No indexed internal runbooks or public API documentation matched your search term. Try different keywords.</p>
      </div>
    <?php else: ?>
      <p class="text-muted">Search enterprise platform documentation, security posture runbooks, and status updates.</p>
    <?php endif; ?>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
