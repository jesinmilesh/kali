<?php session_start(); $page='about'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Company — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 py-5">
  <div class="container" style="max-width:800px">
    <h1 class="fw-bold mb-3">About NxtGen</h1>
    <p class="lead text-muted">We exist to make enterprise platforms reliable, secure, and fast to evolve.</p>
    <p>NxtGen is a leader in next-generation digital transformation and cloud operations software. Our platforms deliver unified observability, proactive security controls, and AI-driven automation to help enterprise organizations scale with speed and resilience.</p>
    <hr>
    <h5 class="mt-4">Our Core Philosophy</h5>
    <p>We believe engineering teams perform best when security, observability, and infrastructure management operate seamlessly together under a single pane of glass.</p>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
