<?php
require_once __DIR__ . '/includes/security.php';
require_once __DIR__ . '/includes/csrf.php';

$page = 'contact';
$sent = false;
$error = '';
$name = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Spam bot honeypot check
    if (!empty($_POST['website_hp'])) {
        // Silent block for bot
        $sent = true;
    } else if (!check_rate_limit('contact', 3, 60)) {
        $error = 'Rate limit exceeded. Please wait a minute before submitting another inquiry.';
    } else if (!verify_csrf_token()) {
        $error = 'Invalid security token. Please refresh the page and try again.';
    } else {
        $name    = sanitize_input($_POST['name'] ?? '');
        $email   = sanitize_input($_POST['email'] ?? '');
        $company = sanitize_input($_POST['company'] ?? '');
        $message = sanitize_input($_POST['message'] ?? '');

        if (empty($name) || empty($email) || empty($message)) {
            $error = 'Please fill out all required fields.';
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid work email address.';
        } else {
            // Process contact submission securely
            $sent = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Sales — NxtGen Enterprise</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-7">
        <h1 class="h3 fw-bold mb-2">Contact Sales & Security Team</h1>
        <p class="text-muted mb-4">Request a demo or discuss security architecture, compliance, and enterprise onboarding.</p>
        
        <?php if ($error): ?>
          <div class="alert alert-danger py-2 mb-3"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($sent && !$error): ?>
          <div class="alert alert-success py-3 mb-4">
            <i class="bi bi-check-circle-fill me-2"></i>Thank you<?= $name ? ', ' . $name : '' ?>. Our enterprise security engineering team will respond within 1 business day.
          </div>
        <?php endif; ?>

        <form method="post" action="/contact.php" class="card border-0 shadow-sm">
          <?= csrf_field(); ?>
          <!-- Honeypot field for bot detection -->
          <div style="display:none;">
            <input type="text" name="website_hp" tabindex="-1" autocomplete="off">
          </div>
          <div class="card-body p-4">
            <div class="mb-3">
              <label class="form-label fw-semibold">Name <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" required value="<?= $name ?>">
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Work email <span class="text-danger">*</span></label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Company</label>
              <input type="text" name="company" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Message <span class="text-danger">*</span></label>
              <textarea name="message" class="form-control" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-accent px-4 py-2 fw-bold">Send message</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
