<?php
require_once __DIR__ . '/includes/security.php';
require_auth();

$page = 'dashboard';
$user = sanitize_input($_SESSION['user'] ?? 'User');
$role = sanitize_input($_SESSION['role'] ?? 'user');
$isAdmin = ($role === 'admin' || strtolower($user) === 'admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $isAdmin ? 'Admin Console' : 'User Portal' ?> — NxtGen Enterprise</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">
<?php include 'includes/navbar.php'; ?>

<main class="flex-grow-1 py-4">
  <div class="container">
    
    <!-- Top Welcome Header Banner -->
    <div class="dash-header-banner text-white p-4 p-md-5 mb-4 position-relative overflow-hidden">
      <div class="row align-items-center position-relative" style="z-index: 2;">
        <div class="col-md-8">
          <div class="d-flex align-items-center gap-2 mb-2">
            <span class="badge <?= $isAdmin ? 'badge-role-admin' : 'badge-role-user' ?> px-3 py-1 rounded-pill">
              <i class="bi <?= $isAdmin ? 'bi-shield-lock-fill' : 'bi-person-badge-fill' ?> me-1"></i>
              Role: <?= htmlspecialchars(ucfirst($role)) ?>
            </span>
            <span class="text-white-50 small">|</span>
            <span class="status-indicator text-white small">
              <span class="status-dot-active"></span> ModSecurity WAF Status: Active & Blocking
            </span>
          </div>
          <h1 class="display-6 fw-bold mb-2">Welcome, <?= $user ?></h1>
          <p class="text-white-50 mb-0">
            <?= $isAdmin 
                ? 'NxtGen Enterprise Administration Console — Manage infrastructure topology, WAF policies, and security telemetry.' 
                : 'NxtGen Organization Workspace — Access operational tools, monitor services, and review security runbooks.' ?>
          </p>
        </div>
        <div class="col-md-4 text-md-end mt-3 mt-md-0">
          <div class="d-inline-block text-start bg-white bg-opacity-10 backdrop-blur rounded-3 p-3 text-white border border-white border-opacity-10">
            <div class="small text-white-50">Organization ID</div>
            <div class="fw-bold font-monospace">ORG-8842-NXT</div>
            <div class="small text-white-50 mt-1">WAF Layer: <span class="text-success font-monospace">ModSec v3 + OWASP CRS</span></div>
          </div>
        </div>
      </div>
    </div>

    <?php if ($isAdmin): ?>
      <!-- ================= ADMIN DASHBOARD VIEW ================= -->
      
      <!-- Key Admin Metrics -->
      <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Active Services</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-cpu"></i></div>
            </div>
            <div class="fs-2 fw-bold">31</div>
            <div class="small text-success"><i class="bi bi-arrow-up-short"></i> 30 Operational · 1 Maintenance</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">WAF Threat Blocks</span>
              <div class="icon-circle bg-teal-soft text-teal" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-shield-x"></i></div>
            </div>
            <div class="fs-2 fw-bold text-teal">1,482</div>
            <div class="small text-muted"><i class="bi bi-check-circle-fill text-success me-1"></i> OWASP CRS Rules Active</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Org Accounts</span>
              <div class="icon-circle bg-amber-soft text-amber" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-people"></i></div>
            </div>
            <div class="fs-2 fw-bold">142</div>
            <div class="small text-muted">3 Admins · 139 Analysts</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Security Posture</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-shield-check"></i></div>
            </div>
            <div class="fs-2 fw-bold text-success">100<span class="fs-6 text-muted">/100</span></div>
            <div class="small text-success"><i class="bi bi-shield-fill-check me-1"></i> Enterprise Hardened</div>
          </div>
        </div>
      </div>

      <!-- Main Admin Grid -->
      <div class="row g-4 mb-4">
        <!-- Company & System Specification Card -->
        <div class="col-lg-7">
          <div class="dash-card p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h5 class="fw-bold mb-0"><i class="bi bi-building-gear me-2 text-indigo"></i>Company Details & System Specification</h5>
              <span class="badge bg-indigo-soft text-indigo">v5.0 Secure Stack</span>
            </div>
            <p class="text-muted small mb-4">Core infrastructure topology, reverse proxy rules, and firewall status for NxtGen Production Cluster.</p>
            
            <div class="row g-3">
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">Subscription Tier</div>
                  <div class="fw-bold">Enterprise Unlimited</div>
                  <div class="small text-success mt-1"><i class="bi bi-patch-check-fill me-1"></i> Active License</div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">Primary Database Cluster</div>
                  <div class="fw-bold">MariaDB / MySQL Engine</div>
                  <div class="small text-muted mt-1">Host: <code>db:3306</code> (Least Privilege)</div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">WAF Audit Telemetry</div>
                  <div class="fw-bold">JSON Audit Stream</div>
                  <div class="small text-teal mt-1"><i class="bi bi-broadcast me-1"></i> Wazuh Ingestion Active</div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">Intrusion Prevention</div>
                  <div class="fw-bold">Fail2Ban & CrowdSec</div>
                  <div class="small text-success mt-1"><i class="bi bi-shield-fill-check me-1"></i> Dual Protection</div>
                </div>
              </div>
            </div>

            <!-- Admin Quick Actions -->
            <div class="mt-4 pt-3 border-top">
              <span class="small fw-bold text-uppercase text-muted me-3">Quick Controls:</span>
              <div class="d-inline-flex flex-wrap gap-2 mt-2 mt-sm-0">
                <button class="btn btn-sm btn-outline-secondary" onclick="alert('ModSecurity rules reloaded.')"><i class="bi bi-arrow-repeat me-1"></i> Reload WAF</button>
                <button class="btn btn-sm btn-outline-secondary" onclick="alert('Backup pipeline triggered.')"><i class="bi bi-download me-1"></i> Trigger Backup</button>
                <button class="btn btn-sm btn-accent" onclick="alert('Security policy synced.')"><i class="bi bi-key me-1"></i> Sync Policies</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Infrastructure Service Status -->
        <div class="col-lg-5">
          <div class="dash-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="bi bi-server me-2 text-teal"></i>Core Security Stack Matrix</h5>
            <div class="list-group list-group-flush border-0">
              
              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">Nginx Reverse Proxy</div>
                  <div class="small text-muted"><code>TLS 1.3 · HTTP/2</code></div>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle-fill me-1"></i> Protected</span>
              </div>

              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">ModSecurity v3 WAF</div>
                  <div class="small text-muted"><code>SecRuleEngine On</code></div>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-shield-fill-check me-1"></i> Blocking Mode</span>
              </div>

              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">OWASP Core Rule Set</div>
                  <div class="small text-muted"><code>CRS v4.0 Protection</code></div>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle-fill me-1"></i> Enforced</span>
              </div>

              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">PHP-FPM Backend</div>
                  <div class="small text-muted"><code>Non-Root Container</code></div>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle-fill me-1"></i> Isolated</span>
              </div>

            </div>
          </div>
        </div>
      </div>

    <?php else: ?>
      <!-- ================= USER / ANALYST DASHBOARD VIEW ================= -->
      
      <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Assigned Tasks</span>
              <div class="icon-circle bg-amber-soft text-amber" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-ticket-perforated"></i></div>
            </div>
            <div class="fs-2 fw-bold text-amber">1</div>
            <div class="small text-muted">Priority: Low · Review Security Logs</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Active Services</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-check2-square"></i></div>
            </div>
            <div class="fs-2 fw-bold">31</div>
            <div class="small text-success"><i class="bi bi-check-circle-fill me-1"></i> All Operational</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Compliance</span>
              <div class="icon-circle bg-teal-soft text-teal" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-award"></i></div>
            </div>
            <div class="fs-2 fw-bold text-teal">100%</div>
            <div class="small text-muted">MFA & Security Hardened</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">SLO Compliance</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-graph-up-arrow"></i></div>
            </div>
            <div class="fs-2 fw-bold text-success">99.9%</div>
            <div class="small text-muted">Target: 99.5%</div>
          </div>
        </div>
      </div>

    <?php endif; ?>

  </div>
</main>

<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
