# NxtGen Enterprise Web Application Firewall & Kali Linux Native Server

## 🛡️ Executive Summary & Security Architecture

This repository contains the complete, production-ready enterprise security deployment for **NxtGen**, engineered to run natively on **Kali Linux terminal on localhost** (or Debian/Ubuntu Linux). All YAML files and Docker abstractions have been removed in favor of native system services.

### 🌐 Native Kali Architecture & Traffic Pipeline

```
Localhost / Kali Browser (https://localhost/ or https://127.0.0.1/)
       │
Nginx Hardened Reverse Proxy (TLS 1.3 / HTTP/2 / Rate Limiters / Security Headers)
       │
ModSecurity v3 Engine (SecRuleEngine On / JSON Audit Logs)
       │
OWASP Core Rule Set (CRS v4.0 / Anomaly Scoring Threshold = 5)
       │
Custom Organization Rules (Admin Protection / Scanner Block / Path Traversal / Honeypots)
       │
PHP-FPM Backend Service (Unix Socket / Session Hardened / CSRF Protected / Non-Root)
       │
MariaDB / MySQL Database (Least Privilege Users / Prepared Statements)
```

---

## 📁 Repository Directory Structure

```
nxtgen-website/
│
├── app/
│   ├── admin/
│   │   └── index.php              # Authenticated Admin Zone & Enumeration Guard
│   ├── includes/
│   │   ├── db.php                 # PDO Prepared Statement Connection Engine
│   │   ├── security.php           # Session Hardening, Rate Limiter & Sanitization
│   │   ├── csrf.php               # Anti-CSRF Token Generation & Verification
│   │   ├── navbar.php             # Unified Navigation Header
│   │   └── footer.php             # Standardized Footer
│   ├── css/                       # Visual Stylesheets
│   ├── js/                        # Client Scripts
│   ├── about.php                  # Company Overview
│   ├── careers.php                # Careers Page
│   ├── contact.php                # Contact Form (CSRF + Honeypot + Rate Limited)
│   ├── dashboard.php              # Session-Validated Operations & Admin Console
│   ├── index.php                  # Landing Page
│   ├── login.php                  # Authentication Portal (Prepared PDO + Rate Limit 5/min)
│   ├── logout.php                 # Safe Session Destruction
│   ├── platform.php               # Platform Overview
│   ├── robots.txt                 # Search Engine Directives
│   ├── search.php                 # Sanitized KB Search (XSS Protected)
│   ├── solutions.php              # Solutions Matrix
│   └── .env.example               # Environment Configuration Blueprint
│
├── database/
│   ├── init-db.sql                # Hardened DB Schema, Users & BCRYPT Passwords
│   └── my.cnf                     # MySQL Security Directives & Performance Tuning
│
├── infrastructure/
│   ├── nginx/
│   │   ├── nginx.conf             # Main Nginx Config (JSON Logging, Rate Limit Zones)
│   │   ├── conf.d/
│   │   │   └── default.conf       # Localhost Virtual Host & FastCGI Unix Socket Proxy
│   │   └── security-headers.conf  # HSTS, CSP, X-Frame-Options, Permissions Policy
│   ├── modsecurity/
│   │   ├── modsecurity.conf       # ModSec v3 Directives & JSON Audit Logging
│   │   ├── crs-setup.conf         # OWASP Core Rule Set Setup
│   │   └── rules/
│   │       └── custom-rules.conf  # NxtGen Organization-Specific WAF Rules
│   ├── fail2ban/
│   │   ├── jail.local             # Auto-Ban Configuration (5 retries = 1hr ban)
│   │   └── filter.d/              # Filters for Nginx Rate Limit, Login Brute-force & PHP
│   ├── ssl/
│   │   ├── generate-certs.sh      # Self-Signed / Staging TLS Cert Generator
│   │   └── ssl.conf               # TLS 1.3 & Cipher Suite Enforcement
│   └── backups/
│       ├── backup.sh              # AES-256 Encrypted Automated Backup Engine
│       └── crontab.example        # Backup Execution Schedule
│
├── setup-kali.sh                  # Automated One-Click Installer for Kali Linux
└── README.md                      # Comprehensive Architecture & Operations Documentation
```

---

## ⚡ Quick Start: Running on Kali Linux Terminal

Execute the automated installer in your Kali Linux terminal:

```bash
# 1. Clone or navigate to the repository folder
cd nxtgen-website

# 2. Run the automated Kali installer with root privileges
sudo bash setup-kali.sh
```

### What `setup-kali.sh` Automates:
1. **Package Installation:** Installs `nginx`, `libnginx-mod-http-modsecurity`, `modsecurity-crs`, `php-fpm`, `php-mysql`, `mariadb-server`, `fail2ban`, `openssl`, and `ufw`.
2. **File Deployment:** Deploys web application code to `/var/www/nxtgen` under `www-data` ownership.
3. **SSL Certificates:** Generates TLS 1.3 4096-bit RSA self-signed certificates into `/etc/ssl/nxtgen/`.
4. **Database Hardening:** Starts MariaDB and creates least-privilege users (`app_user`, `readonly`, `db_admin`) from `database/init-db.sql`.
5. **ModSecurity & WAF Rules:** Deploys `modsecurity.conf`, `crs-setup.conf`, and custom protection rules to `/etc/modsecurity/`.
6. **Reverse Proxy & Fail2Ban:** Configures Nginx reverse proxy with FastCGI socket proxying and sets up Fail2Ban jails.
7. **Automated Verification:** Executes automated curl tests for HTTPS connectivity, scanner blocking (sqlmap), and path traversal protection.

---

## 🧪 Testing WAF Protection on Kali Localhost

Open a terminal on Kali and run the following tests:

### Test 1: Scanner Tool User-Agent Blocking (sqlmap)
```bash
curl -k -i -A "sqlmap/1.5#stable" https://localhost/
# Expected Result: HTTP/1.1 403 Forbidden
```

### Test 2: Path Traversal Attack Blocking
```bash
curl -k -i "https://localhost/index.php?file=../../../../etc/passwd"
# Expected Result: HTTP/1.1 403 Forbidden
```

### Test 3: Rate Limiting Verification (Login Endpoint)
```bash
for i in {1..7}; do curl -k -i -X POST https://localhost/login.php; done
# Expected Result: HTTP/1.1 429 Too Many Requests after 5 attempts
```

### Test 4: Blocked Direct File Access
```bash
curl -k -i https://localhost/includes/db.php
# Expected Result: HTTP/1.1 404 Not Found
```

---

## 🔒 Implemented Security Features

- **ModSecurity v3 Engine:** `SecRuleEngine On` with JSON audit logging to `/var/log/modsecurity/modsec_audit.log`.
- **OWASP CRS v4.0:** Active defense against SQLi, XSS, RCE, LFI/RFI, Command Injection, Path Traversal, and Protocol Abuse.
- **CSRF & Rate Limiting:** Form tokens and 5 req/min rate limits on authentication forms.
- **Prepared Statements:** MariaDB access using PDO prepared statements and BCRYPT hashed passwords.
- **Fail2Ban:** Auto-bans offensive IPs for 1 hour after 5 failed authentication attempts.
- **Encrypted Backups:** AES-256 encrypted backups script located at `/usr/local/bin/nxtgen-backup.sh`.
