# NxtGen — Startup Company Website (Lab)

Professional fictional company site for cybersecurity training.

**Company:** NxtGen — Next-Generation Digital Transformation  
**Purpose:** Authorized local attack / defense / triage demos only.

## Quick start

```bash
cd nxtgen-website
docker compose up -d --build
```

Open **http://127.0.0.1:8080**

| Account  | Password    |
|----------|-------------|
| admin    | admin123    |
| analyst  | secure2024  |

## Intentional vulnerabilities (lab)

| Endpoint       | Type              |
|----------------|-------------------|
| `/login.php`   | SQL Injection     |
| `/search.php`  | Reflected XSS     |
| `/admin/`      | Directory targets |

## Pair with Vulnerability Triage

1. Attack NxtGen (sqlmap, XSS payload, gobuster).
2. Record findings in the **Personalised Vulnerability Triage** platform.
3. Severity **Low / Medium** → auto-patch simulation.
4. Severity **High / Critical** → SOC email alert simulation.

Do **not** expose this site to the public internet.
