<?php
session_start();
$page = 'login';
require_once 'includes/db.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'] ?? '';
  $password = $_POST['password'] ?? '';
  if ($pdo) {
    $sql = "SELECT id, username, role FROM users WHERE username = '$username' AND password = '$password' LIMIT 1";
    try {
      $row = $pdo->query($sql)->fetch();
      if ($row) {
        $_SESSION['user'] = $row['username'];
        $_SESSION['role'] = $row['role'];
        header('Location: /dashboard.php');
        exit;
      }
      $error = 'Invalid credentials.';
    } catch (Exception $e) {
      $error = 'Query error: ' . htmlspecialchars($e->getMessage());
    }
  } else {
    $error = 'Database unavailable.';
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign in — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 d-flex align-items-center py-5">
  <div class="container">
    <div class="auth-card card border-0 shadow-lg">
      <div class="card-body p-4 p-md-5">
        <div class="text-center mb-4">
          <div class="icon-circle bg-indigo-soft text-indigo mx-auto mb-2"><i class="bi bi-person-lock"></i></div>
          <h1 class="h4 fw-bold">Sign in to NxtGen</h1>
          <p class="text-muted small mb-0">Customer & partner portal</p>
        </div>
        <?php if ($error): ?><div class="alert alert-danger py-2"><?= $error ?></div><?php endif; ?>
        <form method="post" action="/login.php" autocomplete="off">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control form-control-lg" required>
          </div>
          <div class="mb-4">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control form-control-lg" required>
          </div>
          <button type="submit" class="btn btn-accent w-100 btn-lg">Sign in</button>
        </form>
      </div>
    </div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
