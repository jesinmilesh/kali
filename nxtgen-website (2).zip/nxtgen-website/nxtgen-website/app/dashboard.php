<?php
session_start();
if (empty($_SESSION['user'])) { header('Location: /login.php'); exit; }
$page = 'dashboard';
$user = $_SESSION['user'];
$role = $_SESSION['role'] ?? 'user';
$isAdmin = ($role === 'admin' || strtolower($user) === 'admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $isAdmin ? 'Admin Console' : 'User Portal' ?> — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">
<?php include 'includes/navbar.php'; ?>

<main class="flex-grow-1 py-4">
  <div class="container">
    
    <!-- Top Welcome Header Banner -->
    <div class="dash-header-banner text-white p-4 p-md-5 mb-4 position-relative overflow-hidden">
      <div class="row align-items-center position-relative" style="z-index: 2;">
        <div class="col-md-8">
          <div class="d-flex align-items-center gap-2 mb-2">
            <span class="badge <?= $isAdmin ? 'badge-role-admin' : 'badge-role-user' ?> px-3 py-1 rounded-pill">
              <i class="bi <?= $isAdmin ? 'bi-shield-lock-fill' : 'bi-person-badge-fill' ?> me-1"></i>
              Role: <?= htmlspecialchars(ucfirst($role)) ?>
            </span>
            <span class="text-white-50 small">|</span>
            <span class="status-indicator text-white small">
              <span class="status-dot-active"></span> System Status: Operational
            </span>
          </div>
          <h1 class="display-6 fw-bold mb-2">Welcome, <?= htmlspecialchars($user) ?></h1>
          <p class="text-white-50 mb-0">
            <?= $isAdmin 
                ? 'NxtGen Enterprise Administration Console — Manage infrastructure, identity roles, and company telemetry.' 
                : 'NxtGen Organization Workspace — Monitor services, access runbooks, and manage assigned operational tasks.' ?>
          </p>
        </div>
        <div class="col-md-4 text-md-end mt-3 mt-md-0">
          <div class="d-inline-block text-start bg-white bg-opacity-10 backdrop-blur rounded-3 p-3 text-white border border-white border-opacity-10">
            <div class="small text-white-50">Organization ID</div>
            <div class="fw-bold font-monospace">ORG-8842-NXT</div>
            <div class="small text-white-50 mt-1">Primary Region: <span class="text-white font-monospace">us-west-2</span></div>
          </div>
        </div>
      </div>
    </div>

    <?php if ($isAdmin): ?>
      <!-- ================= ADMIN DASHBOARD VIEW ================= -->
      
      <!-- Key Admin Metrics -->
      <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Active Services</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-cpu"></i></div>
            </div>
            <div class="fs-2 fw-bold">31</div>
            <div class="small text-success"><i class="bi bi-arrow-up-short"></i> 30 Operational · 1 Maintenance</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">System Health</span>
              <div class="icon-circle bg-teal-soft text-teal" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-activity"></i></div>
            </div>
            <div class="fs-2 fw-bold text-teal">99.98%</div>
            <div class="small text-muted"><i class="bi bi-check-circle-fill text-success me-1"></i> SLO Target Exceeded</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Org Accounts</span>
              <div class="icon-circle bg-amber-soft text-amber" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-people"></i></div>
            </div>
            <div class="fs-2 fw-bold">142</div>
            <div class="small text-muted">3 Admins · 139 Analysts</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Security Posture</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-shield-check"></i></div>
            </div>
            <div class="fs-2 fw-bold text-success">98<span class="fs-6 text-muted">/100</span></div>
            <div class="small text-success"><i class="bi bi-shield-fill-check me-1"></i> Zero Critical Deficiencies</div>
          </div>
        </div>
      </div>

      <!-- Main Admin Grid -->
      <div class="row g-4 mb-4">
        <!-- Company & System Specification Card -->
        <div class="col-lg-7">
          <div class="dash-card p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h5 class="fw-bold mb-0"><i class="bi bi-building-gear me-2 text-indigo"></i>Company Details & System Specification</h5>
              <span class="badge bg-indigo-soft text-indigo">v4.2 Enterprise</span>
            </div>
            <p class="text-muted small mb-4">Core infrastructure topology and deployment parameters for NxtGen Production Cluster.</p>
            
            <div class="row g-3">
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">Subscription Tier</div>
                  <div class="fw-bold">Enterprise Unlimited</div>
                  <div class="small text-success mt-1"><i class="bi bi-patch-check-fill me-1"></i> Active License</div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">Primary Database Cluster</div>
                  <div class="fw-bold">MariaDB v10.11 Engine</div>
                  <div class="small text-muted mt-1">Host: <code>db:3306</code> (Healthy)</div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">SIEM & Telemetry Feed</div>
                  <div class="fw-bold">14,200 Events / sec</div>
                  <div class="small text-teal mt-1"><i class="bi bi-broadcast me-1"></i> Live Stream Active</div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-light border">
                  <div class="text-muted small">Global Disaster Recovery</div>
                  <div class="fw-bold">RPO &lt; 5s · RTO &lt; 1m</div>
                  <div class="small text-muted mt-1">Auto-Failover Enabled</div>
                </div>
              </div>
            </div>

            <!-- Admin Quick Actions -->
            <div class="mt-4 pt-3 border-top">
              <span class="small fw-bold text-uppercase text-muted me-3">Quick Controls:</span>
              <div class="d-inline-flex flex-wrap gap-2 mt-2 mt-sm-0">
                <button class="btn btn-sm btn-outline-secondary" onclick="alert('System cache cleared successfully.')"><i class="bi bi-arrow-repeat me-1"></i> Flush Caches</button>
                <button class="btn btn-sm btn-outline-secondary" onclick="alert('Compliance audit scheduled.')"><i class="bi bi-file-earmark-check me-1"></i> Audit Report</button>
                <button class="btn btn-sm btn-accent" onclick="alert('Identity policy synced across all nodes.')"><i class="bi bi-key me-1"></i> Sync Roles</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Infrastructure Service Status -->
        <div class="col-lg-5">
          <div class="dash-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="bi bi-server me-2 text-teal"></i>Core Service Matrix</h5>
            <div class="list-group list-group-flush border-0">
              
              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">Auth & Identity Service</div>
                  <div class="small text-muted"><code>auth.nxtgen.io</code></div>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle-fill me-1"></i> 100% Up</span>
              </div>

              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">Core API Gateway</div>
                  <div class="small text-muted"><code>api.nxtgen.io</code></div>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle-fill me-1"></i> 99.99% Up</span>
              </div>

              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">MariaDB Database Cluster</div>
                  <div class="small text-muted"><code>db.nxtgen.io</code> (Primary)</div>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle-fill me-1"></i> Healthy (0.8ms)</span>
              </div>

              <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center border-0">
                <div>
                  <div class="fw-semibold">Billing & Metering Engine</div>
                  <div class="small text-muted"><code>billing.nxtgen.io</code></div>
                </div>
                <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-2 py-1"><i class="bi bi-exclamation-triangle-fill me-1"></i> Maintenance</span>
              </div>

            </div>
          </div>
        </div>
      </div>

      <!-- Identity & Recent Access Logs Table -->
      <div class="dash-card p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="fw-bold mb-0"><i class="bi bi-journal-text me-2 text-indigo"></i>Organization Identity & Access Logs</h5>
          <span class="small text-muted">Real-time Session Telemetry</span>
        </div>
        <div class="table-responsive">
          <table class="table table-dash table-hover align-middle mb-0">
            <thead>
              <tr>
                <th>Username</th>
                <th>Assigned Role</th>
                <th>Status</th>
                <th>Source IP</th>
                <th>Last Active</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <div class="fw-bold text-dark">admin</div>
                  <div class="small text-muted">admin@nxtgen.io</div>
                </td>
                <td><span class="badge badge-role-admin">Admin</span></td>
                <td><span class="status-indicator"><span class="status-dot-active"></span> Active</span></td>
                <td><code>10.0.4.12</code></td>
                <td>Just now</td>
                <td class="text-end"><button class="btn btn-sm btn-light border" onclick="alert('Admin session details verified.')">View</button></td>
              </tr>
              <tr>
                <td>
                  <div class="fw-bold text-dark">analyst</div>
                  <div class="small text-muted">analyst@nxtgen.io</div>
                </td>
                <td><span class="badge badge-role-user">User</span></td>
                <td><span class="status-indicator"><span class="status-dot-active"></span> Active</span></td>
                <td><code>10.0.4.88</code></td>
                <td>12 mins ago</td>
                <td class="text-end"><button class="btn btn-sm btn-light border" onclick="alert('Analyst session details verified.')">View</button></td>
              </tr>
              <tr>
                <td>
                  <div class="fw-bold text-dark">partner</div>
                  <div class="small text-muted">partner@nxtgen.io</div>
                </td>
                <td><span class="badge badge-role-user">Partner</span></td>
                <td><span class="status-indicator"><span class="status-dot-active"></span> Idle</span></td>
                <td><code>192.168.1.105</code></td>
                <td>2 hours ago</td>
                <td class="text-end"><button class="btn btn-sm btn-light border" onclick="alert('Partner session details verified.')">View</button></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    <?php else: ?>
      <!-- ================= USER / ANALYST DASHBOARD VIEW ================= -->
      
      <!-- Key User Metrics -->
      <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Assigned Incidents</span>
              <div class="icon-circle bg-amber-soft text-amber" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-ticket-perforated"></i></div>
            </div>
            <div class="fs-2 fw-bold text-amber">1</div>
            <div class="small text-muted">Priority: Low · Requires Review</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Active Services</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-check2-square"></i></div>
            </div>
            <div class="fs-2 fw-bold">31</div>
            <div class="small text-success"><i class="bi bi-check-circle-fill me-1"></i> All Operational</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">Compliance</span>
              <div class="icon-circle bg-teal-soft text-teal" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-award"></i></div>
            </div>
            <div class="fs-2 fw-bold text-teal">100%</div>
            <div class="small text-muted">Training & Certs Completed</div>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="dash-card p-3 p-md-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="text-muted small fw-semibold">SLO Compliance</span>
              <div class="icon-circle bg-indigo-soft text-indigo" style="width:36px; height:36px; font-size:1.1rem;"><i class="bi bi-graph-up-arrow"></i></div>
            </div>
            <div class="fs-2 fw-bold text-success">99.6%</div>
            <div class="small text-muted">Target: 99.5%</div>
          </div>
        </div>
      </div>

      <!-- Main User Workspace Grid -->
      <div class="row g-4">
        <!-- Assigned Tasks & Tickets -->
        <div class="col-lg-7">
          <div class="dash-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="bi bi-kanban me-2 text-indigo"></i>My Active Operational Tasks</h5>
            <div class="list-group list-group-flush border-0">
              
              <div class="list-group-item px-0 py-3 border-bottom">
                <div class="d-flex justify-content-between align-items-start mb-1">
                  <h6 class="fw-bold mb-0">Task #INC-4092: API Rate Limit Monitor Threshold Review</h6>
                  <span class="badge bg-warning-subtle text-warning">In Progress</span>
                </div>
                <p class="text-muted small mb-2">Verify rate-limit alerts for high-throughput endpoints on <code>api.nxtgen.io</code>.</p>
                <div class="d-flex gap-2">
                  <button class="btn btn-sm btn-accent" onclick="alert('Task #INC-4092 marked as complete.')">Complete Task</button>
                  <button class="btn btn-sm btn-light border" onclick="alert('Task details opened.')">Details</button>
                </div>
              </div>

              <div class="list-group-item px-0 py-3 border-0">
                <div class="d-flex justify-content-between align-items-start mb-1">
                  <h6 class="fw-bold mb-0">Task #INC-4085: Annual Identity & SOC Access Certification</h6>
                  <span class="badge bg-success-subtle text-success">Completed</span>
                </div>
                <p class="text-muted small mb-0">Identity privileges verified for Q3 operations audit.</p>
              </div>

            </div>
          </div>
        </div>

        <!-- Quick User Tools & Knowledge Links -->
        <div class="col-lg-5">
          <div class="dash-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="bi bi-tools me-2 text-teal"></i>Analyst Tools & Resources</h5>
            <div class="d-grid gap-2 mb-4">
              <a href="/search.php" class="btn btn-outline-primary text-start p-3">
                <i class="bi bi-search me-2"></i><strong>Search Documentation</strong>
                <div class="small text-muted">Access runbooks, API references & guides.</div>
              </a>
              <button class="btn btn-outline-dark text-start p-3" onclick="alert('SSL Certificate downloaded.')">
                <i class="bi bi-shield-lock me-2"></i><strong>Download Org SSL Root CA</strong>
                <div class="small text-muted">Required for internal microservice TLS.</div>
              </button>
            </div>
            <div class="p-3 bg-light rounded-3 border">
              <div class="fw-bold small mb-1"><i class="bi bi-headset me-1 text-indigo"></i> Need Operations Support?</div>
              <p class="small text-muted mb-0">Contact the 24/7 SOC Operations Desk via internal channel <code>#ops-soc-escalation</code>.</p>
            </div>
          </div>
        </div>
      </div>

    <?php endif; ?>

  </div>
</main>

<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
