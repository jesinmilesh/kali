<?php http_response_code(403); ?>
<!DOCTYPE html><html><head><title>Forbidden</title></head>
<body><h1>403 Forbidden</h1><p>Admin area — restricted.</p></body></html>
