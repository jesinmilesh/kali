<?php
session_start();
$page = 'contact';
$sent = false;
$name = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'] ?? '';
  $sent = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact — NxtGen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'includes/navbar.php'; ?>
<main class="flex-grow-1 py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-7">
        <h1 class="h3 fw-bold mb-2">Contact sales</h1>
        <p class="text-muted mb-4">Request a demo or discuss security, pricing, and onboarding.</p>
        <?php if ($sent): ?>
          <div class="alert alert-success">Thanks<?= $name ? ', ' . htmlspecialchars($name) : '' ?>. Our team will respond shortly.</div>
        <?php endif; ?>
        <form method="post" class="card border-0 shadow-sm">
          <div class="card-body p-4">
            <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">Work email</label><input type="email" name="email" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">Company</label><input type="text" name="company" class="form-control"></div>
            <div class="mb-3"><label class="form-label">Message</label><textarea name="message" class="form-control" rows="4" required></textarea></div>
            <button type="submit" class="btn btn-accent">Send message</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
