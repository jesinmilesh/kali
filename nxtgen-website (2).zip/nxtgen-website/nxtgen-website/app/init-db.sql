CREATE DATABASE IF NOT EXISTS nxtgen;
USE nxtgen;
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL,
  password VARCHAR(128) NOT NULL,
  role VARCHAR(32) DEFAULT 'user'
);
INSERT INTO users (username, password, role) VALUES
  ('admin', 'admin123', 'admin'),
  ('analyst', 'secure2024', 'user'),
  ('partner', 'demo-access', 'partner')
ON DUPLICATE KEY UPDATE username=username;
