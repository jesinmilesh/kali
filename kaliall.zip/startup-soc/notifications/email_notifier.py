import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timezone
from typing import List, Dict

def _load_env_file():
    env_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".env"))
    if os.path.exists(env_path):
        try:
            with open(env_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        os.environ.setdefault(k.strip(), v.strip())
        except Exception:
            pass

_load_env_file()

class EmailNotifier:
    """
    Handles emergency SMTP email alert dispatches for High and Critical security events.
    Supports real Gmail/SMTP relays (with App Passwords) or local fallback logging.
    """
    def __init__(self, 
                 smtp_server: str = None, 
                 smtp_port: int = None, 
                 sender: str = None, 
                 recipients: List[str] = None):
        
        # Load from environment variables or defaults
        self.smtp_server = smtp_server or os.getenv("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = int(smtp_port or os.getenv("SMTP_PORT", "587"))
        self.sender = sender or os.getenv("SMTP_USER", "jesinmilesh@gmail.com")
        
        raw_pwd = os.getenv("SMTP_PASSWORD", "smavbwsgcsuuxybj")
        self.password = raw_pwd.replace(" ", "") # Remove spaces if passed as "smav bwsg csuu xybj"
        
        self.recipients = recipients or [os.getenv("ALERT_EMAIL", "jesinmilesh@gmail.com")]
        self.sent_emails_log: List[dict] = []

    def send_emergency_alert(self, event: dict) -> bool:
        incident_id = event.get("id", f"INC-{int(datetime.now(timezone.utc).timestamp())}")
        severity = event.get("severity", "CRITICAL")
        attack_type = event.get("attack_type", "Unknown Threat")
        ip = event.get("client_ip", "0.0.0.0")
        country = event.get("country", "Unknown")
        time_str = event.get("timestamp", datetime.now(timezone.utc).isoformat())
        affected_page = event.get("uri", "/")
        waf_rule = event.get("rule_id", "CRS-942100")
        recommended_action = event.get("recommended_action", "Immediate IP Quarantine & Session Revocation")

        subject = f"🚨 {severity.upper()} Security Incident Alert - [{incident_id}]"

        html_body = f"""
        <html>
        <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0f172a; color: #f8fafc; padding: 20px;">
            <div style="max-width: 650px; margin: 0 auto; background: #1e293b; border-radius: 12px; padding: 25px; border: 1px solid #334155;">
                <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #ef4444; padding-bottom: 15px;">
                    <h2 style="color: #ef4444; margin: 0;">🚨 Enterprise SOC Emergency Alert</h2>
                    <span style="background-color: #ef4444; color: #fff; padding: 4px 12px; border-radius: 20px; font-weight: bold; font-size: 14px;">{severity}</span>
                </div>

                <div style="margin-top: 20px;">
                    <p style="font-size: 16px; color: #cbd5e1;">Continuous Automated Security Operations detected a high-priority threat targeting corporate infrastructure.</p>
                </div>

                <table style="width: 100%; border-collapse: collapse; margin-top: 15px; background: #0f172a; border-radius: 8px; overflow: hidden;">
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Incident ID</td><td style="padding: 10px 15px; font-weight: bold; color: #38bdf8;">{incident_id}</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Attack Vector</td><td style="padding: 10px 15px; font-weight: bold; color: #f43f5e;">{attack_type}</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Attacker IP</td><td style="padding: 10px 15px; font-weight: bold; color: #fbbf24;">{ip} ({country})</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Device Hostname</td><td style="padding: 10px 15px; font-weight: bold; color: #00f2fe;">{event.get('device_name', 'device-' + ip.replace('.', '-'))}</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Device Type & OS</td><td style="padding: 10px 15px; color: #e2e8f0;">{event.get('device_type', 'Desktop PC')} — {event.get('device_os', 'Linux/Windows')}</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Browser / Software</td><td style="padding: 10px 15px; color: #a855f7;">{event.get('browser', 'HTTP Client')} ({event.get('user_agent', 'N/A')[:40]}...)</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Detection Time</td><td style="padding: 10px 15px; color: #e2e8f0;">{time_str}</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">Target Endpoint</td><td style="padding: 10px 15px; color: #a855f7;">{affected_page}</td></tr>
                    <tr style="border-bottom: 1px solid #334155;"><td style="padding: 10px 15px; color: #94a3b8;">ModSecurity Rule</td><td style="padding: 10px 15px; color: #e2e8f0;">OWASP CRS {waf_rule}</td></tr>
                    <tr><td style="padding: 10px 15px; color: #94a3b8;">Recommended Action</td><td style="padding: 10px 15px; color: #4ade80; font-weight: bold;">{recommended_action}</td></tr>
                </table>

                <div style="margin-top: 20px; background: #020617; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 12px; color: #38bdf8; border: 1px solid #1e293b;">
                    <strong>Raw Telemetry Payload:</strong><br/>
                    {event.get('raw', 'N/A')}
                </div>

                <div style="margin-top: 25px; font-size: 12px; color: #64748b; text-align: center;">
                    NxtGen Automated SOC Orchestrator — Automated Response Protocol Triggered (SOAR Policy Executed)
                </div>
            </div>
        </body>
        </html>
        """

        email_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "incident_id": incident_id,
            "subject": subject,
            "recipients": self.recipients,
            "body": html_body,
            "severity": severity
        }
        self.sent_emails_log.append(email_record)

        import threading

        def _dispatch_smtp():
            try:
                msg = MIMEMultipart("alternative")
                msg["Subject"] = subject
                msg["From"] = self.sender
                msg["To"] = ", ".join(self.recipients)
                msg.attach(MIMEText(html_body, "html"))

                if self.password:
                    with smtplib.SMTP(self.smtp_server, self.smtp_port, timeout=10) as server:
                        server.starttls()
                        server.login(self.sender, self.password)
                        server.sendmail(self.sender, self.recipients, msg.as_string())
                    print(f"[+] REAL EMAIL DISPATCHED to {self.recipients} via {self.smtp_server}")
                else:
                    with smtplib.SMTP("localhost", 1025, timeout=2) as server:
                        server.sendmail(self.sender, self.recipients, msg.as_string())
            except Exception as e:
                print(f"[!] SMTP Dispatch exception: {e}")

        # Dispatch SMTP transmission asynchronously in background thread so HTTP API remains instant
        threading.Thread(target=_dispatch_smtp, daemon=True).start()

        return True

    def get_sent_emails(self) -> List[dict]:
        return self.sent_emails_log
