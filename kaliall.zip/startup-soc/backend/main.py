import sys
import os
import asyncio
from typing import List, Optional
from datetime import datetime, timezone
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Add root directory to python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from soc_engine.log_parser import LogParser
from soc_engine.severity_classifier import SeverityClassifier
from soc_engine.correlation_engine import CorrelationEngine
from soc_engine.soar_engine import SOAREngine
from soc_engine.auto_patcher import AutoPatcher
from soc_engine.ai_assistant import ClaudeSonnetAIAssistant, MythosAIAssistant
from soc_engine.nginx_log_monitor import NginxLogMonitor
from automation.firewall_manager import FirewallManager
from notifications.email_notifier import EmailNotifier
from threat_intelligence.threat_intel import ThreatIntelEngine
from monitoring.metrics_collector import MetricsCollector
from reports.report_generator import ReportGenerator
from logs.log_generator import LiveLogGenerator

app = FastAPI(
    title="Enterprise 24/7 Automated SOC Engine",
    description="SIEM, SOAR, WAF, Nginx Real-Time Telemetry & Automated Patching Engine",
    version="2.1.0"
)

# Enable CORS for React frontend & external web application
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Shared In-Memory SOC State & Engine Components
firewall_mgr = FirewallManager()
auto_patcher = AutoPatcher()
email_notifier = EmailNotifier(recipients=["jesinmilesh@gmail.com"])
correlation_eng = CorrelationEngine()
soar_eng = SOAREngine(firewall_manager=firewall_mgr, email_notifier=email_notifier, auto_patcher=auto_patcher)
metrics_coll = MetricsCollector()
nginx_monitor = NginxLogMonitor()

events_history: List[dict] = []
incidents_history: List[dict] = []
event_counter = 1000

class IngestWebRequest(BaseModel):
    client_ip: str
    method: str = "GET"
    uri: str
    user_agent: Optional[str] = "Mozilla/5.0"
    payload: Optional[str] = ""
    attack_type: Optional[str] = None

class BlockIPRequest(BaseModel):
    ip: str
    reason: str
    country: Optional[str] = "Manual Block"

class UnblockIPRequest(BaseModel):
    ip: str

class WhitelistIPRequest(BaseModel):
    ip: str

class AIChatRequest(BaseModel):
    prompt: str

# Core SOC Processing Pipeline
def process_event(raw_evt: dict) -> dict:
    global event_counter
    event_counter += 1
    
    ip = raw_evt.get("client_ip", "127.0.0.1")
    attack_type = raw_evt.get("attack_type", "Single 404")
    uri = raw_evt.get("uri", "/")
    modsec_sev = raw_evt.get("modsec_severity", "LOW")

    # Correlate frequency
    corr_result = correlation_eng.add_event(ip, attack_type, uri)
    final_attack_type = corr_result["correlated_attack"]

    # Classify Severity (0 - 10)
    sev_info = SeverityClassifier.classify(
        attack_type=final_attack_type,
        uri=uri,
        frequency=corr_result["frequency"],
        modsec_severity=modsec_sev
    )

    # Enrich Threat Intel
    t_intel = ThreatIntelEngine.enrich_ip(ip)

    # Extract device fingerprint
    user_agent = raw_evt.get("user_agent", "Mozilla/5.0")
    device_fp = LogParser.parse_device_fingerprint(user_agent)
    device_name = raw_evt.get("device_name") or LogParser.resolve_device_hostname(ip)

    full_event = {
        "id": raw_evt.get("id", f"EVT-{event_counter}"),
        "timestamp": raw_evt.get("timestamp") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": raw_evt.get("source", "nginx"),
        "client_ip": ip,
        "device_name": device_name,
        "device_os": device_fp["os"],
        "device_type": device_fp["device_type"],
        "browser": device_fp["browser"],
        "user_agent": user_agent,
        "country": t_intel["country"],
        "asn": t_intel["asn"],
        "abuse_score": t_intel["abuse_score"],
        "attack_type": final_attack_type,
        "uri": uri,
        "rule_id": raw_evt.get("rule_id", "CRS-942100"),
        "modsec_severity": modsec_sev,
        "severity": sev_info["severity"],
        "score": sev_info["score"],
        "color": sev_info["color"],
        "raw": raw_evt.get("raw", f"Real-time HTTP {raw_evt.get('method', 'GET')} request from {device_name} ({ip}) to {uri}")
    }

    # Execute SOAR Response Policy
    soar_result = soar_eng.execute_policy(full_event)
    full_event["blocked"] = soar_result["blocked"]
    full_event["email_sent"] = soar_result["email_sent"]
    full_event["patch_applied"] = soar_result.get("patch_applied")
    full_event["actions_taken"] = soar_result["actions_taken"]

    # Append to events history
    events_history.insert(0, full_event)
    if len(events_history) > 500:
        events_history.pop()

    # Create Incident Record for High & Critical
    if soar_result["incident_created"]:
        def _async_incident_logging(evt):
            try:
                ai_analysis = MythosAIAssistant.analyze_incident(evt)
                incident_entry = {
                    "incident_id": f"INC-{int(datetime.now(timezone.utc).timestamp())}",
                    "timestamp": evt["timestamp"],
                    "severity": evt["severity"],
                    "attack_type": evt["attack_type"],
                    "client_ip": evt["client_ip"],
                    "country": evt["country"],
                    "status": "AUTO_MITIGATED",
                    "actions_taken": evt["actions_taken"],
                    "ai_analysis": ai_analysis
                }
                incidents_history.insert(0, incident_entry)
                if len(incidents_history) > 100:
                    incidents_history.pop()
            except Exception as e:
                print(f"[!] Async incident logging error: {e}")

        import threading
        threading.Thread(target=_async_incident_logging, args=(full_event,), daemon=True).start()

    return full_event

# Real Server Log Tailer Integration
from logs.real_log_tailer import RealLogTailer
real_log_tailer = RealLogTailer()

@app.get("/")
def root():
    return {
        "status": "ONLINE", 
        "system": "Enterprise 24/7 Automated SOC Engine", 
        "target_email": "jesinmilesh@gmail.com",
        "version": "2.1.0"
    }

# Ingest live traffic from Nginx / Website Middleware
@app.post("/api/ingest/nginx")
def ingest_nginx_request(req: IngestWebRequest):
    # Log into Nginx log tailer
    log_line = nginx_monitor.append_web_request(req.client_ip, req.method, req.uri, req.user_agent)
    
    # Classify potential attack vectors
    payload_str = f"{req.uri} {req.payload or ''}"
    attack_type = req.attack_type or "Single 404"
    modsec_sev = "LOW"
    
    if not req.attack_type:
        if "select" in payload_str.lower() or "union" in payload_str.lower() or "or 1=1" in payload_str.lower():
            attack_type = "SQL Injection (SQLi)"
            modsec_sev = "CRITICAL"
        elif "<script>" in payload_str.lower() or "javascript:" in payload_str.lower() or "onload=" in payload_str.lower() or "onerror=" in payload_str.lower():
            attack_type = "Cross-Site Scripting (XSS)"
            modsec_sev = "HIGH"
        elif "cat /etc" in payload_str.lower() or "id;" in payload_str.lower() or "whoami" in payload_str.lower() or "cmd=" in payload_str.lower():
            attack_type = "Command Injection (RCE)"
            modsec_sev = "CRITICAL"
        elif "../.." in payload_str.lower() or "/etc/passwd" in payload_str.lower() or "win.ini" in payload_str.lower():
            attack_type = "Path Traversal"
            modsec_sev = "HIGH"
        elif "nikto" in (req.user_agent or "").lower() or "sqlmap" in (req.user_agent or "").lower() or "nmap" in (req.user_agent or "").lower() or "gobuster" in (req.user_agent or "").lower():
            attack_type = "Scanner Detection"
            modsec_sev = "MEDIUM"
        elif "login" in req.uri.lower() and ("failed" in payload_str.lower() or "wrongpass" in payload_str.lower() or "bad_credentials" in payload_str.lower() or "password" in payload_str.lower() or req.method == "POST"):
            attack_type = "Failed Login"
            modsec_sev = "MEDIUM"
        elif "/admin" in req.uri.lower() or ".env" in req.uri.lower() or ".git" in req.uri.lower():
            attack_type = "Admin Enumeration"
            modsec_sev = "MEDIUM"
        else:
            t_intel = ThreatIntelEngine.enrich_ip(req.client_ip)
            if t_intel and t_intel.get("abuse_score", 0) >= 80:
                attack_type = "Malicious IP Activity"
                modsec_sev = "HIGH"
    else:
        if "sql" in attack_type.lower() or "rce" in attack_type.lower() or "command" in attack_type.lower():
            modsec_sev = "CRITICAL"
        elif "xss" in attack_type.lower() or "traversal" in attack_type.lower() or "malicious" in attack_type.lower() or "brute" in attack_type.lower():
            modsec_sev = "HIGH"
        elif "scanner" in attack_type.lower() or "admin" in attack_type.lower() or "login" in attack_type.lower():
            modsec_sev = "MEDIUM"

    raw_event = {
        "source": "nginx",
        "client_ip": req.client_ip,
        "method": req.method,
        "uri": req.uri,
        "user_agent": req.user_agent,
        "attack_type": attack_type,
        "modsec_severity": modsec_sev,
        "raw": log_line
    }

    event_record = process_event(raw_event)
    return {"status": "INGESTED", "event": event_record}

@app.get("/api/dashboard/stats")
def get_dashboard_stats():
    total_attacks = len(events_history)
    critical_alerts = sum(1 for e in events_history if e["severity"] == "Critical")
    high_alerts = sum(1 for e in events_history if e["severity"] == "High")
    medium_alerts = sum(1 for e in events_history if e["severity"] == "Medium")
    low_alerts = sum(1 for e in events_history if e["severity"] == "Low")
    
    sqli_attempts = sum(1 for e in events_history if "SQL" in e["attack_type"])
    xss_attempts = sum(1 for e in events_history if "XSS" in e["attack_type"])
    failed_logins = sum(1 for e in events_history if "Login" in e["attack_type"] or "Brute" in e["attack_type"])
    waf_blocks = sum(1 for e in events_history if e["source"] in ["modsecurity", "nginx"])
    
    blocked_ips = firewall_mgr.get_blocked_ips()
    patches_count = len(auto_patcher.get_patches())
    health = metrics_coll.get_system_health()

    return {
        "total_attacks": total_attacks,
        "critical_alerts": critical_alerts,
        "high_alerts": high_alerts,
        "medium_alerts": medium_alerts,
        "low_alerts": low_alerts,
        "blocked_ips_count": len(blocked_ips),
        "auto_patches_count": patches_count,
        "sqli_attempts": sqli_attempts,
        "xss_attempts": xss_attempts,
        "failed_logins": failed_logins,
        "waf_blocks": waf_blocks,
        "alert_email_target": "jesinmilesh@gmail.com",
        "crowdsec_decisions": 14,
        "server_health": health
    }

@app.get("/api/events")
def get_events(limit: int = 50, severity: Optional[str] = None):
    filtered = events_history
    if severity:
        filtered = [e for e in filtered if e["severity"].lower() == severity.lower()]
    return filtered[:limit]

@app.get("/api/incidents")
def get_incidents():
    return incidents_history

@app.get("/api/patches")
def get_auto_patches():
    return auto_patcher.get_patches()

@app.get("/api/firewall/blocked")
def get_blocked_ips():
    return firewall_mgr.get_blocked_ips()

@app.post("/api/firewall/block")
def manual_block_ip(req: BlockIPRequest):
    success = firewall_mgr.block_ip(req.ip, reason=req.reason, country=req.country)
    return {"success": success, "ip": req.ip}

@app.post("/api/firewall/unblock")
def unblock_ip(req: UnblockIPRequest):
    success = firewall_mgr.unblock_ip(req.ip)
    return {"success": success, "ip": req.ip}

@app.get("/api/firewall/whitelist")
def get_whitelist():
    return firewall_mgr.get_whitelist()

@app.post("/api/firewall/whitelist")
def add_to_whitelist(req: WhitelistIPRequest):
    success = firewall_mgr.add_to_whitelist(req.ip)
    return {"success": success, "ip": req.ip}

@app.get("/api/waf/logs")
def get_waf_logs():
    return [e for e in events_history if e["source"] in ["modsecurity", "nginx"]][:50]

@app.get("/api/health")
def get_health_metrics():
    return metrics_coll.get_system_health()

@app.get("/api/threat_intel/{ip}")
def get_threat_intel(ip: str):
    return ThreatIntelEngine.enrich_ip(ip)

@app.get("/api/cisa_kev")
def get_cisa_kev():
    return ThreatIntelEngine.get_cisa_kev_catalog()

@app.post("/api/ai/chat")
def ai_chat(req: AIChatRequest):
    response_text = MythosAIAssistant.chat_response(req.prompt, events_history)
    return {"prompt": req.prompt, "response": response_text}

@app.post("/api/ai/analyze")
def ai_analyze_event(event_id: str):
    matched = next((e for e in events_history if e["id"] == event_id), None)
    if not matched:
        raise HTTPException(status_code=404, detail="Event not found")
    return MythosAIAssistant.analyze_incident(matched)

@app.get("/api/reports/summary")
def get_report_summary(period: str = "Daily"):
    return ReportGenerator.generate_summary(events_history, firewall_mgr.get_blocked_ips(), period=period)

@app.get("/api/reports/export/csv")
def export_csv():
    csv_data = ReportGenerator.export_csv(events_history)
    return Response(content=csv_data, media_type="text/csv", headers={"Content-Disposition": "attachment; filename=soc_audit_report.csv"})

@app.get("/api/reports/export/pdf")
def export_pdf_html(period: str = "Daily"):
    summary = ReportGenerator.generate_summary(events_history, firewall_mgr.get_blocked_ips(), period=period)
    html_data = ReportGenerator.export_pdf_html(summary, events_history)
    return Response(content=html_data, media_type="text/html", headers={"Content-Disposition": "inline; filename=soc_executive_report.html"})

# WebSocket active clients for real-time live stream
connected_websockets: List[WebSocket] = []

@app.websocket("/ws/live-events")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connected_websockets.append(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        connected_websockets.remove(websocket)

# Real Production Server Log Tailer Loop (No Synthetic/Fake Data)
async def background_log_loop():
    while True:
        await asyncio.sleep(1.0) # Check real server logs every 1 second
        real_events = real_log_tailer.check_new_logs()
        for raw_evt in real_events:
            full_event = process_event(raw_evt)
            
            # Broadcast real events over WebSocket
            for ws in list(connected_websockets):
                try:
                    await ws.send_json(full_event)
                except Exception:
                    if ws in connected_websockets:
                        connected_websockets.remove(ws)

@app.on_event("startup")
async def on_startup():
    asyncio.create_task(background_log_loop())
