from datetime import datetime, timezone
import logging
from typing import Optional
from soc_engine.auto_patcher import AutoPatcher

class SOAREngine:
    """
    SOAR (Security Orchestration, Automation, and Response) Engine.
    Executes automated response playbooks:
      - Low / Medium: Executes automated virtual patching, input sanitization, rate-limiting rules.
      - High / Critical: Auto-blocks malicious IP on Windows Firewall/UFW/Nginx and dispatches emergency alert email to jesinmilesh@gmail.com.
    """
    def __init__(self, firewall_manager=None, email_notifier=None, auto_patcher: Optional[AutoPatcher] = None, audit_logger=None):
        self.firewall_manager = firewall_manager
        self.email_notifier = email_notifier
        self.auto_patcher = auto_patcher or AutoPatcher()
        self.audit_logger = audit_logger or []
        
    def execute_policy(self, event: dict) -> dict:
        severity = event.get("severity", "Low")
        attack_type = event.get("attack_type", "Unknown Event")
        ip = event.get("client_ip", "0.0.0.0")
        uri = event.get("uri", "/")
        
        actions_taken = []
        incident_created = False
        blocked = False
        email_sent = False
        patch_applied = None

        if severity in ["Low", "Medium"]:
            # Automated Patching Protocol
            patch_applied = self.auto_patcher.apply_patch(event)
            actions_taken.append(f"Auto-Patched ({severity}): {patch_applied['patch_type']} applied to endpoint {uri}")

        elif severity in ["High", "Critical"] or attack_type in [
            "SQL Injection (SQLi)", "Cross-Site Scripting (XSS)", "Command Injection (RCE)",
            "Brute Force Attack", "Path Traversal", "File Inclusion", "Critical WAF Violation",
            "Malicious IP Activity", "Malicious IP Traffic"
        ]:
            # Firewall & Nginx Auto IP Blocking
            if self.firewall_manager:
                self.firewall_manager.block_ip(ip, reason=f"SOAR Auto-Block: {attack_type}")
            actions_taken.append(f"Auto-Blocked IP {ip} across Windows Firewall / UFW / Nginx Proxy")
            blocked = True

            # Emergency Email Dispatch to jesinmilesh@gmail.com
            if self.email_notifier:
                self.email_notifier.send_emergency_alert(event)
            actions_taken.append("Emergency Alert Email dispatched to jesinmilesh@gmail.com")
            email_sent = True
            incident_created = True

        if not actions_taken:
            actions_taken.append("Logged event to audit trail")

        audit_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event_id": event.get("id"),
            "client_ip": ip,
            "attack_type": attack_type,
            "severity": severity,
            "actions": actions_taken,
            "blocked": blocked,
            "email_sent": email_sent,
            "patch_applied": patch_applied,
            "incident_created": incident_created
        }

        self.audit_logger.append(audit_entry)
        
        return {
            "actions_taken": actions_taken,
            "blocked": blocked,
            "email_sent": email_sent,
            "patch_applied": patch_applied,
            "incident_created": incident_created,
            "audit_entry": audit_entry
        }
